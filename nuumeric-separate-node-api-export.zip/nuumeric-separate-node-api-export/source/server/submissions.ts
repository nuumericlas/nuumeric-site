/**
 * Shared delivery pipeline for public form submissions.
 *
 * Extracted so both the public endpoints and the admin "release" action
 * (for false positives caught by the spam filter) run identical logic:
 * persist -> Zoho CRM lead -> owner notification.
 */
import { z } from "zod";
import { notifyOwner } from "./_core/notification";
import {
  createContactSubmission,
  createReferralSubmission,
  updateContactZohoSync,
  updateReferralZohoSync,
} from "./db";
import { createZohoLead, isZohoConfigured } from "./zoho";

export const contactInputSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(200),
  email: z.string().trim().email("A valid email is required").max(320),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  service: z.string().trim().min(1, "Service is required").max(100),
  message: z.string().trim().max(5000).optional().or(z.literal("")),
});

export const referralInputSchema = z.object({
  referrerName: z.string().trim().min(1, "Your name is required").max(200),
  referrerEmail: z.string().trim().email("A valid email is required").max(320),
  referrerPhone: z.string().trim().max(40).optional().or(z.literal("")),
  referredBusiness: z.string().trim().min(1, "The business name is required").max(200),
  referredContact: z.string().trim().max(200).optional().or(z.literal("")),
  referredEmail: z
    .string()
    .trim()
    .email("Please enter a valid email for the business")
    .max(320)
    .optional()
    .or(z.literal("")),
  referredPhone: z.string().trim().max(40).optional().or(z.literal("")),
  notes: z.string().trim().max(5000).optional().or(z.literal("")),
});

export type ContactPayload = {
  name: string;
  email: string;
  phone?: string | null;
  service: string;
  message?: string | null;
};

export type ReferralPayload = {
  referrerName: string;
  referrerEmail: string;
  referrerPhone?: string | null;
  referredBusiness: string;
  referredContact?: string | null;
  referredEmail?: string | null;
  referredPhone?: string | null;
  notes?: string | null;
};

/** Persist + sync + notify for a quote request. `notePrefix` marks released items. */
export async function deliverContactSubmission(
  payload: ContactPayload,
  notePrefix?: string,
): Promise<void> {
  const submissionId = await createContactSubmission({
    name: payload.name,
    email: payload.email,
    phone: payload.phone || null,
    service: payload.service,
    message: payload.message || null,
  });

  // Best-effort Zoho CRM lead creation; never block the user on failure.
  let zohoLeadId: string | null = null;
  if (isZohoConfigured()) {
    try {
      zohoLeadId = await createZohoLead({
        name: payload.name,
        email: payload.email,
        phone: payload.phone || null,
        service: payload.service,
        message: payload.message || null,
      });
      if (submissionId) await updateContactZohoSync(submissionId, "synced", zohoLeadId);
    } catch (error) {
      console.error("[Contact] Zoho CRM lead creation failed:", error);
      if (submissionId) await updateContactZohoSync(submissionId, "failed", null);
    }
  }

  // Best-effort owner notification; never block the user on failure.
  try {
    await notifyOwner({
      title: `${notePrefix ?? ""}New quote request from ${payload.name}`,
      content: [
        `Service: ${payload.service}`,
        `Email: ${payload.email}`,
        payload.phone ? `Phone: ${payload.phone}` : null,
        payload.message ? `Message: ${payload.message}` : null,
        zohoLeadId ? `Zoho Lead: created (${zohoLeadId})` : `Zoho Lead: not created`,
      ]
        .filter(Boolean)
        .join("\n"),
    });
  } catch (error) {
    console.warn("[Contact] Owner notification failed:", error);
  }
}

/** Persist + sync + notify for a client referral. */
export async function deliverReferralSubmission(
  payload: ReferralPayload,
  notePrefix?: string,
): Promise<void> {
  const submissionId = await createReferralSubmission({
    referrerName: payload.referrerName,
    referrerEmail: payload.referrerEmail,
    referrerPhone: payload.referrerPhone || null,
    referredBusiness: payload.referredBusiness,
    referredContact: payload.referredContact || null,
    referredEmail: payload.referredEmail || null,
    referredPhone: payload.referredPhone || null,
    notes: payload.notes || null,
  });

  // Zoho lead requires an email so the duplicate check works.
  let zohoLeadId: string | null = null;
  if (isZohoConfigured() && payload.referredEmail) {
    try {
      zohoLeadId = await createZohoLead({
        name: payload.referredContact || payload.referredBusiness,
        email: payload.referredEmail,
        phone: payload.referredPhone || null,
        service: "Client Referral",
        message: [
          `Referred business: ${payload.referredBusiness}`,
          `Referred by: ${payload.referrerName} (${payload.referrerEmail})`,
          payload.notes ? `Notes: ${payload.notes}` : null,
        ]
          .filter(Boolean)
          .join("\n"),
      });
      if (submissionId) await updateReferralZohoSync(submissionId, "synced", zohoLeadId);
    } catch (error) {
      console.error("[Referral] Zoho CRM lead creation failed:", error);
      if (submissionId) await updateReferralZohoSync(submissionId, "failed", null);
    }
  }

  try {
    await notifyOwner({
      title: `${notePrefix ?? ""}New referral from ${payload.referrerName}: ${payload.referredBusiness}`,
      content: [
        `Referrer: ${payload.referrerName} (${payload.referrerEmail}${payload.referrerPhone ? `, ${payload.referrerPhone}` : ""})`,
        `Referred business: ${payload.referredBusiness}`,
        payload.referredContact ? `Contact person: ${payload.referredContact}` : null,
        payload.referredEmail ? `Email: ${payload.referredEmail}` : null,
        payload.referredPhone ? `Phone: ${payload.referredPhone}` : null,
        payload.notes ? `Notes: ${payload.notes}` : null,
        `Reminder: $100 credit applies to ${payload.referrerName}'s next invoice after the referred business completes its first paid month.`,
        zohoLeadId ? `Zoho Lead: created (${zohoLeadId})` : `Zoho Lead: not created`,
      ]
        .filter(Boolean)
        .join("\n"),
    });
  } catch (error) {
    console.warn("[Referral] Owner notification failed:", error);
  }
}
