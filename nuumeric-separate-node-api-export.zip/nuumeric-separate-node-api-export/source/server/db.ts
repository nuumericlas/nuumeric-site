import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { and, desc, inArray, lt } from "drizzle-orm";
import {
  blogPosts,
  contactSubmissions,
  blockedPhrases,
  filteredSubmissions,
  InsertBlockedPhrase,
  InsertBlogPost,
  InsertContactSubmission,
  InsertFilteredSubmission,
  InsertReferralSubmission,
  InsertUser,
  referralSubmissions,
  users,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createContactSubmission(
  submission: InsertContactSubmission,
): Promise<number | null> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  const [result] = await db.insert(contactSubmissions).values(submission);
  return result.insertId ?? null;
}

export async function updateContactZohoSync(
  id: number,
  status: "synced" | "failed",
  zohoLeadId: string | null,
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update Zoho sync status: database not available");
    return;
  }
  await db
    .update(contactSubmissions)
    .set({ zohoSyncStatus: status, zohoLeadId })
    .where(eq(contactSubmissions.id, id));
}

export async function createReferralSubmission(
  submission: InsertReferralSubmission,
): Promise<number | null> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  const [result] = await db.insert(referralSubmissions).values(submission);
  return result.insertId ?? null;
}

export async function updateReferralZohoSync(
  id: number,
  status: "synced" | "failed",
  zohoLeadId: string | null,
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update referral Zoho sync status: database not available");
    return;
  }
  await db
    .update(referralSubmissions)
    .set({ zohoSyncStatus: status, zohoLeadId })
    .where(eq(referralSubmissions.id, id));
}

export type ReferralCreditStatus = "pending" | "approved" | "applied" | "declined";

/** All referral records, newest first, optionally narrowed to one credit status. */
export async function listReferralSubmissions(
  creditStatus?: ReferralCreditStatus,
) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  const query = db.select().from(referralSubmissions);
  const rows = creditStatus
    ? await query
        .where(eq(referralSubmissions.creditStatus, creditStatus))
        .orderBy(desc(referralSubmissions.createdAt))
    : await query.orderBy(desc(referralSubmissions.createdAt));
  return rows;
}

export async function getReferralSubmission(id: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  const rows = await db
    .select()
    .from(referralSubmissions)
    .where(eq(referralSubmissions.id, id))
    .limit(1);
  return rows[0] ?? null;
}

/**
 * Move a referral's credit to a new status. `creditAppliedAt` is stamped only
 * when the credit is actually applied to an invoice, and cleared otherwise so
 * the column never claims a payout that was later reversed.
 */
export async function updateReferralCredit(
  id: number,
  input: {
    creditStatus: ReferralCreditStatus;
    creditNote?: string | null;
    creditAmount?: number;
  },
): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }
  const now = new Date();
  await db
    .update(referralSubmissions)
    .set({
      creditStatus: input.creditStatus,
      ...(input.creditNote !== undefined ? { creditNote: input.creditNote } : {}),
      ...(input.creditAmount !== undefined ? { creditAmount: input.creditAmount } : {}),
      creditAppliedAt: input.creditStatus === "applied" ? now : null,
      creditUpdatedAt: now,
    })
    .where(eq(referralSubmissions.id, id));
}
// ————————————————————————— Blog —————————————————————————

/** Published posts, newest first, without the full content body (for lists). */
export async function listPublishedPosts() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db
    .select({
      id: blogPosts.id,
      slug: blogPosts.slug,
      title: blogPosts.title,
      excerpt: blogPosts.excerpt,
      coverImageUrl: blogPosts.coverImageUrl,
      category: blogPosts.category,
      tags: blogPosts.tags,
      publishedAt: blogPosts.publishedAt,
    })
    .from(blogPosts)
    .where(eq(blogPosts.status, "published"))
    .orderBy(desc(blogPosts.publishedAt));
}

export async function getPublishedPostBySlug(slug: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const rows = await db
    .select()
    .from(blogPosts)
    .where(and(eq(blogPosts.slug, slug), eq(blogPosts.status, "published")))
    .limit(1);
  return rows[0];
}

/** All posts (drafts included), newest first — admin only. */
export async function listAllPosts() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db
    .select({
      id: blogPosts.id,
      slug: blogPosts.slug,
      title: blogPosts.title,
      excerpt: blogPosts.excerpt,
      coverImageUrl: blogPosts.coverImageUrl,
      category: blogPosts.category,
      tags: blogPosts.tags,
      status: blogPosts.status,
      publishedAt: blogPosts.publishedAt,
      updatedAt: blogPosts.updatedAt,
    })
    .from(blogPosts)
    .orderBy(desc(blogPosts.updatedAt));
}

export async function getPostById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const rows = await db.select().from(blogPosts).where(eq(blogPosts.id, id)).limit(1);
  return rows[0];
}

export async function getPostBySlugAnyStatus(slug: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const rows = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug)).limit(1);
  return rows[0];
}

export async function createBlogPost(post: InsertBlogPost): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [result] = await db.insert(blogPosts).values(post);
  return result.insertId;
}

export async function updateBlogPost(
  id: number,
  changes: Partial<InsertBlogPost>,
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(blogPosts).set(changes).where(eq(blogPosts.id, id));
}

export async function deleteBlogPost(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(blogPosts).where(eq(blogPosts.id, id));
}

// ————————————————— Spam filter administration —————————————————

/** All blocked phrases, alphabetical within category. */
export async function listBlockedPhrases() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(blockedPhrases).orderBy(blockedPhrases.category, blockedPhrases.phrase);
}

export async function createBlockedPhrase(row: InsertBlockedPhrase): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [result] = await db.insert(blockedPhrases).values(row);
  return result.insertId;
}

export async function deleteBlockedPhrase(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(blockedPhrases).where(eq(blockedPhrases.id, id));
}

export async function logFilteredSubmission(
  row: InsertFilteredSubmission,
): Promise<number | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot log filtered submission: database not available");
    return null;
  }
  try {
    const [result] = await db.insert(filteredSubmissions).values(row);
    return result.insertId ?? null;
  } catch (error) {
    // Logging must never break the request path.
    console.error("[Database] Failed to log filtered submission:", error);
    return null;
  }
}

/** Filtered submissions, newest first. Optionally restricted to one status. */
export async function listFilteredSubmissions(status?: "pending" | "released" | "dismissed") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const base = db.select().from(filteredSubmissions);
  return status
    ? base.where(eq(filteredSubmissions.status, status)).orderBy(desc(filteredSubmissions.createdAt))
    : base.orderBy(desc(filteredSubmissions.createdAt));
}

export async function getFilteredSubmission(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const rows = await db
    .select()
    .from(filteredSubmissions)
    .where(eq(filteredSubmissions.id, id))
    .limit(1);
  return rows[0];
}

export async function setFilteredSubmissionStatus(
  id: number,
  status: "pending" | "released" | "dismissed",
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(filteredSubmissions)
    .set({ status, releasedAt: status === "released" ? new Date() : null })
    .where(eq(filteredSubmissions.id, id));
}

export async function deleteFilteredSubmission(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(filteredSubmissions).where(eq(filteredSubmissions.id, id));
}

/**
 * Held messages that are still unreviewed after `thresholdHours`, oldest first.
 * Used both by the on-site warning banner and the recurring alert job — a
 * genuine inquiry sitting in the review queue is the one failure mode of the
 * spam filter that actually costs business.
 */
export async function listStalePendingSubmissions(thresholdHours: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const cutoff = new Date(Date.now() - thresholdHours * 60 * 60 * 1000);
  return db
    .select()
    .from(filteredSubmissions)
    .where(
      and(
        eq(filteredSubmissions.status, "pending"),
        lt(filteredSubmissions.createdAt, cutoff),
      ),
    )
    .orderBy(filteredSubmissions.createdAt);
}

/** Stamps alertedAt so an already-reported message is not re-reported daily. */
export async function markSubmissionsAlerted(ids: number[]): Promise<void> {
  if (ids.length === 0) return;
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(filteredSubmissions)
    .set({ alertedAt: new Date() })
    .where(inArray(filteredSubmissions.id, ids));
}
