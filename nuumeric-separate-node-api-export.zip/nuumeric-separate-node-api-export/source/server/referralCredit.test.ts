import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({
  createContactSubmission: vi.fn(),
  createReferralSubmission: vi.fn(),
  updateContactZohoSync: vi.fn(),
  updateReferralZohoSync: vi.fn(),
  listBlockedPhrases: vi.fn().mockResolvedValue([]),
  createFilteredSubmission: vi.fn(),
  listReferralSubmissions: vi.fn(),
  getReferralSubmission: vi.fn(),
  updateReferralCredit: vi.fn(),
}));

vi.mock("./zoho", () => ({
  isZohoConfigured: vi.fn().mockReturnValue(false),
  createZohoLead: vi.fn(),
}));

vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(undefined),
}));

import { appRouter } from "./routers";
import {
  getReferralSubmission,
  listReferralSubmissions,
  updateReferralCredit,
} from "./db";

function adminCaller() {
  return appRouter.createCaller({
    req: {} as never,
    res: {} as never,
    user: { id: 1, openId: "owner", name: "Leighann", role: "admin" },
  } as never);
}

function visitorCaller() {
  return appRouter.createCaller({
    req: {} as never,
    res: {} as never,
    user: null,
  } as never);
}

function referralRow(overrides: Record<string, unknown> = {}) {
  return {
    id: 7,
    referrerName: "Jane Smith",
    referrerEmail: "jane@company.com",
    referrerPhone: null,
    referredBusiness: "Acme Dental",
    referredContact: "John Doe",
    referredEmail: "john@acmedental.com",
    referredPhone: null,
    notes: null,
    creditStatus: "pending",
    creditAmount: 100,
    creditNote: null,
    creditAppliedAt: null,
    creditUpdatedAt: null,
    zohoSyncStatus: "pending",
    zohoLeadId: null,
    createdAt: new Date("2026-07-01T12:00:00Z"),
    ...overrides,
  };
}

describe("referral.admin credit tracking", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(getReferralSubmission).mockResolvedValue(referralRow() as never);
    vi.mocked(listReferralSubmissions).mockResolvedValue([] as never);
  });

  it("requires an admin session to list referral records", async () => {
    await expect(visitorCaller().referral.admin.list({})).rejects.toThrow();
  });

  it("requires an admin session to change a credit status", async () => {
    await expect(
      visitorCaller().referral.admin.setStatus({ id: 7, creditStatus: "applied" }),
    ).rejects.toThrow();
  });

  it("lists every referral when no status filter is given", async () => {
    await adminCaller().referral.admin.list({});
    expect(listReferralSubmissions).toHaveBeenCalledWith(undefined);
  });

  it("passes a status filter through to the query", async () => {
    await adminCaller().referral.admin.list({ status: "approved" });
    expect(listReferralSubmissions).toHaveBeenCalledWith("approved");
  });

  it("moves a referral to approved", async () => {
    const result = await adminCaller().referral.admin.setStatus({
      id: 7,
      creditStatus: "approved",
    });
    expect(result).toEqual({ success: true });
    expect(updateReferralCredit).toHaveBeenCalledWith(7, {
      creditStatus: "approved",
      creditNote: undefined,
      creditAmount: undefined,
    });
  });

  it("stores an internal credit note", async () => {
    await adminCaller().referral.admin.setStatus({
      id: 7,
      creditStatus: "applied",
      creditNote: "Invoice #1042",
    });
    expect(updateReferralCredit).toHaveBeenCalledWith(7, {
      creditStatus: "applied",
      creditNote: "Invoice #1042",
      creditAmount: undefined,
    });
  });

  it("normalises an emptied note to null so the column is cleared", async () => {
    await adminCaller().referral.admin.setStatus({
      id: 7,
      creditStatus: "pending",
      creditNote: "",
    });
    expect(updateReferralCredit).toHaveBeenCalledWith(7, {
      creditStatus: "pending",
      creditNote: null,
      creditAmount: undefined,
    });
  });

  it("rejects an unknown credit status", async () => {
    await expect(
      adminCaller().referral.admin.setStatus({
        id: 7,
        creditStatus: "paid" as never,
      }),
    ).rejects.toThrow();
    expect(updateReferralCredit).not.toHaveBeenCalled();
  });

  it("fails clearly when the referral no longer exists", async () => {
    vi.mocked(getReferralSubmission).mockResolvedValue(null as never);
    await expect(
      adminCaller().referral.admin.setStatus({ id: 999, creditStatus: "applied" }),
    ).rejects.toThrow(/not found/i);
    expect(updateReferralCredit).not.toHaveBeenCalled();
  });

  it("summarises counts and dollar totals per status", async () => {
    vi.mocked(listReferralSubmissions).mockResolvedValue([
      referralRow({ id: 1, creditStatus: "pending" }),
      referralRow({ id: 2, creditStatus: "approved" }),
      referralRow({ id: 3, creditStatus: "approved", creditAmount: 150 }),
      referralRow({ id: 4, creditStatus: "applied" }),
      referralRow({ id: 5, creditStatus: "declined" }),
    ] as never);

    const summary = await adminCaller().referral.admin.summary();

    expect(summary.total).toBe(5);
    expect(summary.pending).toEqual({ count: 1, amount: 100 });
    expect(summary.approved).toEqual({ count: 2, amount: 250 });
    expect(summary.applied).toEqual({ count: 1, amount: 100 });
    expect(summary.declined).toEqual({ count: 1, amount: 100 });
  });

  it("reports zeroes when no referrals exist yet", async () => {
    const summary = await adminCaller().referral.admin.summary();
    expect(summary.total).toBe(0);
    expect(summary.approved).toEqual({ count: 0, amount: 0 });
  });
});
