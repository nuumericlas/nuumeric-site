import { describe, expect, it } from "vitest";
import { slugify } from "./routers/blog";
import { getPostBySlugAnyStatus, getPublishedPostBySlug, listPublishedPosts } from "./db";

const ERISA_SLUG = "do-you-need-an-erisa-for-your-small-business-health-plan";

describe("ERISA post is staged as a draft", () => {
  it("derives the expected slug from the title", () => {
    expect(slugify('Do You Need "an ERISA" for Your Small Business Health Plan?')).toBe(
      ERISA_SLUG,
    );
  });

  it("exists in the database with draft status and no publish date", async () => {
    const post = await getPostBySlugAnyStatus(ERISA_SLUG);
    if (!post) {
      // Database is unavailable in this environment; nothing to assert.
      return;
    }
    expect(post.status).toBe("draft");
    expect(post.publishedAt).toBeNull();
    expect(post.category).toBe("HR");
    expect(post.content.length).toBeGreaterThan(3000);
  });

  it("is NOT returned by the public single-post lookup while it is a draft", async () => {
    const staged = await getPostBySlugAnyStatus(ERISA_SLUG);
    if (!staged || staged.status !== "draft") return;
    const publicPost = await getPublishedPostBySlug(ERISA_SLUG);
    expect(publicPost).toBeFalsy();
  });

  it("is NOT included in the public blog index while it is a draft", async () => {
    const staged = await getPostBySlugAnyStatus(ERISA_SLUG);
    if (!staged || staged.status !== "draft") return;
    const published = await listPublishedPosts();
    expect(published.some((p) => p.slug === ERISA_SLUG)).toBe(false);
    // Sanity check that the index is actually returning posts.
    expect(published.length).toBeGreaterThan(0);
  });
});
