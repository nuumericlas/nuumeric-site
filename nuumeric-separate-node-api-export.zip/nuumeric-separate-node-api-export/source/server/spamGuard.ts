/**
 * Lightweight, dependency-free spam protection for public form endpoints.
 *
 * Three independent layers, each cheap enough to run inline on every request:
 *  1. Honeypot + submit timing — catches naive bots that fill every field
 *     and post instantly.
 *  2. Per-IP rate limiting — caps how many submissions one source can send.
 *  3. Content heuristics — rejects the classic SEO/backlink spam payloads.
 *
 * Rejections are deliberately reported back as generic success to the client
 * (see callers) so spam bots do not learn which signal tripped them.
 */

export type SpamCheckResult =
  | { ok: true }
  | { ok: false; reason: string };

/** Fields every protected form sends alongside its real payload. */
export const antiSpamInputShape = {
  /** Honeypot: must stay empty. Real users never see the field. */
  hp: "",
  /** Client timestamp (ms) captured when the form was first rendered. */
  formLoadedAt: 0,
};

/** Minimum plausible time (ms) for a human to fill out a form. */
export const MIN_FILL_MS = 2500;
/** Ignore absurd values (clock skew, page left open for days). */
export const MAX_FILL_MS = 1000 * 60 * 60 * 12;

export function checkHoneypotAndTiming(input: {
  hp?: string | null;
  formLoadedAt?: number | null;
  now?: number;
}): SpamCheckResult {
  if (input.hp && input.hp.trim().length > 0) {
    return { ok: false, reason: "honeypot" };
  }

  const loadedAt = input.formLoadedAt ?? 0;
  if (loadedAt > 0) {
    const elapsed = (input.now ?? Date.now()) - loadedAt;
    // Negative elapsed means a forged/skewed timestamp.
    if (elapsed < 0) return { ok: false, reason: "timestamp-skew" };
    if (elapsed < MIN_FILL_MS) return { ok: false, reason: "too-fast" };
    if (elapsed > MAX_FILL_MS) return { ok: true };
  }

  return { ok: true };
}

// ---------------------------------------------------------------------------
// Per-IP rate limiting (in-memory, per server instance)
// ---------------------------------------------------------------------------

type Bucket = { timestamps: number[] };
const buckets = new Map<string, Bucket>();

export const RATE_LIMIT_WINDOW_MS = 60 * 60 * 1000; // 1 hour
export const RATE_LIMIT_MAX = 5; // submissions per IP per window
const MAX_TRACKED_IPS = 5000;

export function checkRateLimit(
  ip: string,
  now: number = Date.now(),
  max: number = RATE_LIMIT_MAX,
  windowMs: number = RATE_LIMIT_WINDOW_MS,
): SpamCheckResult {
  if (!ip) return { ok: true };

  // Crude cap so a flood of unique IPs cannot grow the map without bound.
  if (buckets.size > MAX_TRACKED_IPS) buckets.clear();

  const bucket = buckets.get(ip) ?? { timestamps: [] };
  const cutoff = now - windowMs;
  bucket.timestamps = bucket.timestamps.filter(t => t > cutoff);

  if (bucket.timestamps.length >= max) {
    buckets.set(ip, bucket);
    return { ok: false, reason: "rate-limited" };
  }

  bucket.timestamps.push(now);
  buckets.set(ip, bucket);
  return { ok: true };
}

/** Testing helper — clears all rate-limit state. */
export function resetRateLimits() {
  buckets.clear();
}

/** Best-effort client IP extraction from proxy headers. */
export function clientIpFrom(
  headers: Record<string, unknown> | undefined | null,
  fallback?: string,
): string {
  if (!headers) return fallback ?? "";
  const forwarded = headers["x-forwarded-for"];
  if (typeof forwarded === "string" && forwarded.length > 0) {
    return forwarded.split(",")[0]!.trim();
  }
  if (Array.isArray(forwarded) && forwarded.length > 0) {
    return String(forwarded[0]).split(",")[0]!.trim();
  }
  const real = headers["x-real-ip"];
  if (typeof real === "string" && real.length > 0) return real.trim();
  return fallback ?? "";
}

// ---------------------------------------------------------------------------
// Content heuristics
// ---------------------------------------------------------------------------

/**
 * Fallback list used only when the database is unreachable. The live list is
 * the `blocked_phrases` table, managed by the owner at /admin/spam.
 */
export const DEFAULT_SPAM_PHRASES = [
  "seo service",
  "seo services",
  "backlink",
  "back link",
  "guest post",
  "link building",
  "buy now",
  "casino",
  "crypto investment",
  "forex",
  "viagra",
  "cialis",
  "porn",
  "escort",
  "loan offer",
  "bitcoin doubler",
  "increase your traffic",
  "rank #1 on google",
  "rank first on google",
  "web design offer",
  "telegram me",
  "whatsapp me at",
];

const MAX_LINKS = 1;
const MAX_TEXT_UPPERCASE_RATIO = 0.6;

function countLinks(text: string): number {
  const matches = text.match(/(https?:\/\/|www\.)/gi);
  return matches ? matches.length : 0;
}

/**
 * Scores the free-text portions of a submission. Returns not-ok for payloads
 * that look like automated link/SEO spam rather than a real inquiry.
 * `phrases` defaults to the built-in fallback list; callers that can reach the
 * database should pass the admin-managed list instead.
 */
export function checkContent(
  parts: Array<string | null | undefined>,
  phrases: string[] = DEFAULT_SPAM_PHRASES,
): SpamCheckResult {
  const text = parts.filter(Boolean).join("\n");
  if (!text.trim()) return { ok: true };

  const lower = text.toLowerCase();

  for (const phrase of phrases) {
    const needle = phrase.trim().toLowerCase();
    if (needle.length > 0 && lower.includes(needle)) {
      return { ok: false, reason: `phrase:${needle}` };
    }
  }

  if (countLinks(text) > MAX_LINKS) return { ok: false, reason: "too-many-links" };

  // Cyrillic / CJK-only payloads with links are a common spam signature; plain
  // non-Latin text alone is NOT penalised (legitimate international clients).
  const letters = text.replace(/[^A-Za-z]/g, "");
  if (letters.length >= 20) {
    const uppercase = letters.replace(/[^A-Z]/g, "").length;
    if (uppercase / letters.length > MAX_TEXT_UPPERCASE_RATIO) {
      return { ok: false, reason: "shouting" };
    }
  }

  return { ok: true };
}

/** Runs every layer. `ip` may be empty when unavailable. */
export function screenSubmission(args: {
  ip: string;
  hp?: string | null;
  formLoadedAt?: number | null;
  textParts: Array<string | null | undefined>;
  now?: number;
  phrases?: string[];
}): SpamCheckResult {
  const timing = checkHoneypotAndTiming({
    hp: args.hp,
    formLoadedAt: args.formLoadedAt,
    now: args.now,
  });
  if (!timing.ok) return timing;

  const content = checkContent(args.textParts, args.phrases);
  if (!content.ok) return content;

  return checkRateLimit(args.ip, args.now);
}

// ---------------------------------------------------------------------------
// Admin-managed phrase list (cached)
// ---------------------------------------------------------------------------

let phraseCache: { phrases: string[]; loadedAt: number } | null = null;
/** Short TTL so admin edits take effect quickly without hitting the DB per request. */
export const PHRASE_CACHE_TTL_MS = 60 * 1000;

/** Drops the cache so the next screening reloads from the database. */
export function invalidatePhraseCache() {
  phraseCache = null;
}

/**
 * Loads the admin-managed phrase list, falling back to the built-in defaults
 * if the database is unavailable (never leaves forms unprotected).
 */
export async function loadSpamPhrases(
  loader: () => Promise<Array<{ phrase: string }>>,
  now: number = Date.now(),
): Promise<string[]> {
  if (phraseCache && now - phraseCache.loadedAt < PHRASE_CACHE_TTL_MS) {
    return phraseCache.phrases;
  }
  try {
    const rows = await loader();
    const phrases = rows.map(r => r.phrase.trim().toLowerCase()).filter(p => p.length > 0);
    phraseCache = { phrases, loadedAt: now };
    return phrases;
  } catch (error) {
    console.error("[SpamGuard] Failed to load blocked phrases, using defaults:", error);
    return DEFAULT_SPAM_PHRASES;
  }
}
