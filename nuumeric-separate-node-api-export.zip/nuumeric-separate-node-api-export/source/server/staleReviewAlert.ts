/**
 * Stale spam-review alerting.
 *
 * The spam filter's one costly failure mode is a genuine inquiry sitting in the
 * review queue unnoticed. This module finds held messages that have been
 * "pending" for longer than the threshold and reports them to the owner, both
 * on demand (admin UI) and from a recurring schedule.
 */
import type { Request, Response } from "express";
import { SITE } from "../shared/site";
import { notifyOwner } from "./_core/notification";
import { sdk } from "./_core/sdk";
import { listStalePendingSubmissions, markSubmissionsAlerted } from "./db";

/** A held message becomes "overdue" once it has waited this long unreviewed. */
export const STALE_THRESHOLD_HOURS = 48;

type StaleRow = {
  id: number;
  formType: string;
  reason: string;
  payload: string;
  createdAt: Date | string;
  alertedAt: Date | string | null;
};

function hoursWaiting(createdAt: Date | string): number {
  const created = new Date(createdAt).getTime();
  return Math.max(0, Math.floor((Date.now() - created) / (60 * 60 * 1000)));
}

/** Human-readable wait, e.g. "3 days" or "50 hours". */
export function describeWait(createdAt: Date | string): string {
  const hours = hoursWaiting(createdAt);
  if (hours < 48) return `${hours} hours`;
  const days = Math.floor(hours / 24);
  return `${days} days`;
}

/** Best-effort sender name/subject line pulled out of the stored payload. */
function describeSender(row: StaleRow): string {
  try {
    const parsed = JSON.parse(row.payload) as Record<string, unknown>;
    const name =
      (typeof parsed.name === "string" && parsed.name) ||
      (typeof parsed.referrerName === "string" && parsed.referrerName) ||
      "";
    const email =
      (typeof parsed.email === "string" && parsed.email) ||
      (typeof parsed.referrerEmail === "string" && parsed.referrerEmail) ||
      "";
    if (name && email) return `${name} (${email})`;
    return name || email || "Unknown sender";
  } catch {
    return "Unknown sender";
  }
}

function readableReason(reason: string): string {
  if (reason.startsWith("phrase:")) return `blocked phrase "${reason.slice(7)}"`;
  const map: Record<string, string> = {
    honeypot: "hidden field filled (bot)",
    "too-fast": "submitted too quickly (bot)",
    "too-many-links": "too many links",
    shouting: "mostly capital letters",
    "rate-limit": "too many submissions from one address",
  };
  return map[reason] ?? reason;
}

/**
 * Builds the owner notification for a set of overdue messages. Kept pure so the
 * wording is testable without touching the notification service.
 */
export function buildStaleAlert(rows: StaleRow[]): { title: string; content: string } {
  const count = rows.length;
  const oldest = rows[0];
  const title =
    count === 1
      ? `A held message has been waiting ${describeWait(oldest.createdAt)} for review`
      : `${count} held messages are waiting for review`;

  const lines = rows.slice(0, 10).map(row => {
    const kind = row.formType === "contact" ? "Quote request" : "Referral";
    return `- ${kind} from ${describeSender(row)} — waiting ${describeWait(
      row.createdAt,
    )}, held for ${readableReason(row.reason)}`;
  });
  if (count > lines.length) {
    lines.push(`- ...and ${count - lines.length} more`);
  }

  const content = [
    count === 1
      ? `A message caught by the spam filter has been sitting unreviewed for over ${STALE_THRESHOLD_HOURS} hours. If it is genuine, the sender is still waiting on you.`
      : `${count} messages caught by the spam filter have been sitting unreviewed for over ${STALE_THRESHOLD_HOURS} hours. If any are genuine, those senders are still waiting on you.`,
    "",
    ...lines,
    "",
    `Review them here: ${SITE.canonicalOrigin}/admin/spam`,
  ].join("\n");

  return { title, content };
}

/**
 * Finds overdue messages and notifies the owner about the ones not yet
 * reported. Idempotent: a message is only included in one alert, so re-running
 * the job (or the platform retrying it) will not repeat the same notification.
 */
export async function runStaleReviewCheck(): Promise<{
  overdue: number;
  alerted: number;
  notified: boolean;
}> {
  const stale = (await listStalePendingSubmissions(
    STALE_THRESHOLD_HOURS,
  )) as unknown as StaleRow[];

  if (stale.length === 0) {
    return { overdue: 0, alerted: 0, notified: false };
  }

  const unreported = stale.filter(row => !row.alertedAt);
  if (unreported.length === 0) {
    return { overdue: stale.length, alerted: 0, notified: false };
  }

  const { title, content } = buildStaleAlert(unreported);
  const notified = await notifyOwner({ title, content });

  // Only suppress future alerts for messages we actually managed to report;
  // if the notification service was unreachable, try again on the next run.
  if (notified) {
    await markSubmissionsAlerted(unreported.map(row => row.id));
  }

  return { overdue: stale.length, alerted: notified ? unreported.length : 0, notified };
}

/**
 * Cron callback. Registered at POST /api/scheduled/staleSpamReview.
 * Only the Manus scheduler can invoke it (`user.isCron`).
 */
export async function staleSpamReviewHandler(req: Request, res: Response) {
  try {
    // An unauthenticated or non-cron caller is a rejected request, not a server
    // fault — keep it a 403 so the platform does not retry it as a failure.
    let isCron = false;
    try {
      const user = await sdk.authenticateRequest(req);
      isCron = user.isCron === true;
    } catch {
      isCron = false;
    }
    if (!isCron) {
      return res.status(403).json({ error: "cron-only" });
    }

    const result = await runStaleReviewCheck();
    console.log(
      `[StaleReview] overdue=${result.overdue} alerted=${result.alerted} notified=${result.notified}`,
    );
    return res.json({ ok: true, ...result });
  } catch (error) {
    const err = error as Error;
    console.error("[StaleReview] Check failed:", err);
    return res.status(500).json({
      error: err.message ?? "Stale review check failed",
      stack: err.stack,
      context: { url: req.originalUrl },
      timestamp: new Date().toISOString(),
    });
  }
}
