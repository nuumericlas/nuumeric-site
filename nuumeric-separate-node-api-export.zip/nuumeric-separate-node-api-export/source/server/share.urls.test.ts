import { describe, expect, it } from "vitest";
import { canonicalPostUrl, SHARE_TARGETS } from "../client/src/lib/share";

const TITLE = "Bookkeeping Basics & Beyond: What Owners Need";
const SLUG = "bookkeeping-basics";
const URL = canonicalPostUrl(SLUG);

describe("canonicalPostUrl", () => {
  it("builds the canonical www.nuumeric.com post URL", () => {
    expect(URL).toBe("https://www.nuumeric.com/blog/bookkeeping-basics");
  });

  it("URL-encodes unusual slug characters", () => {
    expect(canonicalPostUrl("a b/c")).toBe("https://www.nuumeric.com/blog/a%20b%2Fc");
  });
});

describe("SHARE_TARGETS", () => {
  it("LinkedIn share URL embeds the encoded post URL", () => {
    const href = SHARE_TARGETS.linkedin.href(URL, TITLE);
    expect(href).toBe(
      `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(URL)}`,
    );
  });

  it("Facebook share URL embeds the encoded post URL", () => {
    const href = SHARE_TARGETS.facebook.href(URL, TITLE);
    expect(href).toBe(
      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(URL)}`,
    );
  });

  it("X share URL includes encoded URL and title text", () => {
    const href = SHARE_TARGETS.x.href(URL, TITLE);
    expect(href).toContain(`url=${encodeURIComponent(URL)}`);
    expect(href).toContain(`text=${encodeURIComponent(TITLE)}`);
    expect(href.startsWith("https://twitter.com/intent/tweet?")).toBe(true);
  });

  it("WhatsApp share URL contains title and URL in a single encoded text param", () => {
    const href = SHARE_TARGETS.whatsapp.href(URL, TITLE);
    expect(href).toBe(`https://wa.me/?text=${encodeURIComponent(`${TITLE} ${URL}`)}`);
  });

  it("Email share URL sets subject to title and includes the URL in the body", () => {
    const href = SHARE_TARGETS.email.href(URL, TITLE);
    expect(href.startsWith("mailto:?subject=")).toBe(true);
    expect(href).toContain(encodeURIComponent(TITLE));
    expect(href).toContain(encodeURIComponent(URL));
  });

  it("every target produces a URL with no unencoded ampersands from the title", () => {
    for (const target of Object.values(SHARE_TARGETS)) {
      const href = target.href(URL, TITLE);
      // The raw title contains "&" — it must never appear unencoded in query values
      const query = href.split("?")[1] ?? "";
      for (const pair of query.split("&")) {
        const value = pair.split("=")[1] ?? "";
        expect(value.includes("&")).toBe(false);
      }
    }
  });
});
