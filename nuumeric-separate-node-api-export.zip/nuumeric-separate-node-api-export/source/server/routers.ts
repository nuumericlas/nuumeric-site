import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { notifyOwner } from "./_core/notification";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import {
  createContactSubmission,
  createReferralSubmission,
  listBlockedPhrases,
  logFilteredSubmission,
  updateContactZohoSync,
  updateReferralZohoSync,
} from "./db";
import { blogRouter } from "./routers/blog";
import { spamRouter } from "./routers/spam";
import { referralsRouter } from "./routers/referrals";
import { createZohoLead, isZohoConfigured } from "./zoho";
import { clientIpFrom, loadSpamPhrases, screenSubmission } from "./spamGuard";
import {
  contactInputSchema,
  deliverContactSubmission,
  deliverReferralSubmission,
  referralInputSchema,
} from "./submissions";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  blog: blogRouter,
  spam: spamRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  contact: router({
    submit: publicProcedure
      .input(
        contactInputSchema.extend({
          hp: z.string().max(200).optional(),
          formLoadedAt: z.number().int().nonnegative().optional(),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const headers = ctx.req?.headers as Record<string, unknown> | undefined;
        const ip = clientIpFrom(headers, ctx.req?.ip);
        const phrases = await loadSpamPhrases(listBlockedPhrases);
        const screening = screenSubmission({
          ip,
          hp: input.hp,
          formLoadedAt: input.formLoadedAt,
          textParts: [input.name, input.message, input.service],
          phrases,
        });
        if (!screening.ok) {
          // Report success so bots cannot probe which signal tripped them.
          console.warn(`[Contact] Submission blocked (${screening.reason})`);
          // Retained for owner review at /admin/spam so false positives are visible.
          await logFilteredSubmission({
            formType: "contact",
            reason: screening.reason,
            payload: JSON.stringify({
              name: input.name,
              email: input.email,
              phone: input.phone || null,
              service: input.service,
              message: input.message || null,
            }),
            ip: ip || null,
            userAgent: typeof headers?.["user-agent"] === "string"
              ? String(headers["user-agent"]).slice(0, 500)
              : null,
          });
          return { success: true } as const;
        }

        await deliverContactSubmission({
          name: input.name,
          email: input.email,
          phone: input.phone || null,
          service: input.service,
          message: input.message || null,
        });
        return { success: true } as const;
      }),
  }),

  referral: router({
    /** Owner-only credit tracking for referral records. */
    admin: referralsRouter,
    submit: publicProcedure
      .input(
        referralInputSchema.extend({
          hp: z.string().max(200).optional(),
          formLoadedAt: z.number().int().nonnegative().optional(),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const headers = ctx.req?.headers as Record<string, unknown> | undefined;
        const ip = clientIpFrom(headers, ctx.req?.ip);
        const phrases = await loadSpamPhrases(listBlockedPhrases);
        const screening = screenSubmission({
          ip,
          hp: input.hp,
          formLoadedAt: input.formLoadedAt,
          textParts: [input.referrerName, input.referredBusiness, input.notes],
          phrases,
        });
        if (!screening.ok) {
          console.warn(`[Referral] Submission blocked (${screening.reason})`);
          await logFilteredSubmission({
            formType: "referral",
            reason: screening.reason,
            payload: JSON.stringify({
              referrerName: input.referrerName,
              referrerEmail: input.referrerEmail,
              referrerPhone: input.referrerPhone || null,
              referredBusiness: input.referredBusiness,
              referredContact: input.referredContact || null,
              referredEmail: input.referredEmail || null,
              referredPhone: input.referredPhone || null,
              notes: input.notes || null,
            }),
            ip: ip || null,
            userAgent: typeof headers?.["user-agent"] === "string"
              ? String(headers["user-agent"]).slice(0, 500)
              : null,
          });
          return { success: true } as const;
        }

        await deliverReferralSubmission({
          referrerName: input.referrerName,
          referrerEmail: input.referrerEmail,
          referrerPhone: input.referrerPhone || null,
          referredBusiness: input.referredBusiness,
          referredContact: input.referredContact || null,
          referredEmail: input.referredEmail || null,
          referredPhone: input.referredPhone || null,
          notes: input.notes || null,
        });
        return { success: true } as const;
      }),
  }),
});

export type AppRouter = typeof appRouter;
