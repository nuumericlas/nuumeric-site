import { beforeEach, describe, expect, it } from "vitest";
import {
  _clearTokenCache,
  buildLeadPayload,
  getZohoAccessToken,
  isZohoConfigured,
  splitName,
} from "./zoho";

describe("splitName", () => {
  it("splits first and last name", () => {
    expect(splitName("Jane Smith")).toEqual({ firstName: "Jane", lastName: "Smith" });
  });
  it("handles middle names", () => {
    expect(splitName("Mary Jo Anne Carter")).toEqual({
      firstName: "Mary Jo Anne",
      lastName: "Carter",
    });
  });
  it("handles single names", () => {
    expect(splitName("Cher")).toEqual({ firstName: "", lastName: "Cher" });
  });
  it("handles empty input", () => {
    expect(splitName("  ")).toEqual({ firstName: "", lastName: "Unknown" });
  });
});

describe("buildLeadPayload", () => {
  it("maps quote form fields to Zoho Lead API names", () => {
    const payload = buildLeadPayload({
      name: "Jane Smith",
      email: "jane@company.com",
      phone: "(555) 123-4567",
      service: "Bookkeeping",
      message: "Need monthly reconciliations.",
    });
    expect(payload.data).toHaveLength(1);
    const lead = payload.data[0];
    expect(lead.Last_Name).toBe("Smith");
    expect(lead.First_Name).toBe("Jane");
    expect(lead.Email).toBe("jane@company.com");
    expect(lead.Phone).toBe("(555) 123-4567");
    expect(lead.Lead_Source).toBe("Website");
    expect(lead.Description).toContain("Service needed: Bookkeeping");
    expect(lead.Description).toContain("Need monthly reconciliations.");
  });

  it("omits phone when blank and still sets mandatory Last_Name", () => {
    const lead = buildLeadPayload({
      name: "Cher",
      email: "cher@x.com",
      phone: "",
      service: "Payroll Processing",
      message: null,
    }).data[0];
    expect(lead.Last_Name).toBe("Cher");
    expect("Phone" in lead).toBe(false);
    expect(lead.Description).toBe("Service needed: Payroll Processing");
  });
});

describe("zoho credentials (live)", () => {
  beforeEach(() => _clearTokenCache());

  it("has all required env vars configured", () => {
    expect(isZohoConfigured()).toBe(true);
  });

  it("exchanges the refresh token for a valid access token", async () => {
    const token = await getZohoAccessToken();
    expect(token.accessToken).toBeTruthy();
    expect(token.apiDomain).toMatch(/^https:\/\//);
    expect(token.expiresAt).toBeGreaterThan(Date.now());
  }, 20_000);
});
