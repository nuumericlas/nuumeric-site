import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const createContactSubmission = vi.fn();
const notifyOwner = vi.fn();
const updateContactZohoSync = vi.fn();
const createZohoLead = vi.fn();
const isZohoConfigured = vi.fn();

vi.mock("./db", async importOriginal => {
  const original = await importOriginal<typeof import("./db")>();
  return {
    ...original,
    createContactSubmission: (...args: unknown[]) => createContactSubmission(...args),
    updateContactZohoSync: (...args: unknown[]) => updateContactZohoSync(...args),
  };
});

vi.mock("./_core/notification", () => ({
  notifyOwner: (...args: unknown[]) => notifyOwner(...args),
}));

vi.mock("./zoho", async importOriginal => {
  const original = await importOriginal<typeof import("./zoho")>();
  return {
    ...original,
    createZohoLead: (...args: unknown[]) => createZohoLead(...args),
    isZohoConfigured: () => isZohoConfigured(),
  };
});

import { appRouter } from "./routers";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("contact.submit", () => {
  beforeEach(() => {
    createContactSubmission.mockReset().mockResolvedValue(42);
    notifyOwner.mockReset().mockResolvedValue(undefined);
    updateContactZohoSync.mockReset().mockResolvedValue(undefined);
    createZohoLead.mockReset().mockResolvedValue("9990001112223334445");
    isZohoConfigured.mockReset().mockReturnValue(true);
  });

  it("stores a valid submission and notifies the owner", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    const result = await caller.contact.submit({
      name: "Jane Smith",
      email: "jane@example.com",
      phone: "(555) 123-4567",
      service: "Bookkeeping",
      message: "Looking for monthly bookkeeping support.",
    });

    expect(result).toEqual({ success: true });
    expect(createContactSubmission).toHaveBeenCalledWith({
      name: "Jane Smith",
      email: "jane@example.com",
      phone: "(555) 123-4567",
      service: "Bookkeeping",
      message: "Looking for monthly bookkeeping support.",
    });
    expect(notifyOwner).toHaveBeenCalledTimes(1);
  });

  it("accepts submissions without optional phone and message", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    const result = await caller.contact.submit({
      name: "John Doe",
      email: "john@example.com",
      phone: "",
      service: "Payroll Processing",
      message: "",
    });

    expect(result).toEqual({ success: true });
    expect(createContactSubmission).toHaveBeenCalledWith(
      expect.objectContaining({ phone: null, message: null }),
    );
  });

  it("rejects an invalid email", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    await expect(
      caller.contact.submit({
        name: "Jane Smith",
        email: "not-an-email",
        service: "Bookkeeping",
      }),
    ).rejects.toThrow();
    expect(createContactSubmission).not.toHaveBeenCalled();
  });

  it("rejects a missing name", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    await expect(
      caller.contact.submit({
        name: "",
        email: "jane@example.com",
        service: "Bookkeeping",
      }),
    ).rejects.toThrow();
  });

  it("still succeeds when the owner notification fails", async () => {
    notifyOwner.mockRejectedValueOnce(new Error("notification service down"));
    const caller = appRouter.createCaller(createPublicContext());

    const result = await caller.contact.submit({
      name: "Jane Smith",
      email: "jane@example.com",
      service: "Tax Preparation",
    });

    expect(result).toEqual({ success: true });
    expect(createContactSubmission).toHaveBeenCalledTimes(1);
  });

  it("creates a Zoho CRM lead and records the sync status", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    const result = await caller.contact.submit({
      name: "Jane Smith",
      email: "jane@example.com",
      phone: "(555) 123-4567",
      service: "Bookkeeping",
      message: "Monthly support needed.",
    });

    expect(result).toEqual({ success: true });
    expect(createZohoLead).toHaveBeenCalledWith({
      name: "Jane Smith",
      email: "jane@example.com",
      phone: "(555) 123-4567",
      service: "Bookkeeping",
      message: "Monthly support needed.",
    });
    expect(updateContactZohoSync).toHaveBeenCalledWith(42, "synced", "9990001112223334445");
  });

  it("still succeeds and marks the sync failed when Zoho errors", async () => {
    createZohoLead.mockRejectedValueOnce(new Error("zoho down"));
    const caller = appRouter.createCaller(createPublicContext());

    const result = await caller.contact.submit({
      name: "John Doe",
      email: "john@example.com",
      service: "Payroll Processing",
    });

    expect(result).toEqual({ success: true });
    expect(updateContactZohoSync).toHaveBeenCalledWith(42, "failed", null);
    expect(notifyOwner).toHaveBeenCalledTimes(1);
  });

  it("skips Zoho entirely when credentials are not configured", async () => {
    isZohoConfigured.mockReturnValue(false);
    const caller = appRouter.createCaller(createPublicContext());

    const result = await caller.contact.submit({
      name: "Jane Smith",
      email: "jane@example.com",
      service: "Tax Preparation",
    });

    expect(result).toEqual({ success: true });
    expect(createZohoLead).not.toHaveBeenCalled();
    expect(updateContactZohoSync).not.toHaveBeenCalled();
  });
});
