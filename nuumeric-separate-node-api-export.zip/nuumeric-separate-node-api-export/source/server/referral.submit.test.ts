import { describe, expect, it, vi, beforeEach } from "vitest";

// Mock db helpers and integrations before importing the router.
vi.mock("./db", () => ({
  createContactSubmission: vi.fn(),
  createReferralSubmission: vi.fn().mockResolvedValue(42),
  updateContactZohoSync: vi.fn(),
  updateReferralZohoSync: vi.fn(),
  listBlockedPhrases: vi.fn().mockResolvedValue([]),
  createFilteredSubmission: vi.fn().mockResolvedValue(1),
}));

vi.mock("./zoho", () => ({
  isZohoConfigured: vi.fn().mockReturnValue(false),
  createZohoLead: vi.fn(),
}));

vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(undefined),
}));

import { appRouter } from "./routers";
import { createReferralSubmission, updateReferralZohoSync } from "./db";
import { createZohoLead, isZohoConfigured } from "./zoho";
import { notifyOwner } from "./_core/notification";

function createCaller() {
  return appRouter.createCaller({
    req: {} as never,
    res: {} as never,
    user: null,
  } as never);
}

const validInput = {
  referrerName: "Jane Smith",
  referrerEmail: "jane@company.com",
  referrerPhone: "",
  referredBusiness: "Acme Dental",
  referredContact: "John Doe",
  referredEmail: "john@acmedental.com",
  referredPhone: "(555) 987-6543",
  notes: "Needs bookkeeping help",
};

describe("referral.submit", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(createReferralSubmission).mockResolvedValue(42);
    vi.mocked(isZohoConfigured).mockReturnValue(false);
  });

  it("stores a valid referral and notifies the owner", async () => {
    const caller = createCaller();
    const result = await caller.referral.submit(validInput);

    expect(result).toEqual({ success: true });
    expect(createReferralSubmission).toHaveBeenCalledWith({
      referrerName: "Jane Smith",
      referrerEmail: "jane@company.com",
      referrerPhone: null,
      referredBusiness: "Acme Dental",
      referredContact: "John Doe",
      referredEmail: "john@acmedental.com",
      referredPhone: "(555) 987-6543",
      notes: "Needs bookkeeping help",
    });
    expect(notifyOwner).toHaveBeenCalledOnce();
    const notification = vi.mocked(notifyOwner).mock.calls[0][0];
    expect(notification.title).toContain("Jane Smith");
    expect(notification.title).toContain("Acme Dental");
    expect(notification.content).toContain("$100 credit");
  });

  it("rejects a missing referrer name", async () => {
    const caller = createCaller();
    await expect(
      caller.referral.submit({ ...validInput, referrerName: "" }),
    ).rejects.toThrow();
  });

  it("rejects an invalid referrer email", async () => {
    const caller = createCaller();
    await expect(
      caller.referral.submit({ ...validInput, referrerEmail: "not-an-email" }),
    ).rejects.toThrow();
  });

  it("rejects a missing referred business name", async () => {
    const caller = createCaller();
    await expect(
      caller.referral.submit({ ...validInput, referredBusiness: "" }),
    ).rejects.toThrow();
  });

  it("accepts optional fields left empty", async () => {
    const caller = createCaller();
    const result = await caller.referral.submit({
      referrerName: "Jane Smith",
      referrerEmail: "jane@company.com",
      referrerPhone: "",
      referredBusiness: "Acme Dental",
      referredContact: "",
      referredEmail: "",
      referredPhone: "",
      notes: "",
    });
    expect(result).toEqual({ success: true });
    expect(createReferralSubmission).toHaveBeenCalledWith(
      expect.objectContaining({
        referredContact: null,
        referredEmail: null,
        referredPhone: null,
        notes: null,
      }),
    );
  });

  it("creates a Zoho lead when configured and referred email present", async () => {
    vi.mocked(isZohoConfigured).mockReturnValue(true);
    vi.mocked(createZohoLead).mockResolvedValue("zoho-lead-123");

    const caller = createCaller();
    await caller.referral.submit(validInput);

    expect(createZohoLead).toHaveBeenCalledOnce();
    const leadInput = vi.mocked(createZohoLead).mock.calls[0][0];
    expect(leadInput.email).toBe("john@acmedental.com");
    expect(leadInput.service).toBe("Client Referral");
    expect(leadInput.message).toContain("Referred by: Jane Smith");
    expect(updateReferralZohoSync).toHaveBeenCalledWith(42, "synced", "zoho-lead-123");
  });

  it("skips Zoho when no referred email is provided", async () => {
    vi.mocked(isZohoConfigured).mockReturnValue(true);

    const caller = createCaller();
    await caller.referral.submit({ ...validInput, referredEmail: "" });

    expect(createZohoLead).not.toHaveBeenCalled();
  });

  it("still succeeds when Zoho lead creation fails", async () => {
    vi.mocked(isZohoConfigured).mockReturnValue(true);
    vi.mocked(createZohoLead).mockRejectedValue(new Error("Zoho down"));

    const caller = createCaller();
    const result = await caller.referral.submit(validInput);

    expect(result).toEqual({ success: true });
    expect(updateReferralZohoSync).toHaveBeenCalledWith(42, "failed", null);
  });
});
