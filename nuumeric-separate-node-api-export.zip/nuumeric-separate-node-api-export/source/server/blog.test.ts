import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { slugify } from "./routers/blog";
import type { TrpcContext } from "./_core/context";

function makeCtx(role: "admin" | "user" | null): TrpcContext {
  return {
    user: role
      ? ({
          id: 1,
          openId: "test-open-id",
          name: "Test User",
          email: "test@example.com",
          loginMethod: "test",
          role,
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: new Date(),
        } as TrpcContext["user"])
      : null,
    req: { headers: {} } as TrpcContext["req"],
    res: {
      cookie: () => undefined,
      clearCookie: () => undefined,
    } as unknown as TrpcContext["res"],
  };
}

describe("slugify", () => {
  it("converts titles to url-safe slugs", () => {
    expect(slugify("Zoho Books vs. Xero: Which One?")).toBe("zoho-books-vs-xero-which-one");
    expect(slugify("  What's a Bookkeeper Worth?  ")).toBe("whats-a-bookkeeper-worth");
    expect(slugify("Émigré — café & crème")).toBe("migr-caf-cr-me");
  });

  it("caps slug length at 190 chars", () => {
    expect(slugify("a".repeat(400)).length).toBeLessThanOrEqual(190);
  });

  it("returns empty string for symbol-only input", () => {
    expect(slugify("!!!")).toBe("");
  });
});

describe("blog router access control", () => {
  it("rejects anonymous users from admin.list", async () => {
    const caller = appRouter.createCaller(makeCtx(null));
    await expect(caller.blog.admin.list()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("rejects non-admin users from admin.create", async () => {
    const caller = appRouter.createCaller(makeCtx("user"));
    await expect(
      caller.blog.admin.create({ title: "Test", content: "Body" }),
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects non-admin users from admin.setStatus and admin.delete", async () => {
    const caller = appRouter.createCaller(makeCtx("user"));
    await expect(
      caller.blog.admin.setStatus({ id: 1, status: "published" }),
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.blog.admin.delete({ id: 1 })).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });
});

describe("blog publish flow (integration, requires DATABASE_URL)", () => {
  const hasDb = Boolean(process.env.DATABASE_URL);
  const itDb = hasDb ? it : it.skip;

  itDb("creates a draft, keeps it private, publishes it, then cleans up", async () => {
    const admin = appRouter.createCaller(makeCtx("admin"));
    const anon = appRouter.createCaller(makeCtx(null));

    const title = `Vitest Post ${Date.now()}`;
    const { id, slug } = await admin.blog.admin.create({
      title,
      content: "# Hello\n\nThis is a **test** post.",
      excerpt: "Test excerpt",
      category: "Testing",
      tags: "vitest, ci",
    });

    try {
      // Draft must NOT be publicly visible.
      await expect(anon.blog.getBySlug({ slug })).rejects.toMatchObject({
        code: "NOT_FOUND",
      });
      const publicList = await anon.blog.list();
      expect(publicList.some(p => p.slug === slug)).toBe(false);

      // Publish → now public with publishedAt set.
      await admin.blog.admin.setStatus({ id, status: "published" });
      const post = await anon.blog.getBySlug({ slug });
      expect(post.title).toBe(title);
      expect(post.publishedAt).toBeInstanceOf(Date);

      // Slug uniqueness: same title gets a suffixed slug.
      const dup = await admin.blog.admin.create({ title, content: "Second body" });
      expect(dup.slug).not.toBe(slug);
      expect(dup.slug.startsWith(slug.slice(0, 20))).toBe(true);
      await admin.blog.admin.delete({ id: dup.id });
    } finally {
      await admin.blog.admin.delete({ id });
    }

    // Deleted → gone from public reads.
    await expect(anon.blog.getBySlug({ slug })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  }, 30_000);
});
