import express, { type Express } from "express";
import fs from "fs";
import { type Server } from "http";
import path from "path";
import superjson from "superjson";
import { createServer as createViteServer } from "vite";
import viteConfig from "../../vite.config";
import type { HeadMeta } from "../../client/src/ssr/prefetch";
import { buildSsrPrefetch } from "./ssrCaller";

const SITE_NAME = process.env.SITE_NAME || "Nuumeric Inc";
const OG_LOCALE = process.env.OG_LOCALE || "en_US";
const DEFAULT_TITLE = "Nuumeric Inc — Expert Solutions for Growing Enterprises";
const DEFAULT_DESCRIPTION =
  "US-based bookkeeping, business and individual tax preparation, and payroll for growing enterprises. Nuumeric — expert back-office support in Charlotte, NC.";

function canonicalOrigin(): string {
  return (process.env.CANONICAL_ORIGIN || "https://www.nuumeric.com").replace(/\/+$/, "");
}

const esc = (s: string) =>
  s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

function buildHeadTags(head: HeadMeta): string {
  const origin = canonicalOrigin();
  const tags: string[] = [];
  tags.push(`<title>${esc(head.title)}</title>`);
  tags.push(`<meta name="description" content="${esc(head.description)}" />`);
  tags.push(
    `<meta name="keywords" content="bookkeeping services, tax preparation, individual tax returns, payroll processing, QuickBooks ProAdvisor, Xero advisor, Zoho CRM support, US back-office support" />`
  );
  if (head.noindex || head.notFound) {
    tags.push(`<meta name="robots" content="noindex" />`);
  } else if (head.canonicalPath) {
    tags.push(`<link rel="canonical" href="${origin}${esc(head.canonicalPath)}" />`);
  }
  tags.push(`<meta property="og:site_name" content="${esc(SITE_NAME)}" />`);
  tags.push(`<meta property="og:locale" content="${OG_LOCALE}" />`);
  tags.push(`<meta property="og:type" content="${head.ogType ?? "website"}" />`);
  tags.push(`<meta property="og:title" content="${esc(head.title)}" />`);
  tags.push(`<meta property="og:description" content="${esc(head.description)}" />`);
  if (head.canonicalPath && !head.noindex && !head.notFound) {
    tags.push(`<meta property="og:url" content="${origin}${esc(head.canonicalPath)}" />`);
  }
  if (head.ogImage) {
    const absImg = head.ogImage.startsWith("http")
      ? head.ogImage
      : `${origin}${head.ogImage}`;
    tags.push(`<meta property="og:image" content="${esc(absImg)}" />`);
    if (head.ogImageAlt)
      tags.push(`<meta property="og:image:alt" content="${esc(head.ogImageAlt)}" />`);
    tags.push(`<meta name="twitter:card" content="summary_large_image" />`);
    tags.push(`<meta name="twitter:image" content="${esc(absImg)}" />`);
  } else {
    tags.push(`<meta name="twitter:card" content="summary" />`);
  }
  if (head.ogType === "article") {
    if (head.publishedTime)
      tags.push(`<meta property="article:published_time" content="${head.publishedTime}" />`);
    if (head.modifiedTime)
      tags.push(`<meta property="article:modified_time" content="${head.modifiedTime}" />`);
  }
  tags.push(`<meta name="twitter:title" content="${esc(head.title)}" />`);
  tags.push(`<meta name="twitter:description" content="${esc(head.description)}" />`);
  return tags.join("\n    ");
}

type Rendered = { html: string; dehydratedState: unknown; head: HeadMeta };
type RenderFn = (url: string, prefetch: unknown) => Promise<Rendered>;

function composeHtml(template: string, rendered: Rendered): string {
  const headTags = buildHeadTags(rendered.head);
  // superjson keeps Dates intact through hydration; escape "<" so user-authored
  // content in the dehydrated state cannot break out of the script tag.
  const stateJson = JSON.stringify(superjson.serialize(rendered.dehydratedState)).replace(
    /</g,
    "\\u003c"
  );
  return template
    .replace("<!--app-head-->", headTags)
    .replace("<!--app-html-->", rendered.html)
    .replace(
      '<div id="root">',
      `<script>window.__RQ_STATE__ = ${stateJson};</script>\n    <div id="root">`
    );
}

/** Fallback shell when SSR rendering throws: the SPA still boots client-side. */
function composeShell(template: string): string {
  const headTags = buildHeadTags({
    title: DEFAULT_TITLE,
    description: DEFAULT_DESCRIPTION,
  });
  return template.replace("<!--app-head-->", headTags).replace("<!--app-html-->", "");
}

export async function setupVite(app: Express, server: Server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true as const,
  };

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    server: serverOptions,
    appType: "custom",
  });

  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;

    try {
      const clientTemplate = path.resolve(
        import.meta.dirname,
        "../..",
        "client",
        "index.html"
      );

      // always reload the index.html file from disk incase it changes
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = await vite.transformIndexHtml(url, template);
      try {
        const mod = (await vite.ssrLoadModule("/src/entry-server.tsx")) as {
          render: RenderFn;
        };
        const prefetch = await buildSsrPrefetch(req as never, res as never);
        const rendered = await mod.render(url, prefetch);
        const status = rendered.head.notFound ? 404 : 200;
        res
          .status(status)
          .set({ "Content-Type": "text/html" })
          .end(composeHtml(template, rendered));
      } catch (ssrError) {
        // SSR failure must never take the site down: serve the CSR shell.
        vite.ssrFixStacktrace(ssrError as Error);
        console.error("[SSR] dev render failed, serving CSR shell:", ssrError);
        res.status(200).set({ "Content-Type": "text/html" }).end(composeShell(template));
      }
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
}

export function serveStatic(app: Express) {
  const distPath =
    process.env.NODE_ENV === "development"
      ? path.resolve(import.meta.dirname, "../..", "dist", "public")
      : path.resolve(import.meta.dirname, "public");
  const ssrEntryPath =
    process.env.NODE_ENV === "development"
      ? path.resolve(import.meta.dirname, "../..", "dist", "server-ssr", "entry-server.js")
      : path.resolve(import.meta.dirname, "server-ssr", "entry-server.js");
  if (!fs.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }

  // Static assets first — index:false so "/" falls through to the SSR handler.
  app.use(express.static(distPath, { index: false }));

  const template = fs.readFileSync(path.resolve(distPath, "index.html"), "utf-8");
  let renderPromise: Promise<{ render: RenderFn }> | null = null;
  const loadRenderer = () => {
    renderPromise ??= import(ssrEntryPath) as Promise<{ render: RenderFn }>;
    return renderPromise;
  };

  app.use("*", async (req, res) => {
    try {
      const { render } = await loadRenderer();
      const prefetch = await buildSsrPrefetch(req as never, res as never);
      const rendered = await render(req.originalUrl, prefetch);
      const status = rendered.head.notFound ? 404 : 200;
      res
        .status(status)
        .set({ "Content-Type": "text/html" })
        .end(composeHtml(template, rendered));
    } catch (e) {
      console.error("[SSR] prod render failed, serving CSR shell:", e);
      res.status(200).set({ "Content-Type": "text/html" }).end(composeShell(template));
    }
  });
}
