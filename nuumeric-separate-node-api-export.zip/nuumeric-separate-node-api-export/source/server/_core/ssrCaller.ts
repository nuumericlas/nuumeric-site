import type { Request, Response } from "express";
import { appRouter } from "../routers";
import { createContext } from "./context";
import type { SsrPrefetch } from "../../client/src/ssr/prefetch";

/**
 * In-process tRPC caller for SSR prefetch. Only viewer-independent public
 * procedures are exposed (blog list + article by slug).
 */
export async function buildSsrPrefetch(req: Request, res: Response): Promise<SsrPrefetch> {
  const ctx = await createContext({ req, res } as never);
  const caller = appRouter.createCaller(ctx);
  return {
    blogList: () => caller.blog.list(),
    blogBySlug: (slug: string) => caller.blog.getBySlug({ slug }),
  };
}
