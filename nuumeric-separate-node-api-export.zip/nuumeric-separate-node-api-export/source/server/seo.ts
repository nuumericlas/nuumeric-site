import type { Express, Request, Response } from "express";
import { listPublishedPosts } from "./db";

const ORIGIN = (process.env.CANONICAL_ORIGIN || "https://www.nuumeric.com").replace(/\/+$/, "");

/** Static public routes included in the sitemap (path, priority, changefreq). */
const STATIC_SITEMAP_ROUTES: Array<{ path: string; priority: string; changefreq: string }> = [
  { path: "/", priority: "1.0", changefreq: "monthly" },
  { path: "/services", priority: "0.9", changefreq: "monthly" },
  { path: "/about", priority: "0.8", changefreq: "monthly" },
  { path: "/what-to-expect", priority: "0.7", changefreq: "monthly" },
  { path: "/careers", priority: "0.5", changefreq: "monthly" },
  { path: "/blog", priority: "0.8", changefreq: "weekly" },
  { path: "/contact", priority: "0.8", changefreq: "monthly" },
  { path: "/refer", priority: "0.7", changefreq: "monthly" },
  { path: "/privacy-policy", priority: "0.3", changefreq: "yearly" },
  { path: "/terms-and-conditions", priority: "0.3", changefreq: "yearly" },
  { path: "/cookie-policy", priority: "0.3", changefreq: "yearly" },
];

function iso(d: Date | string | null | undefined): string {
  const date = d ? new Date(d) : new Date();
  return date.toISOString().slice(0, 10);
}

/**
 * Dynamic sitemap: static routes plus every published blog post with a real
 * lastmod. Cached for 10 minutes to keep DB load negligible under crawlers.
 */
let sitemapCache: { xml: string; at: number } | null = null;
const SITEMAP_TTL_MS = 10 * 60 * 1000;

async function buildSitemap(): Promise<string> {
  const now = Date.now();
  if (sitemapCache && now - sitemapCache.at < SITEMAP_TTL_MS) return sitemapCache.xml;
  let posts: Awaited<ReturnType<typeof listPublishedPosts>> = [];
  try {
    posts = await listPublishedPosts();
  } catch (e) {
    console.error("[sitemap] failed to list posts, serving static routes only:", e);
  }
  const today = iso(new Date());
  const urls: string[] = [];
  for (const r of STATIC_SITEMAP_ROUTES) {
    urls.push(
      `  <url>\n    <loc>${ORIGIN}${r.path}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>${r.changefreq}</changefreq>\n    <priority>${r.priority}</priority>\n  </url>`
    );
  }
  for (const p of posts) {
    const lastmod = iso((p as { updatedAt?: Date }).updatedAt ?? p.publishedAt);
    urls.push(
      `  <url>\n    <loc>${ORIGIN}/blog/${encodeURI(p.slug)}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>yearly</changefreq>\n    <priority>0.6</priority>\n  </url>`
    );
  }
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join("\n")}\n</urlset>\n`;
  sitemapCache = { xml, at: now };
  return xml;
}

/**
 * Register SEO/AI-crawler routes. MUST be called BEFORE the SSR catch-all so
 * /sitemap.xml, /robots.txt, and /llms.txt are served as real documents.
 */
export function registerSeoRoutes(app: Express) {
  app.get("/sitemap.xml", async (_req: Request, res: Response) => {
    const xml = await buildSitemap();
    res.set("Content-Type", "application/xml").send(xml);
  });
}
