import { describe, expect, it } from "vitest";

/**
 * Validates the Zoho SalesIQ widget code by fetching the widget bootstrap
 * script from Zoho's CDN endpoint, exactly as the browser embed does.
 * A valid widget code returns a JavaScript payload; an invalid one returns
 * an error page or empty body.
 */
describe("zoho salesiq widget code (live)", () => {
  const widgetCode = process.env.VITE_ZOHO_SALESIQ_WIDGET_CODE;

  it("is configured", () => {
    expect(widgetCode, "VITE_ZOHO_SALESIQ_WIDGET_CODE must be set").toBeTruthy();
    expect(widgetCode).toMatch(/^siq[0-9a-f]/i);
    expect(widgetCode).not.toMatch(/\s/);
  });

  it("resolves to a valid widget script on Zoho's servers", async () => {
    const res = await fetch(
      `https://salesiq.zoho.com/widget?wc=${widgetCode}`,
      { redirect: "follow" },
    );
    expect(res.ok).toBe(true);
    const body = await res.text();
    // A valid widget code returns the SalesIQ loader JavaScript.
    expect(body.length).toBeGreaterThan(500);
    expect(body.toLowerCase()).not.toContain("<html");
  }, 30000);
});
