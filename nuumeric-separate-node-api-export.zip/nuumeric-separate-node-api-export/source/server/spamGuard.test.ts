import { beforeEach, describe, expect, it } from "vitest";
import {
  checkContent,
  checkHoneypotAndTiming,
  checkRateLimit,
  clientIpFrom,
  resetRateLimits,
  screenSubmission,
  MIN_FILL_MS,
  RATE_LIMIT_MAX,
} from "./spamGuard";
import { isBlockedUserAgent } from "./botBlocker";

beforeEach(() => {
  resetRateLimits();
});

describe("honeypot and timing", () => {
  it("accepts an empty honeypot with plausible fill time", () => {
    const now = 1_000_000;
    expect(
      checkHoneypotAndTiming({ hp: "", formLoadedAt: now - 30_000, now }),
    ).toEqual({ ok: true });
  });

  it("rejects a filled honeypot", () => {
    const result = checkHoneypotAndTiming({ hp: "http://spam.example", formLoadedAt: 0 });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.reason).toBe("honeypot");
  });

  it("rejects submissions faster than a human could type", () => {
    const now = 1_000_000;
    const result = checkHoneypotAndTiming({
      hp: "",
      formLoadedAt: now - (MIN_FILL_MS - 500),
      now,
    });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.reason).toBe("too-fast");
  });

  it("rejects timestamps from the future", () => {
    const now = 1_000_000;
    const result = checkHoneypotAndTiming({ hp: "", formLoadedAt: now + 60_000, now });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.reason).toBe("timestamp-skew");
  });

  it("tolerates a page left open for a long time", () => {
    const now = 1_000_000_000;
    expect(
      checkHoneypotAndTiming({ hp: "", formLoadedAt: now - 1000 * 60 * 60 * 24, now }),
    ).toEqual({ ok: true });
  });

  it("accepts a missing timestamp (older cached client)", () => {
    expect(checkHoneypotAndTiming({ hp: "" })).toEqual({ ok: true });
  });
});

describe("rate limiting", () => {
  it("allows submissions up to the cap then blocks", () => {
    const now = 5_000_000;
    for (let i = 0; i < RATE_LIMIT_MAX; i++) {
      expect(checkRateLimit("203.0.113.10", now + i).ok).toBe(true);
    }
    const blocked = checkRateLimit("203.0.113.10", now + RATE_LIMIT_MAX);
    expect(blocked.ok).toBe(false);
    if (!blocked.ok) expect(blocked.reason).toBe("rate-limited");
  });

  it("tracks each IP independently", () => {
    const now = 5_000_000;
    for (let i = 0; i < RATE_LIMIT_MAX; i++) checkRateLimit("198.51.100.1", now + i);
    expect(checkRateLimit("198.51.100.2", now).ok).toBe(true);
  });

  it("forgets submissions once the window passes", () => {
    const now = 5_000_000;
    for (let i = 0; i < RATE_LIMIT_MAX; i++) checkRateLimit("198.51.100.7", now + i);
    const later = now + 1000 * 60 * 61;
    expect(checkRateLimit("198.51.100.7", later).ok).toBe(true);
  });

  it("skips limiting when no IP is available", () => {
    expect(checkRateLimit("").ok).toBe(true);
  });
});

describe("client IP extraction", () => {
  it("uses the first entry of x-forwarded-for", () => {
    expect(
      clientIpFrom({ "x-forwarded-for": "203.0.113.5, 70.41.3.18" }),
    ).toBe("203.0.113.5");
  });

  it("falls back to x-real-ip then the socket address", () => {
    expect(clientIpFrom({ "x-real-ip": "203.0.113.9" })).toBe("203.0.113.9");
    expect(clientIpFrom({}, "10.0.0.4")).toBe("10.0.0.4");
  });
});

describe("content heuristics", () => {
  it("accepts an ordinary inquiry", () => {
    expect(
      checkContent([
        "Jane Smith",
        "We're a two-location dental practice and need monthly bookkeeping plus payroll for 12 staff.",
      ]),
    ).toEqual({ ok: true });
  });

  it("accepts a message containing one legitimate link", () => {
    expect(
      checkContent(["Our site is https://acmedental.com if that helps."]),
    ).toEqual({ ok: true });
  });

  it("rejects link-stuffed payloads", () => {
    const result = checkContent([
      "Visit http://a.example and http://b.example and www.c.example",
    ]);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.reason).toBe("too-many-links");
  });

  it("rejects classic SEO/backlink spam", () => {
    const result = checkContent(["We offer cheap SEO services and backlink packages."]);
    expect(result.ok).toBe(false);
  });

  it("rejects all-caps shouting", () => {
    const result = checkContent(["MAKE MONEY FAST WITH OUR AMAZING PROGRAM TODAY"]);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.reason).toBe("shouting");
  });

  it("does not penalise non-Latin text on its own", () => {
    expect(checkContent(["Necesitamos ayuda con la contabilidad mensual."])).toEqual({
      ok: true,
    });
  });

  it("accepts empty optional text", () => {
    expect(checkContent([null, undefined, ""])).toEqual({ ok: true });
  });
});

describe("screenSubmission", () => {
  it("passes a realistic human submission", () => {
    const now = 9_000_000;
    expect(
      screenSubmission({
        ip: "203.0.113.44",
        hp: "",
        formLoadedAt: now - 45_000,
        textParts: ["Jane Smith", "Looking for help with quarterly taxes."],
        now,
      }),
    ).toEqual({ ok: true });
  });

  it("blocks a bot that fills the honeypot", () => {
    const result = screenSubmission({
      ip: "203.0.113.45",
      hp: "spam",
      formLoadedAt: 0,
      textParts: ["Bot"],
    });
    expect(result.ok).toBe(false);
  });
});

describe("hostile user-agent blocking", () => {
  it("blocks known harvesters and scrapers", () => {
    for (const ua of [
      "EmailSiphon",
      "Mozilla/5.0 (compatible; SemrushBot/7~bl)",
      "Wget/1.21.3",
      "HTTrack 3.0",
      "Mozilla/5.0 (compatible; AhrefsBot/7.0)",
    ]) {
      expect(isBlockedUserAgent(ua)).toBe(true);
    }
  });

  it("allows real browsers, search engines, and AI crawlers", () => {
    for (const ua of [
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
      "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Version/17.0 Mobile/15E148 Safari/604.1",
      "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
      "Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)",
      "Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; GPTBot/1.2; +https://openai.com/gptbot",
      "Mozilla/5.0 (compatible; ClaudeBot/1.0; +claudebot@anthropic.com)",
      "Mozilla/5.0 (compatible; PerplexityBot/1.0; +https://perplexity.ai/perplexitybot)",
    ]) {
      expect(isBlockedUserAgent(ua)).toBe(false);
    }
  });

  it("allows requests with no user-agent rather than guessing", () => {
    expect(isBlockedUserAgent(undefined)).toBe(false);
    expect(isBlockedUserAgent("")).toBe(false);
  });
});
