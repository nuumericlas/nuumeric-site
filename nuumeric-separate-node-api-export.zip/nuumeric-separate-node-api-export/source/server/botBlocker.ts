import type { Express, NextFunction, Request, Response } from "express";

/**
 * User-agent substrings belonging to email harvesters and aggressive content
 * scrapers. These tools ignore robots.txt, so they are refused at the server.
 *
 * Deliberately excludes search engines and AI answer crawlers (Googlebot,
 * Bingbot, GPTBot, ClaudeBot, PerplexityBot, ...) — those are wanted traffic.
 */
const BLOCKED_UA_PATTERNS = [
  "emailcollector",
  "emailsiphon",
  "emailwolf",
  "extractorpro",
  "webemailextrac",
  "cherrypicker",
  "nicerspro",
  "collector",
  "harvest",
  "grabber",
  "sitesnagger",
  "webbandit",
  "webcopier",
  "webstripper",
  "webzip",
  "httrack",
  "teleport",
  "wget",
  "libwww-perl",
  "zgrab",
  "masscan",
  "semrushbot",
  "ahrefsbot",
  "mj12bot",
  "dotbot",
  "blexbot",
  "petalbot",
  "serpstatbot",
];

export function isBlockedUserAgent(userAgent: string | undefined): boolean {
  if (!userAgent || userAgent.trim() === "") return false;
  const ua = userAgent.toLowerCase();
  return BLOCKED_UA_PATTERNS.some(pattern => ua.includes(pattern));
}

/**
 * Blocks harvester traffic before it reaches page rendering. Never applied to
 * /api/ routes (the app's own client sends no such user-agents) so a false
 * positive can't break site functionality for real visitors.
 */
export function registerBotBlocker(app: Express) {
  app.use((req: Request, res: Response, next: NextFunction) => {
    if (isBlockedUserAgent(req.headers["user-agent"])) {
      res.status(403).type("text/plain").send("Access denied.");
      return;
    }
    next();
  });
}
