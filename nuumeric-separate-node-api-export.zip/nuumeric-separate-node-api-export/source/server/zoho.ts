/**
 * Zoho CRM integration — creates Leads from quote form submissions.
 *
 * Uses the OAuth 2.0 "Self Client" refresh-token flow:
 * the refresh token (never expires) is exchanged for a 1-hour access
 * token on demand, cached in memory, and refreshed automatically.
 */

const ZOHO_ACCOUNTS_URL = (process.env.ZOHO_ACCOUNTS_URL || "https://accounts.zoho.com").replace(/\/+$/, "");

type TokenCache = {
  accessToken: string;
  apiDomain: string;
  expiresAt: number; // epoch ms
};

let tokenCache: TokenCache | null = null;

export function isZohoConfigured(): boolean {
  return Boolean(
    process.env.ZOHO_CLIENT_ID &&
      process.env.ZOHO_CLIENT_SECRET &&
      process.env.ZOHO_REFRESH_TOKEN,
  );
}

/** For tests: clear the in-memory token cache. */
export function _clearTokenCache() {
  tokenCache = null;
}

export async function getZohoAccessToken(): Promise<TokenCache> {
  if (tokenCache && Date.now() < tokenCache.expiresAt - 60_000) {
    return tokenCache;
  }
  if (!isZohoConfigured()) {
    throw new Error("Zoho CRM credentials are not configured");
  }
  const params = new URLSearchParams({
    refresh_token: process.env.ZOHO_REFRESH_TOKEN!,
    client_id: process.env.ZOHO_CLIENT_ID!,
    client_secret: process.env.ZOHO_CLIENT_SECRET!,
    grant_type: "refresh_token",
  });
  const res = await fetch(`${ZOHO_ACCOUNTS_URL}/oauth/v2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });
  const json = (await res.json()) as {
    access_token?: string;
    api_domain?: string;
    expires_in?: number;
    error?: string;
  };
  if (!res.ok || !json.access_token) {
    throw new Error(`Zoho token refresh failed: ${json.error || res.statusText}`);
  }
  tokenCache = {
    accessToken: json.access_token,
    apiDomain: json.api_domain || "https://www.zohoapis.com",
    expiresAt: Date.now() + (json.expires_in ?? 3600) * 1000,
  };
  return tokenCache;
}

export type QuoteLeadInput = {
  name: string;
  email: string;
  phone?: string | null;
  service: string;
  message?: string | null;
};

/** Split a full name into Zoho First_Name / Last_Name (Last_Name is mandatory). */
export function splitName(fullName: string): { firstName: string; lastName: string } {
  const parts = fullName.trim().split(/\s+/);
  if (parts.length <= 1) {
    return { firstName: "", lastName: parts[0] || "Unknown" };
  }
  return {
    firstName: parts.slice(0, -1).join(" "),
    lastName: parts[parts.length - 1],
  };
}

/** Build the Zoho Leads payload from a quote form submission. */
export function buildLeadPayload(input: QuoteLeadInput) {
  const { firstName, lastName } = splitName(input.name);
  const description = [
    `Service needed: ${input.service}`,
    input.message?.trim() ? `Message: ${input.message.trim()}` : null,
  ]
    .filter(Boolean)
    .join("\n\n");
  return {
    data: [
      {
        Last_Name: lastName,
        ...(firstName ? { First_Name: firstName } : {}),
        Email: input.email,
        ...(input.phone?.trim() ? { Phone: input.phone.trim() } : {}),
        Company: input.name, // Zoho Leads convention: Company is often required in UI; use name as placeholder
        Description: description,
        Lead_Source: "Website",
      },
    ],
    trigger: ["workflow"],
  };
}

/**
 * Create a Lead in Zoho CRM. Returns the new lead ID.
 * Throws on failure — callers should treat Zoho errors as non-fatal.
 * Uses the upsert endpoint with Email as the duplicate-check field so a
 * repeat inquiry from the same address updates the existing lead instead
 * of failing with DUPLICATE_DATA.
 */
export async function createZohoLead(input: QuoteLeadInput): Promise<string> {
  const { accessToken, apiDomain } = await getZohoAccessToken();
  const payload = {
    ...buildLeadPayload(input),
    duplicate_check_fields: ["Email"],
  };
  const res = await fetch(`${apiDomain}/crm/v8/Leads/upsert`, {
    method: "POST",
    headers: {
      Authorization: `Zoho-oauthtoken ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
  const json = (await res.json()) as {
    data?: Array<{
      code: string;
      details?: { id?: string; errors?: unknown };
      message?: string;
    }>;
  };
  const first = json.data?.[0];
  if (!res.ok || !first || first.code !== "SUCCESS" || !first.details?.id) {
    throw new Error(
      `Zoho lead creation failed: ${first?.code || res.status} ${first?.message || ""} ${
        first?.details ? JSON.stringify(first.details) : ""
      }`.trim(),
    );
  }
  return first.details.id;
}
