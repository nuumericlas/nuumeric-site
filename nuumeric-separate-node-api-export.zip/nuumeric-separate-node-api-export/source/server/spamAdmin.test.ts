import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  DEFAULT_SPAM_PHRASES,
  PHRASE_CACHE_TTL_MS,
  checkContent,
  invalidatePhraseCache,
  loadSpamPhrases,
} from "./spamGuard";
import { contactInputSchema, referralInputSchema } from "./submissions";

describe("admin-managed phrase list", () => {
  beforeEach(() => {
    invalidatePhraseCache();
  });

  it("screens against the database list, not the built-in defaults", async () => {
    const loader = vi.fn().mockResolvedValue([{ phrase: "website audit offer" }]);
    const phrases = await loadSpamPhrases(loader);

    // A custom phrase the owner added is now blocked...
    expect(checkContent(["Free website audit offer inside"], phrases).ok).toBe(false);
    // ...while a default phrase no longer in the DB list is allowed through.
    expect(checkContent(["We need help with backlink accounting"], phrases).ok).toBe(true);
  });

  it("normalises phrases to lowercase and drops blanks", async () => {
    const loader = vi.fn().mockResolvedValue([
      { phrase: "  GUEST Post  " },
      { phrase: "   " },
    ]);
    const phrases = await loadSpamPhrases(loader);

    expect(phrases).toEqual(["guest post"]);
    expect(checkContent(["Interested in a Guest POST?"], phrases).ok).toBe(false);
  });

  it("reports which phrase caused the rejection so the admin screen can show it", async () => {
    const loader = vi.fn().mockResolvedValue([{ phrase: "link building" }]);
    const phrases = await loadSpamPhrases(loader);

    const result = checkContent(["cheap link building packages"], phrases);
    expect(result).toEqual({ ok: false, reason: "phrase:link building" });
  });

  it("caches the list, then reloads after the TTL expires", async () => {
    const loader = vi.fn().mockResolvedValue([{ phrase: "casino" }]);

    await loadSpamPhrases(loader, 1_000);
    await loadSpamPhrases(loader, 1_000 + PHRASE_CACHE_TTL_MS - 1);
    expect(loader).toHaveBeenCalledTimes(1);

    await loadSpamPhrases(loader, 1_000 + PHRASE_CACHE_TTL_MS + 1);
    expect(loader).toHaveBeenCalledTimes(2);
  });

  it("picks up an admin edit immediately once the cache is invalidated", async () => {
    const loader = vi
      .fn()
      .mockResolvedValueOnce([{ phrase: "casino" }])
      .mockResolvedValueOnce([{ phrase: "casino" }, { phrase: "cold call script" }]);

    const before = await loadSpamPhrases(loader, 5_000);
    expect(checkContent(["our cold call script"], before).ok).toBe(true);

    invalidatePhraseCache();
    const after = await loadSpamPhrases(loader, 5_001);
    expect(checkContent(["our cold call script"], after).ok).toBe(false);
  });

  it("falls back to the built-in list if the database is unreachable", async () => {
    const loader = vi.fn().mockRejectedValue(new Error("db down"));
    const phrases = await loadSpamPhrases(loader);

    expect(phrases).toEqual(DEFAULT_SPAM_PHRASES);
    expect(checkContent(["cheap seo services"], phrases).ok).toBe(false);
  });

  it("keeps forms protected rather than failing open on database errors", async () => {
    const loader = vi.fn().mockRejectedValue(new Error("db down"));
    const phrases = await loadSpamPhrases(loader);

    expect(phrases.length).toBeGreaterThan(0);
  });
});

describe("releasing a held submission", () => {
  it("re-parses a stored contact payload back into a deliverable inquiry", () => {
    const stored = JSON.stringify({
      name: "Dana Reed",
      email: "dana@reedbakery.com",
      phone: "585-555-0134",
      company: "Reed Bakery",
      service: "Bookkeeping",
      message: "We rank first on google for cupcakes and need monthly books.",
    });

    const parsed = contactInputSchema.safeParse(JSON.parse(stored));
    expect(parsed.success).toBe(true);
    if (parsed.success) {
      expect(parsed.data.name).toBe("Dana Reed");
      expect(parsed.data.email).toBe("dana@reedbakery.com");
    }
  });

  it("re-parses a stored referral payload back into a deliverable referral", () => {
    const stored = JSON.stringify({
      referrerName: "Sam Ortiz",
      referrerEmail: "sam@ortizhvac.com",
      referredBusiness: "Lakeside Casino Supply",
      referredContact: "Pat Lee",
      referredEmail: "pat@lakesidesupply.com",
    });

    const parsed = referralInputSchema.safeParse(JSON.parse(stored));
    expect(parsed.success).toBe(true);
    if (parsed.success) {
      expect(parsed.data.referredBusiness).toBe("Lakeside Casino Supply");
    }
  });

  it("rejects an unreadable stored payload instead of delivering garbage", () => {
    expect(() => JSON.parse("{not json")).toThrow();
  });

  it("rejects a stored payload missing required fields", () => {
    const parsed = contactInputSchema.safeParse({ name: "No Email Given" });
    expect(parsed.success).toBe(false);
  });
});
