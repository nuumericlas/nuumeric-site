import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({
  listStalePendingSubmissions: vi.fn(),
  markSubmissionsAlerted: vi.fn(),
}));

vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn(),
}));

vi.mock("./_core/sdk", () => ({
  sdk: { authenticateRequest: vi.fn() },
}));

import { notifyOwner } from "./_core/notification";
import { sdk } from "./_core/sdk";
import { listStalePendingSubmissions, markSubmissionsAlerted } from "./db";
import {
  STALE_THRESHOLD_HOURS,
  buildStaleAlert,
  describeWait,
  runStaleReviewCheck,
  staleSpamReviewHandler,
} from "./staleReviewAlert";

const HOUR = 60 * 60 * 1000;

function heldRow(overrides: Record<string, unknown> = {}) {
  return {
    id: 1,
    formType: "contact",
    reason: "phrase:rank #1 on google",
    payload: JSON.stringify({
      name: "Dana Reyes",
      email: "dana@brightpath.com",
      service: "Bookkeeping",
      message: "We want help getting our books current.",
    }),
    createdAt: new Date(Date.now() - 50 * HOUR),
    alertedAt: null,
    ...overrides,
  };
}

function mockRes() {
  const res = {
    statusCode: 200,
    body: undefined as unknown,
    status(code: number) {
      res.statusCode = code;
      return res;
    },
    json(payload: unknown) {
      res.body = payload;
      return res;
    },
  };
  return res;
}

describe("stale review threshold", () => {
  it("flags messages only after 48 hours", () => {
    expect(STALE_THRESHOLD_HOURS).toBe(48);
  });

  it("describes a sub-48-hour wait in hours", () => {
    expect(describeWait(new Date(Date.now() - 30 * HOUR))).toBe("30 hours");
  });

  it("describes a longer wait in whole days", () => {
    expect(describeWait(new Date(Date.now() - 74 * HOUR))).toBe("3 days");
  });
});

describe("buildStaleAlert wording", () => {
  it("names the sender, wait time, and plain-language reason for one message", () => {
    const { title, content } = buildStaleAlert([heldRow()] as never);
    expect(title).toMatch(/has been waiting 2 days for review/);
    expect(content).toContain("Dana Reyes (dana@brightpath.com)");
    expect(content).toContain('blocked phrase "rank #1 on google"');
    expect(content).toContain("/admin/spam");
  });

  it("summarises a batch and truncates long lists", () => {
    const rows = Array.from({ length: 12 }, (_, i) =>
      heldRow({ id: i + 1, createdAt: new Date(Date.now() - (60 + i) * HOUR) }),
    );
    const { title, content } = buildStaleAlert(rows as never);
    expect(title).toBe("12 held messages are waiting for review");
    expect(content).toContain("and 2 more");
  });

  it("translates automated-rule reasons into plain language", () => {
    const { content } = buildStaleAlert([heldRow({ reason: "too-many-links" })] as never);
    expect(content).toContain("too many links");
  });

  it("falls back gracefully when the payload is unreadable", () => {
    const { content } = buildStaleAlert([heldRow({ payload: "not-json" })] as never);
    expect(content).toContain("Unknown sender");
  });

  it("uses referral field names for referral submissions", () => {
    const { content } = buildStaleAlert([
      heldRow({
        formType: "referral",
        payload: JSON.stringify({
          referrerName: "Jane Smith",
          referrerEmail: "jane@company.com",
        }),
      }),
    ] as never);
    expect(content).toContain("Referral from Jane Smith (jane@company.com)");
  });
});

describe("runStaleReviewCheck", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(notifyOwner).mockResolvedValue(true);
  });

  it("queries using the 48-hour threshold", async () => {
    vi.mocked(listStalePendingSubmissions).mockResolvedValue([] as never);
    await runStaleReviewCheck();
    expect(listStalePendingSubmissions).toHaveBeenCalledWith(48);
  });

  it("stays silent when nothing is overdue", async () => {
    vi.mocked(listStalePendingSubmissions).mockResolvedValue([] as never);
    const result = await runStaleReviewCheck();
    expect(result).toEqual({ overdue: 0, alerted: 0, notified: false });
    expect(notifyOwner).not.toHaveBeenCalled();
  });

  it("notifies the owner and stamps the reported messages", async () => {
    vi.mocked(listStalePendingSubmissions).mockResolvedValue([
      heldRow({ id: 4 }),
      heldRow({ id: 5 }),
    ] as never);

    const result = await runStaleReviewCheck();

    expect(notifyOwner).toHaveBeenCalledTimes(1);
    expect(markSubmissionsAlerted).toHaveBeenCalledWith([4, 5]);
    expect(result).toEqual({ overdue: 2, alerted: 2, notified: true });
  });

  it("does not re-alert a message that was already reported", async () => {
    vi.mocked(listStalePendingSubmissions).mockResolvedValue([
      heldRow({ id: 4, alertedAt: new Date(Date.now() - 2 * HOUR) }),
    ] as never);

    const result = await runStaleReviewCheck();

    expect(notifyOwner).not.toHaveBeenCalled();
    expect(markSubmissionsAlerted).not.toHaveBeenCalled();
    expect(result).toEqual({ overdue: 1, alerted: 0, notified: false });
  });

  it("alerts only the newly overdue message in a mixed batch", async () => {
    vi.mocked(listStalePendingSubmissions).mockResolvedValue([
      heldRow({ id: 4, alertedAt: new Date(Date.now() - 2 * HOUR) }),
      heldRow({ id: 9 }),
    ] as never);

    await runStaleReviewCheck();

    expect(markSubmissionsAlerted).toHaveBeenCalledWith([9]);
  });

  it("retries next run when the notification service is unreachable", async () => {
    vi.mocked(listStalePendingSubmissions).mockResolvedValue([heldRow({ id: 4 })] as never);
    vi.mocked(notifyOwner).mockResolvedValue(false);

    const result = await runStaleReviewCheck();

    expect(markSubmissionsAlerted).not.toHaveBeenCalled();
    expect(result).toEqual({ overdue: 1, alerted: 0, notified: false });
  });
});

describe("staleSpamReviewHandler (cron endpoint)", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(notifyOwner).mockResolvedValue(true);
    vi.mocked(listStalePendingSubmissions).mockResolvedValue([] as never);
  });

  it("rejects a signed-in human, not just anonymous callers", async () => {
    vi.mocked(sdk.authenticateRequest).mockResolvedValue({
      id: 1,
      role: "admin",
      isCron: false,
    } as never);
    const res = mockRes();

    await staleSpamReviewHandler({ originalUrl: "/api/scheduled/staleSpamReview" } as never, res as never);

    expect(res.statusCode).toBe(403);
    expect(listStalePendingSubmissions).not.toHaveBeenCalled();
  });

  it("rejects an anonymous caller with 403, not a retryable 500", async () => {
    vi.mocked(sdk.authenticateRequest).mockRejectedValue(new Error("Invalid session cookie"));
    const res = mockRes();

    await staleSpamReviewHandler({ originalUrl: "/api/scheduled/staleSpamReview" } as never, res as never);

    expect(res.statusCode).toBe(403);
    expect(res.body).toEqual({ error: "cron-only" });
    expect(listStalePendingSubmissions).not.toHaveBeenCalled();
  });

  it("runs the check for a cron caller", async () => {
    vi.mocked(sdk.authenticateRequest).mockResolvedValue({
      isCron: true,
      taskUid: "task_123",
    } as never);
    const res = mockRes();

    await staleSpamReviewHandler({ originalUrl: "/api/scheduled/staleSpamReview" } as never, res as never);

    expect(res.statusCode).toBe(200);
    expect(res.body).toEqual({ ok: true, overdue: 0, alerted: 0, notified: false });
  });

  it("returns a JSON-encoded 500 the platform can surface", async () => {
    vi.mocked(sdk.authenticateRequest).mockResolvedValue({ isCron: true } as never);
    vi.mocked(listStalePendingSubmissions).mockRejectedValue(new Error("db offline"));
    const res = mockRes();

    await staleSpamReviewHandler({ originalUrl: "/api/scheduled/staleSpamReview" } as never, res as never);

    expect(res.statusCode).toBe(500);
    expect(res.body).toMatchObject({ error: "db offline" });
  });
});
