/**
 * Admin procedures backing /admin/referrals: review referral records and track
 * where each $100 credit stands (pending -> approved -> applied, or declined).
 */
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { adminProcedure, router } from "../_core/trpc";
import {
  getReferralSubmission,
  listReferralSubmissions,
  updateReferralCredit,
} from "../db";

const creditStatusSchema = z.enum(["pending", "approved", "applied", "declined"]);

export const referralsRouter = router({
  /** Referral records, newest first, optionally narrowed to one credit status. */
  list: adminProcedure
    .input(z.object({ status: creditStatusSchema.optional() }).optional())
    .query(({ input }) => listReferralSubmissions(input?.status)),

  /**
   * Counts and dollar totals per status, so the admin header can show what is
   * owed without the client having to add up a filtered list.
   */
  summary: adminProcedure.query(async () => {
    const rows = await listReferralSubmissions();
    const empty = { count: 0, amount: 0 };
    const summary = {
      total: rows.length,
      pending: { ...empty },
      approved: { ...empty },
      applied: { ...empty },
      declined: { ...empty },
    };
    for (const row of rows) {
      const bucket = summary[row.creditStatus];
      bucket.count += 1;
      bucket.amount += row.creditAmount;
    }
    return summary;
  }),

  setStatus: adminProcedure
    .input(
      z.object({
        id: z.number().int().positive(),
        creditStatus: creditStatusSchema,
        creditNote: z.string().trim().max(500).optional(),
        creditAmount: z.number().int().min(0).max(100000).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const existing = await getReferralSubmission(input.id);
      if (!existing) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Referral not found." });
      }
      await updateReferralCredit(input.id, {
        creditStatus: input.creditStatus,
        creditNote: input.creditNote === undefined ? undefined : input.creditNote || null,
        creditAmount: input.creditAmount,
      });
      return { success: true } as const;
    }),
});
