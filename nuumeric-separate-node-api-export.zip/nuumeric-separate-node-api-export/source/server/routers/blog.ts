import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { adminProcedure, publicProcedure, router } from "../_core/trpc";
import { storagePut } from "../storage";
import {
  createBlogPost,
  deleteBlogPost,
  getPostById,
  getPostBySlugAnyStatus,
  getPublishedPostBySlug,
  listAllPosts,
  listPublishedPosts,
  updateBlogPost,
} from "../db";

/** Normalize a title or user-entered slug into a URL-safe slug. */
export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/['’]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 190);
}

const postInput = z.object({
  title: z.string().trim().min(1, "Title is required").max(300),
  slug: z.string().trim().max(200).optional().or(z.literal("")),
  excerpt: z.string().trim().max(1000).optional().or(z.literal("")),
  content: z.string().min(1, "Content is required").max(200_000),
  coverImageUrl: z.string().trim().max(2000).optional().or(z.literal("")),
  category: z.string().trim().max(100).optional().or(z.literal("")),
  tags: z.string().trim().max(500).optional().or(z.literal("")),
  seoTitle: z.string().trim().max(300).optional().or(z.literal("")),
  seoDescription: z.string().trim().max(500).optional().or(z.literal("")),
});

async function resolveUniqueSlug(desired: string, excludeId?: number): Promise<string> {
  let candidate = desired;
  let suffix = 2;
  // Try up to 20 suffixes before appending a timestamp.
  for (let i = 0; i < 20; i++) {
    const existing = await getPostBySlugAnyStatus(candidate);
    if (!existing || (excludeId !== undefined && existing.id === excludeId)) {
      return candidate;
    }
    candidate = `${desired}-${suffix++}`;
  }
  return `${desired}-${Date.now()}`;
}

export const blogRouter = router({
  // ————— Public —————
  list: publicProcedure.query(() => listPublishedPosts()),

  getBySlug: publicProcedure
    .input(z.object({ slug: z.string().trim().min(1).max(200) }))
    .query(async ({ input }) => {
      const post = await getPublishedPostBySlug(input.slug);
      if (!post) throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
      return post;
    }),

  // ————— Admin —————
  admin: router({
    list: adminProcedure.query(() => listAllPosts()),

    get: adminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .query(async ({ input }) => {
        const post = await getPostById(input.id);
        if (!post) throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
        return post;
      }),

    create: adminProcedure.input(postInput).mutation(async ({ input, ctx }) => {
      const desired = slugify(input.slug || input.title);
      if (!desired) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Could not derive a slug" });
      }
      const slug = await resolveUniqueSlug(desired);
      const id = await createBlogPost({
        slug,
        title: input.title,
        excerpt: input.excerpt || null,
        content: input.content,
        coverImageUrl: input.coverImageUrl || null,
        category: input.category || null,
        tags: input.tags || null,
        seoTitle: input.seoTitle || null,
        seoDescription: input.seoDescription || null,
        authorId: ctx.user.id,
        status: "draft",
      });
      return { id, slug } as const;
    }),

    update: adminProcedure
      .input(postInput.extend({ id: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        const existing = await getPostById(input.id);
        if (!existing) throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
        const desired = slugify(input.slug || input.title);
        if (!desired) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Could not derive a slug" });
        }
        const slug =
          desired === existing.slug ? existing.slug : await resolveUniqueSlug(desired, input.id);
        await updateBlogPost(input.id, {
          slug,
          title: input.title,
          excerpt: input.excerpt || null,
          content: input.content,
          coverImageUrl: input.coverImageUrl || null,
          category: input.category || null,
          tags: input.tags || null,
          seoTitle: input.seoTitle || null,
          seoDescription: input.seoDescription || null,
        });
        return { id: input.id, slug } as const;
      }),

    setStatus: adminProcedure
      .input(
        z.object({
          id: z.number().int().positive(),
          status: z.enum(["draft", "published"]),
        }),
      )
      .mutation(async ({ input }) => {
        const existing = await getPostById(input.id);
        if (!existing) throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
        await updateBlogPost(input.id, {
          status: input.status,
          // Keep the original publishedAt on re-publish so URLs/dates stay stable.
          publishedAt:
            input.status === "published"
              ? (existing.publishedAt ?? new Date())
              : existing.publishedAt,
        });
        return { success: true } as const;
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await deleteBlogPost(input.id);
        return { success: true } as const;
      }),

    /**
     * Upload a cover/body image (base64, ≤5MB) to S3 and return its URL.
     */
    uploadImage: adminProcedure
      .input(
        z.object({
          fileName: z.string().trim().min(1).max(300),
          contentType: z
            .string()
            .regex(/^image\/(png|jpe?g|webp|gif|avif)$/i, "Only image files are allowed"),
          base64: z.string().min(1),
        }),
      )
      .mutation(async ({ input }) => {
        const bytes = Buffer.from(input.base64, "base64");
        if (bytes.length > 5 * 1024 * 1024) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Image must be 5MB or smaller" });
        }
        const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]+/g, "-").toLowerCase();
        const { url } = await storagePut(`blog/${safeName}`, bytes, input.contentType);
        return { url } as const;
      }),
  }),
});
