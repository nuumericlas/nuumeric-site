/**
 * Admin procedures backing /admin/spam: manage the blocked-phrase list and
 * review submissions the filter rejected (including releasing false positives).
 */
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { adminProcedure, router } from "../_core/trpc";
import {
  createBlockedPhrase,
  deleteBlockedPhrase,
  deleteFilteredSubmission,
  getFilteredSubmission,
  listBlockedPhrases,
  listFilteredSubmissions,
  listStalePendingSubmissions,
  setFilteredSubmissionStatus,
} from "../db";
import { invalidatePhraseCache } from "../spamGuard";
import { STALE_THRESHOLD_HOURS, describeWait } from "../staleReviewAlert";
import {
  contactInputSchema,
  deliverContactSubmission,
  deliverReferralSubmission,
  referralInputSchema,
} from "../submissions";

/** Phrases shorter than this are too broad and would block real inquiries. */
const MIN_PHRASE_LENGTH = 4;

export const spamRouter = router({
  listPhrases: adminProcedure.query(() => listBlockedPhrases()),

  addPhrase: adminProcedure
    .input(
      z.object({
        phrase: z.string().trim().min(MIN_PHRASE_LENGTH, "Use at least 4 characters").max(200),
        category: z.string().trim().max(100).optional().or(z.literal("")),
        note: z.string().trim().max(500).optional().or(z.literal("")),
      }),
    )
    .mutation(async ({ input, ctx }) => {
      const phrase = input.phrase.trim().toLowerCase();
      const existing = await listBlockedPhrases();
      if (existing.some(p => p.phrase === phrase)) {
        throw new TRPCError({ code: "CONFLICT", message: "That phrase is already blocked." });
      }
      const id = await createBlockedPhrase({
        phrase,
        category: input.category || null,
        note: input.note || null,
        createdBy: ctx.user.id,
      });
      invalidatePhraseCache();
      return { id, phrase } as const;
    }),

  removePhrase: adminProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ input }) => {
      await deleteBlockedPhrase(input.id);
      invalidatePhraseCache();
      return { success: true } as const;
    }),

  listFiltered: adminProcedure
    .input(
      z
        .object({ status: z.enum(["pending", "released", "dismissed"]).optional() })
        .optional(),
    )
    .query(({ input }) => listFilteredSubmissions(input?.status)),

  /**
   * How many held messages have gone unreviewed past the threshold, so the
   * admin screens can warn even when the owner is not on the spam page.
   */
  staleReview: adminProcedure.query(async () => {
    const rows = await listStalePendingSubmissions(STALE_THRESHOLD_HOURS);
    const oldest = rows[0];
    return {
      thresholdHours: STALE_THRESHOLD_HOURS,
      count: rows.length,
      oldestWait: oldest ? describeWait(oldest.createdAt) : null,
    };
  }),

  /** Re-delivers a false positive through the normal pipeline. */
  release: adminProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ input }) => {
      const row = await getFilteredSubmission(input.id);
      if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "Submission not found." });
      if (row.status === "released") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Already released." });
      }

      let parsed: unknown;
      try {
        parsed = JSON.parse(row.payload);
      } catch {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Stored payload is unreadable." });
      }

      if (row.formType === "contact") {
        const data = contactInputSchema.safeParse(parsed);
        if (!data.success) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Stored payload is incomplete." });
        }
        await deliverContactSubmission(data.data, "[Released from spam review] ");
      } else {
        const data = referralInputSchema.safeParse(parsed);
        if (!data.success) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Stored payload is incomplete." });
        }
        await deliverReferralSubmission(data.data, "[Released from spam review] ");
      }

      await setFilteredSubmissionStatus(input.id, "released");
      return { success: true } as const;
    }),

  /** Marks as confirmed spam (kept for the record). */
  dismiss: adminProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ input }) => {
      await setFilteredSubmissionStatus(input.id, "dismissed");
      return { success: true } as const;
    }),

  remove: adminProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ input }) => {
      await deleteFilteredSubmission(input.id);
      return { success: true } as const;
    }),
});
