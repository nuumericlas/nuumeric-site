CREATE TABLE `blocked_phrases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phrase` varchar(200) NOT NULL,
	`category` varchar(100),
	`note` varchar(500),
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `blocked_phrases_id` PRIMARY KEY(`id`),
	CONSTRAINT `blocked_phrases_phrase_unique` UNIQUE(`phrase`)
);
--> statement-breakpoint
CREATE TABLE `filtered_submissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`formType` enum('contact','referral') NOT NULL,
	`reason` varchar(200) NOT NULL,
	`payload` text NOT NULL,
	`ip` varchar(64),
	`userAgent` varchar(500),
	`status` enum('pending','released','dismissed') NOT NULL DEFAULT 'pending',
	`releasedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `filtered_submissions_id` PRIMARY KEY(`id`)
);
