ALTER TABLE `referral_submissions` ADD `creditStatus` enum('pending','approved','applied','declined') DEFAULT 'pending' NOT NULL;--> statement-breakpoint
ALTER TABLE `referral_submissions` ADD `creditAmount` int DEFAULT 100 NOT NULL;--> statement-breakpoint
ALTER TABLE `referral_submissions` ADD `creditNote` varchar(500);--> statement-breakpoint
ALTER TABLE `referral_submissions` ADD `creditAppliedAt` timestamp;--> statement-breakpoint
ALTER TABLE `referral_submissions` ADD `creditUpdatedAt` timestamp;