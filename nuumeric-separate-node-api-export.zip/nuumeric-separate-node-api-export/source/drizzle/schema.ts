import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Contact / quote request submissions from the public website form.
 */
export const contactSubmissions = mysqlTable("contact_submissions", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 40 }),
  service: varchar("service", { length: 100 }).notNull(),
  message: text("message"),
  /** Zoho CRM sync status: pending until attempted, then synced or failed. */
  zohoSyncStatus: mysqlEnum("zohoSyncStatus", ["pending", "synced", "failed"])
    .default("pending")
    .notNull(),
  /** Zoho CRM Lead record ID when the sync succeeds. */
  zohoLeadId: varchar("zohoLeadId", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContactSubmission = typeof contactSubmissions.$inferSelect;
export type InsertContactSubmission = typeof contactSubmissions.$inferInsert;

/**
 * Client referral submissions from the dedicated /refer page.
 * Referrer = existing client; referred = the business they recommend.
 */
export const referralSubmissions = mysqlTable("referral_submissions", {
  id: int("id").autoincrement().primaryKey(),
  referrerName: varchar("referrerName", { length: 200 }).notNull(),
  referrerEmail: varchar("referrerEmail", { length: 320 }).notNull(),
  referrerPhone: varchar("referrerPhone", { length: 40 }),
  referredBusiness: varchar("referredBusiness", { length: 200 }).notNull(),
  referredContact: varchar("referredContact", { length: 200 }),
  referredEmail: varchar("referredEmail", { length: 320 }),
  referredPhone: varchar("referredPhone", { length: 40 }),
  notes: text("notes"),
  /**
   * Where the $100 referral credit stands for this referral.
   * pending  = referral received, referred business has not started paid service yet
   * approved = referred business completed its first paid month, credit is owed
   * applied  = credit has been applied to the referrer's invoice
   * declined = referral did not qualify (no signup, duplicate, existing client)
   */
  creditStatus: mysqlEnum("creditStatus", [
    "pending",
    "approved",
    "applied",
    "declined",
  ])
    .default("pending")
    .notNull(),
  /** Credit amount in whole US dollars, so the standing offer can change over time. */
  creditAmount: int("creditAmount").default(100).notNull(),
  /** Internal note about the credit decision, e.g. invoice number it was applied to. */
  creditNote: varchar("creditNote", { length: 500 }),
  /** Set when creditStatus moves to applied. */
  creditAppliedAt: timestamp("creditAppliedAt"),
  /** Last time any credit field changed, for the admin activity column. */
  creditUpdatedAt: timestamp("creditUpdatedAt"),
  /** Zoho CRM sync status for the referred business lead. */
  zohoSyncStatus: mysqlEnum("zohoSyncStatus", ["pending", "synced", "failed"])
    .default("pending")
    .notNull(),
  zohoLeadId: varchar("zohoLeadId", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ReferralSubmission = typeof referralSubmissions.$inferSelect;
export type InsertReferralSubmission = typeof referralSubmissions.$inferInsert;

/**
 * Blog posts authored via the admin editor. Content is Markdown.
 * Draft posts are only visible to admins; published posts are public.
 */
export const blogPosts = mysqlTable("blog_posts", {
  id: int("id").autoincrement().primaryKey(),
  /** URL slug, unique, e.g. "zoho-books-vs-xero" */
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  title: varchar("title", { length: 300 }).notNull(),
  /** Short summary shown on cards and used as default meta description. */
  excerpt: text("excerpt"),
  /** Markdown body. */
  content: text("content").notNull(),
  /** Cover image URL (S3). */
  coverImageUrl: text("coverImageUrl"),
  category: varchar("category", { length: 100 }),
  /** Comma-separated tags. */
  tags: varchar("tags", { length: 500 }),
  status: mysqlEnum("status", ["draft", "published"]).default("draft").notNull(),
  /** Set when first published; used for display + ordering + sitemap lastmod. */
  publishedAt: timestamp("publishedAt"),
  /** Optional SEO overrides. */
  seoTitle: varchar("seoTitle", { length: 300 }),
  seoDescription: varchar("seoDescription", { length: 500 }),
  /** users.id of the author (admin). */
  authorId: int("authorId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = typeof blogPosts.$inferInsert;

/**
 * Admin-managed spam phrase list used by the public form content filter.
 * Matching is case-insensitive substring matching against submission free text.
 */
export const blockedPhrases = mysqlTable("blocked_phrases", {
  id: int("id").autoincrement().primaryKey(),
  /** Lower-cased phrase. Unique so the same rule cannot be added twice. */
  phrase: varchar("phrase", { length: 200 }).notNull().unique(),
  /** Optional grouping label shown in the admin UI, e.g. "SEO / link spam". */
  category: varchar("category", { length: 100 }),
  /** Free-text note explaining why the phrase is blocked. */
  note: varchar("note", { length: 500 }),
  /** users.id of the admin who added it; null for the seeded defaults. */
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BlockedPhrase = typeof blockedPhrases.$inferSelect;
export type InsertBlockedPhrase = typeof blockedPhrases.$inferInsert;

/**
 * Every public form submission rejected by the spam filter. Retained so the
 * owner can review false positives and release them into the real pipeline.
 */
export const filteredSubmissions = mysqlTable("filtered_submissions", {
  id: int("id").autoincrement().primaryKey(),
  /** Which public form produced the submission. */
  formType: mysqlEnum("formType", ["contact", "referral"]).notNull(),
  /** Machine reason, e.g. "honeypot", "too-fast", "phrase:backlink". */
  reason: varchar("reason", { length: 200 }).notNull(),
  /** Full submitted payload as JSON so it can be replayed on release. */
  payload: text("payload").notNull(),
  ip: varchar("ip", { length: 64 }),
  userAgent: varchar("userAgent", { length: 500 }),
  /** pending until the owner acts; released = re-delivered, dismissed = confirmed spam. */
  status: mysqlEnum("status", ["pending", "released", "dismissed"])
    .default("pending")
    .notNull(),
  /** Set when released into the real pipeline. */
  releasedAt: timestamp("releasedAt"),
  /**
   * Last time the owner was alerted that this message was still unreviewed.
   * Keeps the recurring staleness check from re-reporting the same message
   * every single day once it has already been flagged.
   */
  alertedAt: timestamp("alertedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type FilteredSubmission = typeof filteredSubmissions.$inferSelect;
export type InsertFilteredSubmission = typeof filteredSubmissions.$inferInsert;
