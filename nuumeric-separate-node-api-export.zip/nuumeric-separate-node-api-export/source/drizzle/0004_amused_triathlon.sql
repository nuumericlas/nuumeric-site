CREATE TABLE `referral_submissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`referrerName` varchar(200) NOT NULL,
	`referrerEmail` varchar(320) NOT NULL,
	`referrerPhone` varchar(40),
	`referredBusiness` varchar(200) NOT NULL,
	`referredContact` varchar(200),
	`referredEmail` varchar(320),
	`referredPhone` varchar(40),
	`notes` text,
	`zohoSyncStatus` enum('pending','synced','failed') NOT NULL DEFAULT 'pending',
	`zohoLeadId` varchar(32),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `referral_submissions_id` PRIMARY KEY(`id`)
);
