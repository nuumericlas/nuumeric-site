/**
 * Invisible decoy input. Automated form fillers populate every field they can
 * find, so any value arriving in `hp` marks the submission as a bot.
 *
 * Kept out of the accessibility tree and out of the tab order so real visitors
 * (including screen-reader users) never encounter it.
 */
export function HoneypotField({
  value,
  onChange,
}: {
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
      <label htmlFor="company-website-hp">Leave this field empty</label>
      <input
        id="company-website-hp"
        name="company-website"
        type="text"
        tabIndex={-1}
        autoComplete="off"
        value={value}
        onChange={e => onChange(e.target.value)}
      />
    </div>
  );
}
