import { useEffect } from "react";

const DEFAULT_TITLE = "Nuumeric Inc — Expert Solutions for Growing Enterprises";
const DEFAULT_DESCRIPTION =
  "US-based bookkeeping, tax preparation, and payroll for growing enterprises. Nuumeric — expert back-office support, formerly Montgomery Bookkeeping.";

type SeoProps = {
  /** Page-specific document title. */
  title?: string;
  /** Page-specific meta description (keep between 50 and 160 characters). */
  description?: string;
  /** Optional JSON-LD structured data object injected as a script tag. */
  jsonLd?: Record<string, unknown>;
};

/**
 * Sets the document title and meta description for the current route.
 * Restores the site-wide defaults when the page unmounts so navigating
 * back to Home always shows the canonical tags from index.html.
 */
export default function Seo({ title, description, jsonLd }: SeoProps) {
  useEffect(() => {
    document.title = title ?? DEFAULT_TITLE;

    const meta = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (meta) {
      meta.setAttribute("content", description ?? DEFAULT_DESCRIPTION);
    }

    let script: HTMLScriptElement | null = null;
    if (jsonLd) {
      script = document.createElement("script");
      script.type = "application/ld+json";
      script.setAttribute("data-seo-jsonld", "true");
      script.textContent = JSON.stringify(jsonLd);
      document.head.appendChild(script);
    }

    return () => {
      document.title = DEFAULT_TITLE;
      const m = document.querySelector<HTMLMetaElement>('meta[name="description"]');
      if (m) m.setAttribute("content", DEFAULT_DESCRIPTION);
      script?.remove();
    };
  }, [title, description, jsonLd]);

  return null;
}
