import {
  BUSINESS_HOURS,
  SITE,
  formatCityLine,
  formatStreetAddress,
  mapsUrl,
} from "@shared/site";
import { Clock, MapPin, Phone } from "lucide-react";
import { Link } from "wouter";
import { PhoneLink } from "./PhoneLink";
import { SocialIcons } from "./SocialIcons";

declare global {
  interface Window {
    displayPreferenceModal?: () => void;
  }
}

export function SiteFooter() {
  return (
    <footer className="bg-ink text-ink-foreground">
      <div className="container grid gap-12 py-16 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <img
            src="/manus-storage/nuumeric_logo_dark_d687ed3b.png"
            alt="Nuumeric"
            className="h-10 w-auto"
          />
          <p className="mt-3 text-[11px] font-medium uppercase tracking-[0.2em] text-gold">
            Driving growth thru numbers &amp; insights
          </p>
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-ink-foreground/70">
            US-based back-office support for growing enterprises — bookkeeping,
            business and individual tax preparation, payroll, and more. Formerly{" "}
            {SITE.formerName}.
          </p>
          <SocialIcons className="mt-6 text-ink-foreground" />
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">
            Explore
          </p>
          <nav className="mt-4 flex flex-col gap-2.5 text-sm">
            <Link href="/" className="text-ink-foreground/75 transition-colors hover:text-gold">Home</Link>
            <Link href="/services" className="text-ink-foreground/75 transition-colors hover:text-gold">Services</Link>
            <Link href="/about" className="text-ink-foreground/75 transition-colors hover:text-gold">About Us</Link>
            <Link href="/what-to-expect" className="text-ink-foreground/75 transition-colors hover:text-gold">What to Expect</Link>
            <Link href="/blog" className="text-ink-foreground/75 transition-colors hover:text-gold">Blog</Link>
            <Link href="/careers" className="text-ink-foreground/75 transition-colors hover:text-gold">Careers</Link>
            <Link href="/contact" className="text-ink-foreground/75 transition-colors hover:text-gold">Contact</Link>
          </nav>
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">
            Get in Touch
          </p>
          <PhoneLink
            source="footer"
            className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-ink-foreground transition-colors hover:text-gold"
          >
            <Phone className="h-4 w-4 text-gold" strokeWidth={1.75} />
            Call or Text {SITE.phoneDisplay}
          </PhoneLink>

          {/*
            Address and hours are visible here as well as in structured data, so
            visitors and search engines see the same details. `address` is the
            correct semantic element for a contact address.
          */}
          <address className="mt-4 flex items-start gap-2 text-sm not-italic leading-relaxed text-ink-foreground/75">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold" strokeWidth={1.75} />
            <a
              href={mapsUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="transition-colors hover:text-gold"
            >
              {formatStreetAddress()}
              <br />
              {formatCityLine()}
            </a>
          </address>

          <p className="mt-4 flex items-start gap-2 text-sm leading-relaxed text-ink-foreground/75">
            <Clock className="mt-0.5 h-4 w-4 shrink-0 text-gold" strokeWidth={1.75} />
            <span>
              {BUSINESS_HOURS.daysDisplay}
              <br />
              {BUSINESS_HOURS.timeDisplay} {BUSINESS_HOURS.timezoneDisplay}
            </span>
          </p>

          <p className="mt-4 text-sm leading-relaxed text-ink-foreground/70">
            Insured and bondable. Certificate of Insurance (COI) available upon
            request.
          </p>
        </div>
      </div>

      <div className="border-t border-ink-foreground/10">
        <div className="container flex flex-col items-center justify-between gap-3 py-6 text-xs text-ink-foreground/60 sm:flex-row">
          <p>© {new Date().getFullYear()} {SITE.legalName}. All rights reserved.</p>
          <nav className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2">
            <Link href="/privacy-policy" className="transition-colors hover:text-gold">
              Privacy Policy
            </Link>
            <Link href="/terms-and-conditions" className="transition-colors hover:text-gold">
              Terms &amp; Conditions
            </Link>
            <Link href="/cookie-policy" className="transition-colors hover:text-gold">
              Cookie Policy
            </Link>
            <a
              href="#"
              className="termly-display-preferences transition-colors hover:text-gold"
              onClick={e => {
                e.preventDefault();
                // Termly's resource-blocker exposes this global when loaded.
                window.displayPreferenceModal?.();
              }}
            >
              Consent Preferences
            </a>
          </nav>
        </div>
      </div>
    </footer>
  );
}
