import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { canonicalPostUrl, SHARE_TARGETS } from "@/lib/share";
import { Check, Facebook, Link2, Linkedin, Mail, MessageCircle } from "lucide-react";
import { useEffect, useRef, useState } from "react";

/** Simple X (Twitter) glyph — lucide has no up-to-date X logo. */
function XLogo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
      className={className}
    >
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );
}

interface ShareButtonsProps {
  slug: string;
  title: string;
  /** Visual context: dark ink hero vs light article body. */
  tone?: "light" | "dark";
  className?: string;
}

export function ShareButtons({ slug, title, tone = "light", className }: ShareButtonsProps) {
  const url = canonicalPostUrl(slug);
  const [copied, setCopied] = useState(false);
  const resetTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => () => clearTimeout(resetTimer.current), []);

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      // Fallback for older browsers / non-secure contexts
      const el = document.createElement("textarea");
      el.value = url;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      el.remove();
    }
    setCopied(true);
    clearTimeout(resetTimer.current);
    resetTimer.current = setTimeout(() => setCopied(false), 2000);
  };

  const buttonClasses =
    tone === "dark"
      ? "border-ink-foreground/25 text-ink-foreground/80 hover:border-gold hover:bg-ink-foreground/10 hover:text-gold"
      : "border-border text-muted-foreground hover:border-primary hover:bg-primary/5 hover:text-primary";

  const items = [
    { key: "linkedin", icon: <Linkedin className="h-4 w-4" />, target: SHARE_TARGETS.linkedin },
    { key: "facebook", icon: <Facebook className="h-4 w-4" />, target: SHARE_TARGETS.facebook },
    { key: "x", icon: <XLogo className="h-4 w-4" />, target: SHARE_TARGETS.x },
    { key: "whatsapp", icon: <MessageCircle className="h-4 w-4" />, target: SHARE_TARGETS.whatsapp },
    { key: "email", icon: <Mail className="h-4 w-4" />, target: SHARE_TARGETS.email },
  ] as const;

  return (
    <div className={`flex flex-wrap items-center gap-2 ${className ?? ""}`}>
      <span
        className={`mr-1 text-xs font-semibold uppercase tracking-[0.14em] ${
          tone === "dark" ? "text-ink-foreground/60" : "text-muted-foreground"
        }`}
      >
        Share
      </span>
      {items.map(({ key, icon, target }) => (
        <Tooltip key={key}>
          <TooltipTrigger asChild>
            <Button
              asChild
              variant="outline"
              size="icon"
              className={`h-9 w-9 rounded-full transition-colors ${buttonClasses}`}
            >
              <a
                href={target.href(url, title)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`Share on ${target.name}`}
              >
                {icon}
              </a>
            </Button>
          </TooltipTrigger>
          <TooltipContent>Share on {target.name}</TooltipContent>
        </Tooltip>
      ))}
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            type="button"
            variant="outline"
            size="icon"
            aria-label={copied ? "Link copied" : "Copy link"}
            onClick={copyLink}
            className={`h-9 w-9 rounded-full transition-colors ${buttonClasses}`}
          >
            {copied ? <Check className="h-4 w-4 text-primary" /> : <Link2 className="h-4 w-4" />}
          </Button>
        </TooltipTrigger>
        <TooltipContent>{copied ? "Copied!" : "Copy link"}</TooltipContent>
      </Tooltip>
    </div>
  );
}
