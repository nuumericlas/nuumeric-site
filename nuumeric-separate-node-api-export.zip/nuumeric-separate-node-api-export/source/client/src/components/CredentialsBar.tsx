import { CREDENTIALS } from "@shared/site";
import { BadgeCheck } from "lucide-react";

/**
 * Trust & Credentials bar — certification titles rendered verbatim.
 */
export function CredentialsBar({ variant = "light" }: { variant?: "light" | "dark" }) {
  const isDark = variant === "dark";
  return (
    <section
      aria-label="Certifications and credentials"
      className={
        isDark
          ? "border-y border-gold/20 bg-ink text-ink-foreground"
          : "border-y border-border bg-secondary text-secondary-foreground"
      }
    >
      <div className="container flex flex-wrap items-center justify-center gap-x-10 gap-y-4 py-7">
        {CREDENTIALS.map(cred => (
          <div key={cred} className="flex items-center gap-2.5">
            <BadgeCheck
              className={`h-[18px] w-[18px] shrink-0 ${isDark ? "text-gold" : "text-primary"}`}
              strokeWidth={1.75}
            />
            <span className="text-[13px] font-medium tracking-wide whitespace-nowrap">
              {cred}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
