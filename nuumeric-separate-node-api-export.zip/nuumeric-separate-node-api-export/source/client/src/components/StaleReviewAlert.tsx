import { trpc } from "@/lib/trpc";
import { AlertTriangle } from "lucide-react";
import { Link } from "wouter";

/**
 * Warns the owner when messages have been sitting in the spam review queue past
 * the threshold. Rendered on every admin screen so a false positive cannot go
 * unnoticed just because the spam page was never opened.
 *
 * `variant="banner"` is the full callout used on /admin/spam itself;
 * `variant="link"` is the compact header pill used on the other admin pages.
 */
export function StaleReviewAlert({
  variant = "banner",
  enabled = true,
}: {
  variant?: "banner" | "link";
  enabled?: boolean;
}) {
  const { data } = trpc.spam.staleReview.useQuery(undefined, {
    enabled,
    refetchOnWindowFocus: true,
  });

  if (!data || data.count === 0) return null;

  const label =
    data.count === 1
      ? `1 held message has been waiting ${data.oldestWait}`
      : `${data.count} held messages are waiting review — oldest ${data.oldestWait}`;

  if (variant === "link") {
    return (
      <Link
        href="/admin/spam"
        className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/40 bg-amber-500/10 px-4 py-2 text-sm font-medium text-amber-700 transition-colors hover:bg-amber-500/20 dark:text-amber-400"
      >
        <AlertTriangle className="h-4 w-4" /> {label}
      </Link>
    );
  }

  return (
    <div className="mt-6 flex items-start gap-3 rounded-lg border border-amber-500/40 bg-amber-500/10 p-4 text-sm">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
      <div>
        <p className="font-medium text-amber-800 dark:text-amber-300">{label}</p>
        <p className="mt-1 text-amber-800/80 dark:text-amber-300/80">
          Anything held longer than {data.thresholdHours} hours is flagged here. If one of these
          is a genuine inquiry, the sender is still waiting on a reply.
        </p>
      </div>
    </div>
  );
}
