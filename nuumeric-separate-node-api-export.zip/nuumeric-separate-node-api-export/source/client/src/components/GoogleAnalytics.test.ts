// @vitest-environment jsdom
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { beforeEach, describe, expect, it } from "vitest";
import {
  GA_MEASUREMENT_ID,
  GTM_CONTAINER_ID,
  trackPageView,
} from "./GoogleAnalytics";

const indexHtml = readFileSync(
  resolve(__dirname, "../../index.html"),
  "utf-8",
);

describe("Google Analytics / Tag Manager configuration", () => {
  it("uses the IDs provided by the owner", () => {
    expect(GA_MEASUREMENT_ID).toBe("G-ECKM2GTE74");
    expect(GTM_CONTAINER_ID).toBe("GTM-P3S4KDRK");
  });

  it("index.html loads gtag.js and GTM with the correct IDs", () => {
    expect(indexHtml).toContain(
      `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`,
    );
    expect(indexHtml).toContain(`"${GTM_CONTAINER_ID}"`);
    // GTM noscript fallback
    expect(indexHtml).toContain(
      `https://www.googletagmanager.com/ns.html?id=${GTM_CONTAINER_ID}`,
    );
  });

  it("declares Consent Mode v2 defaults (denied) before Google tags", () => {
    for (const signal of [
      "ad_storage",
      "ad_user_data",
      "ad_personalization",
      "analytics_storage",
    ]) {
      expect(indexHtml).toContain(signal);
    }
    expect(indexHtml).toMatch(/"consent",\s*"default"/);
    // Consent default must appear before the GTM loader snippet
    const consentIdx = indexHtml.indexOf('"consent", "default"');
    const gtmIdx = indexHtml.indexOf("gtm.start");
    expect(consentIdx).toBeGreaterThan(-1);
    expect(gtmIdx).toBeGreaterThan(consentIdx);
    // Termly resource blocker stays the first script in head
    const termlyIdx = indexHtml.indexOf("app.termly.io/resource-blocker");
    expect(termlyIdx).toBeGreaterThan(-1);
    expect(termlyIdx).toBeLessThan(consentIdx);
  });

  it("disables automatic page_view (SPA sends them manually)", () => {
    expect(indexHtml).toMatch(/send_page_view:\s*false/);
  });
});

describe("trackPageView", () => {
  beforeEach(() => {
    (window as any).gtag = undefined;
    (window as any).dataLayer = undefined;
  });

  it("sends a GA4 page_view event and a dataLayer push", () => {
    const gtagCalls: unknown[][] = [];
    (window as any).gtag = (...args: unknown[]) => gtagCalls.push(args);
    (window as any).dataLayer = [] as unknown[];

    trackPageView("/services", "Services — Nuumeric Inc");

    expect(gtagCalls).toHaveLength(1);
    const [cmd, eventName, params] = gtagCalls[0] as [
      string,
      string,
      Record<string, unknown>,
    ];
    expect(cmd).toBe("event");
    expect(eventName).toBe("page_view");
    expect(params.page_path).toBe("/services");
    expect(params.page_title).toBe("Services — Nuumeric Inc");
    expect(params.send_to).toBe(GA_MEASUREMENT_ID);

    const pushed = (window as any).dataLayer[0];
    expect(pushed.event).toBe("spa_page_view");
    expect(pushed.page_path).toBe("/services");
  });

  it("does not crash when gtag/dataLayer are absent", () => {
    expect(() => trackPageView("/about", "About")).not.toThrow();
  });
});
