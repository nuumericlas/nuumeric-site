import { trackConversion } from "@/lib/conversions";
import { SITE } from "@shared/site";
import type { AnchorHTMLAttributes, ReactNode } from "react";

interface PhoneLinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  /** Where on the site this link lives, e.g. "nav" or "hero". */
  source: string;
  children: ReactNode;
}

/**
 * A `tel:` link that records a phone_click conversion before navigating.
 *
 * Uses the existing `SITE.phoneHref` so the number stays in one place. The
 * tracking call is fire-and-forget: we never delay or intercept the dial,
 * because a missed call costs more than a missed analytics event.
 */
export function PhoneLink({ source, children, onClick, ...rest }: PhoneLinkProps) {
  return (
    <a
      href={SITE.phoneHref}
      onClick={e => {
        trackConversion("phone", { source });
        onClick?.(e);
      }}
      {...rest}
    >
      {children}
    </a>
  );
}
