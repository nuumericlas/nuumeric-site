import { useEffect, useRef } from "react";
import { useLocation } from "wouter";

export const GA_MEASUREMENT_ID = "G-ECKM2GTE74";
export const GTM_CONTAINER_ID = "GTM-P3S4KDRK";

declare global {
  interface Window {
    dataLayer?: unknown[];
    gtag?: (...args: unknown[]) => void;
  }
}

/**
 * Sends a page_view for the given path to GA4 (via gtag) and pushes a
 * `page_view` event to the GTM dataLayer, so GTM tags can also react to
 * SPA navigations (use a History Change / Custom Event trigger in GTM).
 */
export function trackPageView(path: string, title: string) {
  window.gtag?.("event", "page_view", {
    page_path: path,
    page_location: window.location.href,
    page_title: title,
    send_to: GA_MEASUREMENT_ID,
  });
  window.dataLayer?.push({
    event: "spa_page_view",
    page_path: path,
    page_title: title,
  });
}

/**
 * SPA page-view tracker: fires once on initial load and again on every
 * client-side route change. The gtag config uses send_page_view:false, so
 * this component is the single source of page_view events (no double counts).
 * Because routes are lazy-loaded chunks that set document.title via an SEO
 * hook after they mount, we wait for the <title> element to actually change
 * (MutationObserver) before sending, with a 2s fallback in case a route keeps
 * the same title (e.g. anchor-only or unchanged-title navigations).
 */
export default function GoogleAnalytics() {
  const [location] = useLocation();
  const lastTracked = useRef<string | null>(null);
  const isFirstView = useRef(true);

  useEffect(() => {
    if (lastTracked.current === location) return;
    lastTracked.current = location;

    // Initial page load: the correct title is already in the document.
    if (isFirstView.current) {
      isFirstView.current = false;
      trackPageView(location, document.title);
      return;
    }

    // Client-side navigation: wait until the destination page updates the
    // title, then send. Fallback fires after 2s if the title never changes.
    let done = false;
    const send = () => {
      if (done) return;
      done = true;
      observer.disconnect();
      clearTimeout(fallback);
      trackPageView(location, document.title);
    };
    const titleEl = document.querySelector("title");
    const observer = new MutationObserver(send);
    if (titleEl) {
      observer.observe(titleEl, { childList: true, characterData: true, subtree: true });
    }
    const fallback = setTimeout(send, 2000);
    return () => {
      done = true;
      observer.disconnect();
      clearTimeout(fallback);
    };
  }, [location]);

  return null;
}
