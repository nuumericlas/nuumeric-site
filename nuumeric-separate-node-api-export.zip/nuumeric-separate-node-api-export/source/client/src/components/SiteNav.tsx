import { SITE } from "@shared/site";
import { PhoneLink } from "./PhoneLink";
import { Menu, Phone, Search, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { SearchDialog, useSearchShortcut } from "./SearchDialog";
import { SocialIcons } from "./SocialIcons";
import { Button } from "./ui/button";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/services", label: "Services" },
  { href: "/about", label: "About Us" },
  { href: "/what-to-expect", label: "What to Expect" },
  { href: "/blog", label: "Blog" },
  { href: "/contact", label: "Contact" },
];

/** Routes that open with a light background (no dark hero) need dark nav text. */
const LIGHT_HERO_PREFIXES = ["/admin"];

export function SiteNav() {
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  // Pages that open with a dark (ink) hero need light nav text until scrolled.
  const darkHero = !LIGHT_HERO_PREFIXES.some(p => location.startsWith(p));
  const onDark = darkHero && !scrolled && !mobileOpen;

  useSearchShortcut(setSearchOpen);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    window.scrollTo({ top: 0 });
  }, [location]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/95 shadow-[0_1px_0_0_oklch(0.9_0.012_100),0_8px_30px_-18px_rgb(0_0_0/0.25)] backdrop-blur-md"
          : "bg-transparent"
      }`}
    >
      <div className="container flex h-[72px] items-center justify-between gap-6">
        <Link href="/" className="flex items-center select-none">
          <img
            src={
              onDark
                ? "/manus-storage/nuumeric_logo_dark_d687ed3b.png"
                : "/manus-storage/nuumeric_logo_light_c560ce7c.png"
            }
            alt="Nuumeric — Driving Growth Thru Numbers & Insights"
            className="h-9 w-auto transition-opacity duration-300 sm:h-10"
          />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map(link => {
            const active =
              link.href === "/" ? location === "/" : location.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`relative whitespace-nowrap rounded-md px-4 py-2 text-sm font-medium transition-colors duration-200 ${
                  active
                    ? onDark
                      ? "text-gold"
                      : "text-primary"
                    : onDark
                      ? "text-ink-foreground/80 hover:text-gold"
                      : "text-foreground/70 hover:text-primary"
                }`}
              >
                {link.label}
                {active && (
                  <span className="absolute inset-x-4 -bottom-px h-px bg-gold" />
                )}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <button
            onClick={() => setSearchOpen(true)}
            aria-label="Search the site (Ctrl+K)"
            title="Search (Ctrl+K)"
            className={`inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors duration-200 ${
              onDark
                ? "text-ink-foreground/80 hover:bg-ink-foreground/10 hover:text-gold"
                : "text-foreground/70 hover:bg-accent hover:text-primary"
            }`}
          >
            <Search className="h-[18px] w-[18px]" />
          </button>
          <SocialIcons className={onDark ? "text-ink-foreground" : "text-primary"} />
          <Button
            asChild
            className={`rounded-full px-5 shadow-sm transition-all duration-150 active:scale-[0.97] ${
              onDark
                ? "bg-gold text-gold-foreground hover:bg-gold/90"
                : "bg-primary text-primary-foreground hover:bg-primary/90"
            }`}
          >
            <PhoneLink source="nav_desktop">
              <Phone className="h-3.5 w-3.5" />
              {SITE.phoneDisplay}
            </PhoneLink>
          </Button>
        </div>

        <div className="flex items-center gap-1 lg:hidden">
          <button
            className={`inline-flex h-10 w-10 items-center justify-center rounded-md ${
              onDark ? "text-ink-foreground" : "text-primary"
            }`}
            onClick={() => setSearchOpen(true)}
            aria-label="Search the site"
          >
            <Search className="h-5 w-5" />
          </button>
          <button
            className={`inline-flex h-10 w-10 items-center justify-center rounded-md ${
              onDark ? "text-ink-foreground" : "text-primary"
            }`}
            onClick={() => setMobileOpen(o => !o)}
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="border-t border-border bg-background lg:hidden">
          <nav className="container flex flex-col py-3">
            <button
              onClick={() => {
                setMobileOpen(false);
                setSearchOpen(true);
              }}
              className="flex items-center gap-2.5 rounded-md px-3 py-3 text-left text-base font-medium text-foreground/80 hover:bg-accent hover:text-primary"
            >
              <Search className="h-4 w-4" />
              Search the site
            </button>
            {NAV_LINKS.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className="rounded-md px-3 py-3 text-base font-medium text-foreground/80 hover:bg-accent hover:text-primary"
              >
                {link.label}
              </Link>
            ))}
            <div className="mt-2 flex items-center justify-between border-t border-border px-3 pt-4 pb-2">
              <SocialIcons className="text-primary" />
              <PhoneLink
                source="nav_mobile"
                className="text-sm font-semibold text-primary"
              >
                {SITE.phoneDisplay}
              </PhoneLink>
            </div>
          </nav>
        </div>
      )}

      <SearchDialog open={searchOpen} onOpenChange={setSearchOpen} />
    </header>
  );
}
