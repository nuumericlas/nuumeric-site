// @vitest-environment jsdom
import { TERMLY } from "@shared/site";
import { beforeEach, describe, expect, it } from "vitest";

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

describe("Termly configuration", () => {
  it("has valid UUIDs for the website and policy documents", () => {
    expect(TERMLY.websiteUuid).toMatch(UUID_RE);
    expect(TERMLY.privacyPolicyId).toMatch(UUID_RE);
    expect(TERMLY.cookiePolicyId).toMatch(UUID_RE);
    expect(TERMLY.termsId).toMatch(UUID_RE);
  });

  it("uses distinct document ids for all three policies", () => {
    const ids = [
      TERMLY.privacyPolicyId,
      TERMLY.cookiePolicyId,
      TERMLY.termsId,
    ];
    expect(new Set(ids).size).toBe(ids.length);
  });
});

describe("Termly consent banner (index.html)", () => {
  it("references the resource blocker with the website uuid and autoBlock", async () => {
    const fs = await import("node:fs/promises");
    const path = await import("node:path");
    const html = await fs.readFile(
      path.resolve(process.cwd(), "client/index.html"),
      "utf-8",
    );
    expect(html).toContain(
      `https://app.termly.io/resource-blocker/${TERMLY.websiteUuid}?autoBlock=on`,
    );
    // Must be inside <head> and before other scripts per Termly docs.
    const headEnd = html.indexOf("</head>");
    const blockerAt = html.indexOf("resource-blocker");
    const firstOtherScript = html.indexOf("embed-policy");
    expect(blockerAt).toBeGreaterThan(-1);
    expect(blockerAt).toBeLessThan(headEnd);
    if (firstOtherScript !== -1) {
      expect(blockerAt).toBeLessThan(firstOtherScript);
    }
  });
});

describe("TermlyPolicy embed loader", () => {
  beforeEach(() => {
    document.body.innerHTML = "";
    document.getElementById("termly-jssdk")?.remove();
  });

  it("injects the embed-policy script after mount", async () => {
    const { TermlyPolicy } = await import("./TermlyPolicy");
    const { createElement, act } = await import("react");
    const { createRoot } = await import("react-dom/client");

    const host = document.createElement("div");
    document.body.appendChild(host);
    const root = createRoot(host);
    await act(async () => {
      root.render(createElement(TermlyPolicy, { dataId: TERMLY.privacyPolicyId }));
    });
    // Script injection is deferred past React's commit (setTimeout 0).
    await act(async () => {
      await new Promise((r) => setTimeout(r, 20));
    });

    const script = document.getElementById(
      "termly-jssdk",
    ) as HTMLScriptElement | null;
    expect(script).not.toBeNull();
    expect(script!.src).toBe("https://app.termly.io/embed-policy.min.js");

    // Renders the div Termly scans for, with the right data-id.
    const embed = host.querySelector('[data-id="' + TERMLY.privacyPolicyId + '"]');
    expect(embed).not.toBeNull();
    expect(embed!.getAttribute("name")).toBe("termly-embed");

    await act(async () => {
      root.unmount();
    });
  });
});
