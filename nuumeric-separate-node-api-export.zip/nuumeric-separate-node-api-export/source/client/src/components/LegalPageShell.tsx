import Seo from "@/components/Seo";
import { SiteLayout } from "@/components/SiteLayout";
import type { ReactNode } from "react";

/**
 * Shared shell for legal document pages (Privacy Policy, Terms & Conditions,
 * Cookie Policy): dark page header matching the rest of the site, followed by
 * a white document area where the embedded policy renders.
 */
export function LegalPageShell({
  eyebrow,
  title,
  seoTitle,
  seoDescription,
  children,
}: {
  eyebrow: string;
  title: string;
  seoTitle: string;
  seoDescription: string;
  children: ReactNode;
}) {
  return (
    <SiteLayout>
      <Seo title={seoTitle} description={seoDescription} />
      <section className="bg-ink pt-40 pb-16 text-ink-foreground">
        <div className="container">
          <p className="eyebrow fade-up">{eyebrow}</p>
          <h1 className="fade-up mt-4 max-w-3xl text-balance font-display text-5xl font-bold leading-[1.08] md:text-6xl">
            {title}
          </h1>
        </div>
      </section>
      <section className="bg-background py-8 md:py-14">
        {/* Termly's embedded document carries its own generous internal
            margins, so on mobile we keep the page gutters minimal to give
            the policy text as much width as possible. */}
        <div className="legal-container mx-auto w-full max-w-4xl px-2 sm:px-4 lg:px-8">
          {children}
        </div>
      </section>
    </SiteLayout>
  );
}
