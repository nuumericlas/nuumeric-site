// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from "vitest";

/**
 * Tests for the SalesIQ visitor-identification queue in ZohoSalesIQ.tsx.
 * The module keeps internal state (pendingIdentity/widgetReady), so each
 * test re-imports a fresh module instance via vi.resetModules().
 */

function makeVisitorMock() {
  return {
    name: vi.fn(),
    email: vi.fn(),
    contactnumber: vi.fn(),
    info: vi.fn(),
  };
}

async function freshModule() {
  vi.resetModules();
  return import("./ZohoSalesIQ");
}

describe("identifySalesIQVisitor", () => {
  beforeEach(() => {
    delete (window as { $zoho?: unknown }).$zoho;
    document.getElementById("zsiqscript")?.remove();
  });

  it("does not crash when the widget has never loaded", async () => {
    const { identifySalesIQVisitor } = await freshModule();
    expect(() =>
      identifySalesIQVisitor({ name: "Jane Doe", email: "jane@example.com" })
    ).not.toThrow();
  });

  it("queues identity before load and flushes it when SalesIQ fires ready", async () => {
    const { identifySalesIQVisitor, bootstrapSalesIQGlobals } =
      await freshModule();

    // App bootstraps the globals (as injectSalesIQ does on widget injection).
    bootstrapSalesIQGlobals("test-widget-code");

    // A visitor submits the quote form BEFORE the widget is ready.
    identifySalesIQVisitor({
      name: "Jane Doe",
      email: "jane@example.com",
      phone: "5551234567",
      info: { "Service Needed": "Bookkeeping" },
    });

    // Widget script arrives: it exposes the visitor API, then calls ready().
    const visitor = makeVisitorMock();
    window.$zoho!.salesiq!.visitor = visitor;
    window.$zoho!.salesiq!.ready!();

    expect(visitor.name).toHaveBeenCalledWith("Jane Doe");
    expect(visitor.email).toHaveBeenCalledWith("jane@example.com");
    expect(visitor.contactnumber).toHaveBeenCalledWith("5551234567");
    expect(visitor.info).toHaveBeenCalledWith({
      "Service Needed": "Bookkeeping",
    });
  });

  it("applies identity immediately when the widget is already ready", async () => {
    const { identifySalesIQVisitor, bootstrapSalesIQGlobals } =
      await freshModule();

    const visitor = makeVisitorMock();
    window.$zoho = { salesiq: { visitor } };
    bootstrapSalesIQGlobals("test-widget-code");
    window.$zoho.salesiq!.ready!(); // widget initialized with no queued identity

    identifySalesIQVisitor({ name: "John Smith", email: "john@example.com" });

    expect(visitor.name).toHaveBeenCalledWith("John Smith");
    expect(visitor.email).toHaveBeenCalledWith("john@example.com");
    expect(visitor.contactnumber).not.toHaveBeenCalled();
  });

  it("merges successive identifications (later fields win)", async () => {
    const { identifySalesIQVisitor, bootstrapSalesIQGlobals } =
      await freshModule();

    bootstrapSalesIQGlobals("test-widget-code");
    identifySalesIQVisitor({ name: "First Name" });
    identifySalesIQVisitor({ name: "Second Name", email: "second@example.com" });

    const visitor = makeVisitorMock();
    window.$zoho!.salesiq!.visitor = visitor;
    window.$zoho!.salesiq!.ready!();

    expect(visitor.name).toHaveBeenCalledTimes(1);
    expect(visitor.name).toHaveBeenCalledWith("Second Name");
    expect(visitor.email).toHaveBeenCalledWith("second@example.com");
  });
});
