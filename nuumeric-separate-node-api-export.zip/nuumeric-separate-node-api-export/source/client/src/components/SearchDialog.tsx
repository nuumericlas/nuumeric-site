import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { SEARCH_INDEX, type SearchEntry } from "@/lib/searchIndex";
import { ArrowRight, FileText } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";

/**
 * Global site search rendered as a command palette.
 * Controlled externally via open/onOpenChange; also listens for Ctrl/Cmd+K.
 */
export function SearchDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [, setLocation] = useLocation();
  const [query, setQuery] = useState("");

  // Reset query each time the dialog opens
  useEffect(() => {
    if (open) setQuery("");
  }, [open]);

  const groups = useMemo(() => {
    const map = new Map<string, SearchEntry[]>();
    for (const entry of SEARCH_INDEX) {
      const list = map.get(entry.page) ?? [];
      list.push(entry);
      map.set(entry.page, list);
    }
    return Array.from(map.entries());
  }, []);

  const go = (entry: SearchEntry) => {
    onOpenChange(false);
    const [pathAndQuery, hash] = entry.href.split("#");
    const [path, queryString] = pathAndQuery.split("?");
    if (hash) {
      // Set the hash first so the target page's scroll effect picks it up
      window.history.replaceState(null, "", entry.href);
      setLocation(entry.href, { replace: false });
      // Let already-mounted pages react (e.g. expand the matching FAQ item)
      if (queryString) {
        window.dispatchEvent(
          new CustomEvent("site-search-navigate", {
            detail: { path, query: queryString, hash },
          }),
        );
      }
      // If already on the page, scroll directly
      setTimeout(() => {
        document
          .getElementById(hash)
          ?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 200);
    } else {
      setLocation(path || "/");
    }
  };

  return (
    <CommandDialog
      open={open}
      onOpenChange={onOpenChange}
      title="Search the site"
      description="Search pages, services, and information"
    >
      <CommandInput
        placeholder="Search services, pages, industries..."
        value={query}
        onValueChange={setQuery}
      />
      <CommandList>
        <CommandEmpty>
          No results found. Try "bookkeeping", "payroll", or "quote" — or{" "}
          <button
            className="font-semibold text-primary underline underline-offset-2"
            onClick={() => {
              onOpenChange(false);
              setLocation("/contact");
            }}
          >
            contact us
          </button>{" "}
          directly.
        </CommandEmpty>
        {groups.map(([page, entries]) => (
          <CommandGroup key={page} heading={page}>
            {entries.map((entry: SearchEntry) => (
              <CommandItem
                key={`${entry.href}-${entry.title}`}
                value={`${entry.title} ${entry.description} ${entry.keywords}`}
                onSelect={() => go(entry)}
                className="group flex items-start gap-3 px-3 py-2.5"
              >
                <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                  <FileText className="h-4 w-4" />
                </span>
                <span className="flex min-w-0 flex-col">
                  <span className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
                    {entry.title}
                    <ArrowRight className="h-3.5 w-3.5 opacity-0 transition-opacity group-data-[selected=true]:opacity-60" />
                  </span>
                  <span className="truncate text-xs text-muted-foreground">
                    {entry.description}
                  </span>
                </span>
              </CommandItem>
            ))}
          </CommandGroup>
        ))}
      </CommandList>
    </CommandDialog>
  );
}

/** Hook wiring the global Ctrl/Cmd+K shortcut to a dialog open state. */
export function useSearchShortcut(setOpen: (open: boolean) => void) {
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen(true);
      }
    };
    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, [setOpen]);
}
