import { SITE } from "@shared/site";
import { Facebook, Instagram, Linkedin, MessageCircle } from "lucide-react";

const links = [
  { href: SITE.social.linkedin, label: "LinkedIn", Icon: Linkedin },
  { href: SITE.social.instagram, label: "Instagram", Icon: Instagram },
  { href: SITE.social.facebook, label: "Facebook", Icon: Facebook },
  { href: SITE.social.whatsapp, label: "WhatsApp", Icon: MessageCircle },
];

export function SocialIcons({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-1 ${className}`}>
      {links.map(({ href, label, Icon }) => (
        <a
          key={label}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={label}
          className="inline-flex h-8 w-8 items-center justify-center rounded-full text-current opacity-70 transition-all duration-200 hover:opacity-100 hover:bg-gold/15"
        >
          <Icon className="h-4 w-4" strokeWidth={1.75} />
        </a>
      ))}
    </div>
  );
}
