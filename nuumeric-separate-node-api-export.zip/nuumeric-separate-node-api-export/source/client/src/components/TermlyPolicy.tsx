import { useEffect } from "react";

const TERMLY_SDK_ID = "termly-jssdk";
const TERMLY_SDK_SRC = "https://app.termly.io/embed-policy.min.js";

declare global {
  interface Window {
    Termly?: { initialize?: () => void };
  }
}

/**
 * Load (or fully reload) the Termly embed SDK so it scans the DOM for the
 * current page's embed div. Termly's `initialize()` only renders a given
 * policy once per SDK lifetime, so on SPA navigation between legal pages we
 * remove the script and the `window.Termly` global and re-append the script —
 * a fresh SDK instance then auto-scans and injects the policy iframe.
 * A short poll acts as a safety net for slow script loads.
 */
function loadTermly(cancelled: () => boolean) {
  // Fresh SDK instance per legal-page mount.
  document.getElementById(TERMLY_SDK_ID)?.remove();
  delete window.Termly;
  const script = document.createElement("script");
  script.id = TERMLY_SDK_ID;
  script.src = TERMLY_SDK_SRC;
  script.async = true;
  document.body.appendChild(script);

  let attempts = 0;
  const tryInit = () => {
    if (cancelled()) return;
    const embed = document.querySelector('[name="termly-embed"]');
    // Stop once the SDK injected the policy iframe into our div.
    if (embed?.querySelector("iframe")) return;
    window.Termly?.initialize?.();
    if (attempts++ < 40) setTimeout(tryInit, 250);
  };
  setTimeout(tryInit, 250);
}

/**
 * Embeds a Termly-hosted policy document (privacy policy, cookie policy, …)
 * using Termly's code-snippet method, adapted for an SPA:
 * - reloads embed-policy.min.js on each mount so the SDK reliably renders the
 *   policy on first client-side navigation AND when moving between legal pages
 * - polls `Termly.initialize()` until the policy iframe appears as a fallback
 */
export function TermlyPolicy({ dataId }: { dataId: string }) {
  useEffect(() => {
    let cancelled = false;
    // Defer past React's commit so the embed div is in the DOM when the SDK
    // auto-scans on script execution.
    const t = setTimeout(() => loadTermly(() => cancelled), 0);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [dataId]);

  return (
    <div
      // Termly's embed script looks up embeds by this name attribute.
      {...{ name: "termly-embed" }}
      data-id={dataId}
      className="termly-policy min-h-[60vh] w-full"
    />
  );
}
