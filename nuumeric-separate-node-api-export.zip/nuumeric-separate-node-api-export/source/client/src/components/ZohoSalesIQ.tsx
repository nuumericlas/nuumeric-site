import { useEffect } from "react";

const WIDGET_CODE = import.meta.env.VITE_ZOHO_SALESIQ_WIDGET_CODE as
  | string
  | undefined;

/**
 * Fallback delay (ms) used when requestIdleCallback is unavailable, and the
 * hard ceiling passed as its `timeout` so the chat never waits indefinitely.
 */
const IDLE_TIMEOUT_MS = 4000;

type SalesIQVisitorApi = {
  name?: (value: string) => void;
  email?: (value: string) => void;
  contactnumber?: (value: string) => void;
  info?: (values: Record<string, string>) => void;
};

declare global {
  interface Window {
    $zoho?: {
      salesiq?: {
        ready?: () => void;
        widgetcode?: string;
        visitor?: SalesIQVisitorApi;
      };
    };
  }
}

export type VisitorIdentity = {
  name?: string;
  email?: string;
  phone?: string;
  info?: Record<string, string>;
};

/** Identity captured before the widget finished loading, applied on ready. */
let pendingIdentity: VisitorIdentity | null = null;
let widgetReady = false;

function applyIdentity(identity: VisitorIdentity) {
  const visitor = window.$zoho?.salesiq?.visitor;
  if (!visitor) return false;
  try {
    if (identity.name && typeof visitor.name === "function") {
      visitor.name(identity.name);
    }
    if (identity.email && typeof visitor.email === "function") {
      visitor.email(identity.email);
    }
    if (identity.phone && typeof visitor.contactnumber === "function") {
      visitor.contactnumber(identity.phone);
    }
    if (identity.info && typeof visitor.info === "function") {
      visitor.info(identity.info);
    }
    return true;
  } catch {
    // Third-party API changed shape — never break the host app.
    return false;
  }
}

/**
 * Identifies the current visitor to Zoho SalesIQ (name/email/phone plus
 * optional custom info). Safe to call at any time: if the deferred widget
 * hasn't loaded yet, the identity is queued and applied once SalesIQ fires
 * its `ready` callback. With the SalesIQ–CRM integration enabled, this is
 * what lets Zoho auto-link the chat visitor to the matching CRM lead.
 */
export function identifySalesIQVisitor(identity: VisitorIdentity) {
  pendingIdentity = { ...pendingIdentity, ...identity };
  if (widgetReady) {
    applyIdentity(pendingIdentity);
  }
}

/**
 * Sets up the `window.$zoho.salesiq` globals and the `ready` callback that
 * flushes any queued identity. Extracted from injectSalesIQ so it can be
 * exercised in unit tests without a widget code configured.
 */
export function bootstrapSalesIQGlobals(widgetCode?: string) {
  window.$zoho = window.$zoho || {};
  window.$zoho.salesiq = window.$zoho.salesiq || {
    widgetcode: widgetCode,
    ready: function () {},
  };
  window.$zoho.salesiq.ready = function () {
    widgetReady = true;
    if (pendingIdentity) applyIdentity(pendingIdentity);
  };
}

function injectSalesIQ() {
  if (!WIDGET_CODE) return;
  if (document.getElementById("zsiqscript")) return; // already loaded (HMR/strict mode)

  // SalesIQ calls `ready` once the widget has initialized; flush any
  // identity captured before that point (e.g. an early form submission).
  bootstrapSalesIQGlobals(WIDGET_CODE);

  const script = document.createElement("script");
  script.id = "zsiqscript";
  script.type = "text/javascript";
  script.defer = true;
  script.src = `https://salesiq.zoho.com/widget?wc=${WIDGET_CODE}`;
  document.body.appendChild(script);
  // Intentionally no cleanup: the widget should persist for the whole
  // session; SalesIQ does not support clean unloading.
}

/**
 * Schedules the SalesIQ injection for after the browser is idle so the
 * third-party script never competes with the critical rendering path
 * (LCP, TBT) or delays hydration.
 */
function scheduleIdleInjection() {
  if (typeof window.requestIdleCallback === "function") {
    window.requestIdleCallback(() => injectSalesIQ(), {
      timeout: IDLE_TIMEOUT_MS,
    });
  } else {
    // Safari fallback: a plain timeout well past first paint.
    window.setTimeout(injectSalesIQ, IDLE_TIMEOUT_MS);
  }
}

/**
 * Loads the Zoho SalesIQ live chat widget once for the whole app, deferred
 * until after the `load` event AND an idle period so Core Web Vitals are
 * unaffected. Rendered at the App level so the chat is available on every
 * page and survives client-side route changes without reloading.
 */
export default function ZohoSalesIQ() {
  useEffect(() => {
    if (!WIDGET_CODE) return; // silently skip when not configured
    if (document.getElementById("zsiqscript")) return;

    // If the page has already fully loaded (SPA navigations, fast caches),
    // go straight to idle scheduling; otherwise wait for the load event so
    // the widget never competes with images/fonts/LCP resources.
    if (document.readyState === "complete") {
      scheduleIdleInjection();
      return;
    }

    const onLoad = () => scheduleIdleInjection();
    window.addEventListener("load", onLoad, { once: true });
    return () => window.removeEventListener("load", onLoad);
  }, []);

  return null;
}
