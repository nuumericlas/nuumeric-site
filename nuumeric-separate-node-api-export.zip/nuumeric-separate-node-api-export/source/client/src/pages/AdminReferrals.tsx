import { useAuth } from "@/_core/hooks/useAuth";
import Seo from "@/components/Seo";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteNav } from "@/components/SiteNav";
import { StaleReviewAlert } from "@/components/StaleReviewAlert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Spinner } from "@/components/ui/spinner";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Gift, Handshake, Inbox, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";

type CreditStatus = "pending" | "approved" | "applied" | "declined";

const STATUS_ORDER: CreditStatus[] = ["pending", "approved", "applied", "declined"];

const STATUS_META: Record<
  CreditStatus,
  { label: string; short: string; help: string; className: string }
> = {
  pending: {
    label: "Pending",
    short: "Pending",
    help: "Referral received. The referred business has not completed a paid month yet.",
    className: "border-amber-500/40 text-amber-700 dark:text-amber-400",
  },
  approved: {
    label: "Credit approved",
    short: "Approved",
    help: "The referred business qualified. The credit is owed but not yet on an invoice.",
    className: "border-sky-500/40 text-sky-700 dark:text-sky-400",
  },
  applied: {
    label: "Credit applied",
    short: "Applied",
    help: "The credit has been applied to the referrer's invoice.",
    className: "border-primary/50 text-primary",
  },
  declined: {
    label: "Not eligible",
    short: "Not eligible",
    help: "The referral did not qualify (no signup, duplicate, or an existing client).",
    className: "text-muted-foreground",
  },
};

type ReferralRow = {
  id: number;
  referrerName: string;
  referrerEmail: string;
  referrerPhone: string | null;
  referredBusiness: string;
  referredContact: string | null;
  referredEmail: string | null;
  referredPhone: string | null;
  notes: string | null;
  creditStatus: CreditStatus;
  creditAmount: number;
  creditNote: string | null;
  creditAppliedAt: Date | string | null;
  creditUpdatedAt: Date | string | null;
  zohoSyncStatus: string;
  createdAt: Date | string;
};

function money(amount: number) {
  return `$${amount.toLocaleString("en-US")}`;
}

function ReferralCard({
  row,
  onSetStatus,
  saving,
}: {
  row: ReferralRow;
  onSetStatus: (input: {
    id: number;
    creditStatus: CreditStatus;
    creditNote?: string;
  }) => void;
  saving: boolean;
}) {
  const [note, setNote] = useState(row.creditNote ?? "");
  const meta = STATUS_META[row.creditStatus];
  const noteChanged = note !== (row.creditNote ?? "");

  return (
    <li className="rounded-lg border border-border p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-semibold">{row.referredBusiness}</h3>
          <p className="mt-0.5 text-sm text-muted-foreground">
            Referred by {row.referrerName} &middot; {row.referrerEmail}
          </p>
        </div>
        <div className="flex flex-col items-end gap-1.5">
          <Badge variant="outline" className={meta.className}>
            {money(row.creditAmount)} {meta.short}
          </Badge>
          <span className="text-xs text-muted-foreground">
            Received {new Date(row.createdAt).toLocaleDateString()}
          </span>
        </div>
      </div>

      <dl className="mt-4 grid gap-x-6 gap-y-1.5 rounded-md bg-muted/40 p-4 text-sm sm:grid-cols-[10rem_1fr]">
        {row.referredContact && (
          <>
            <dt className="font-medium text-muted-foreground">Contact</dt>
            <dd>{row.referredContact}</dd>
          </>
        )}
        {row.referredEmail && (
          <>
            <dt className="font-medium text-muted-foreground">Contact email</dt>
            <dd className="break-words">{row.referredEmail}</dd>
          </>
        )}
        {row.referredPhone && (
          <>
            <dt className="font-medium text-muted-foreground">Contact phone</dt>
            <dd>{row.referredPhone}</dd>
          </>
        )}
        {row.referrerPhone && (
          <>
            <dt className="font-medium text-muted-foreground">Referrer phone</dt>
            <dd>{row.referrerPhone}</dd>
          </>
        )}
        {row.notes && (
          <>
            <dt className="font-medium text-muted-foreground">Notes</dt>
            <dd className="break-words">{row.notes}</dd>
          </>
        )}
        <dt className="font-medium text-muted-foreground">Zoho lead</dt>
        <dd className="capitalize">{row.zohoSyncStatus}</dd>
      </dl>

      <div className="mt-4">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          Credit status
        </p>
        <div className="mt-2 flex flex-wrap gap-2">
          {STATUS_ORDER.map(status => {
            const active = row.creditStatus === status;
            return (
              <Button
                key={status}
                size="sm"
                variant={active ? "default" : "outline"}
                title={STATUS_META[status].help}
                disabled={saving || active}
                className={
                  active
                    ? "rounded-full bg-primary px-4 text-primary-foreground hover:bg-primary/90"
                    : "rounded-full bg-background px-4 active:scale-[0.97]"
                }
                onClick={() => onSetStatus({ id: row.id, creditStatus: status })}
              >
                {STATUS_META[status].label}
              </Button>
            );
          })}
        </div>
        <p className="mt-2 text-xs text-muted-foreground">{meta.help}</p>
      </div>

      <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center">
        <Input
          value={note}
          onChange={e => setNote(e.target.value)}
          placeholder="Internal note, e.g. invoice #1042"
          maxLength={500}
          className="sm:flex-1"
        />
        <Button
          size="sm"
          variant="outline"
          className="rounded-full bg-background px-4 active:scale-[0.97]"
          disabled={saving || !noteChanged}
          onClick={() =>
            onSetStatus({ id: row.id, creditStatus: row.creditStatus, creditNote: note })
          }
        >
          Save note
        </Button>
      </div>

      {row.creditAppliedAt && (
        <p className="mt-3 text-xs text-muted-foreground">
          Credit applied {new Date(row.creditAppliedAt).toLocaleString()}
        </p>
      )}
      {!row.creditAppliedAt && row.creditUpdatedAt && (
        <p className="mt-3 text-xs text-muted-foreground">
          Status last changed {new Date(row.creditUpdatedAt).toLocaleString()}
        </p>
      )}
    </li>
  );
}

export default function AdminReferrals() {
  const { isAuthenticated, user, loading } = useAuth();
  const utils = trpc.useUtils();
  const [tab, setTab] = useState<CreditStatus | "all">("all");

  const isAdmin = isAuthenticated && user?.role === "admin";
  const listQuery = trpc.referral.admin.list.useQuery(
    tab === "all" ? {} : { status: tab },
    { enabled: !!isAdmin },
  );
  const summaryQuery = trpc.referral.admin.summary.useQuery(undefined, {
    enabled: !!isAdmin,
  });

  const setStatusMut = trpc.referral.admin.setStatus.useMutation({
    onSuccess: () => {
      toast.success("Referral updated");
      utils.referral.admin.list.invalidate();
      utils.referral.admin.summary.invalidate();
    },
    onError: err => toast.error(err.message),
  });

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Spinner className="h-6 w-6" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background">
        <Seo
          title="Referral Credits — Nuumeric"
          description="Owner-only referral credit tracking."
        />
        <SiteNav />
        <main className="container flex min-h-[70vh] flex-col items-center justify-center pt-[72px] text-center">
          <ShieldCheck className="h-10 w-10 text-muted-foreground" />
          <h1 className="mt-4 text-2xl font-bold">Referral credit tracking</h1>
          <p className="mt-2 max-w-md text-sm text-muted-foreground">
            {isAuthenticated
              ? "This area is reserved for the site owner. Your account doesn't have admin access."
              : "Please sign in with the site owner account to review referral credits."}
          </p>
          {!isAuthenticated && (
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <Button
                className="rounded-full bg-primary px-6 text-primary-foreground hover:bg-primary/90 active:scale-[0.97]"
                onClick={() => startLogin()}
              >
                Sign In as Owner
              </Button>
              <Button
                variant="outline"
                className="rounded-full bg-background px-6 active:scale-[0.97]"
                onClick={() => {
                  window.location.href = "/";
                }}
              >
                Back to the site
              </Button>
            </div>
          )}
        </main>
        <SiteFooter />
      </div>
    );
  }

  const rows = (listQuery.data ?? []) as unknown as ReferralRow[];
  const summary = summaryQuery.data;

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Referral Credits — Nuumeric"
        description="Owner-only referral credit tracking."
      />
      <SiteNav />
      <main className="container max-w-4xl pb-24 pt-[120px]">
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
          <Link
            href="/admin/blog"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" /> Blog admin
          </Link>
          <Link
            href="/admin/spam"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ShieldCheck className="h-4 w-4" /> Spam filter
          </Link>
        </div>
        <div className="mt-4 empty:mt-0">
          <StaleReviewAlert variant="link" enabled={!!isAdmin} />
        </div>

        <div className="mt-4">
          <p className="eyebrow">Referral program</p>
          <h1 className="mt-1 text-3xl font-bold">Referral credits</h1>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
            Every referral submitted through the site is listed here. Move a referral to{" "}
            <span className="font-medium text-foreground">Credit approved</span> once the referred
            business completes its first paid month, then to{" "}
            <span className="font-medium text-foreground">Credit applied</span> after the credit
            lands on an invoice.
          </p>
        </div>

        {summary && (
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-lg border border-border p-4">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">Awaiting</p>
              <p className="mt-1 text-2xl font-bold">{summary.pending.count}</p>
              <p className="text-xs text-muted-foreground">referrals not yet qualified</p>
            </div>
            <div className="rounded-lg border border-border p-4">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">Credit owed</p>
              <p className="mt-1 text-2xl font-bold">{money(summary.approved.amount)}</p>
              <p className="text-xs text-muted-foreground">
                {summary.approved.count} approved, not yet invoiced
              </p>
            </div>
            <div className="rounded-lg border border-border p-4">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">
                Credit applied
              </p>
              <p className="mt-1 text-2xl font-bold">{money(summary.applied.amount)}</p>
              <p className="text-xs text-muted-foreground">
                across {summary.applied.count} referrals
              </p>
            </div>
            <div className="rounded-lg border border-border p-4">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">
                Total referrals
              </p>
              <p className="mt-1 text-2xl font-bold">{summary.total}</p>
              <p className="text-xs text-muted-foreground">
                {summary.declined.count} not eligible
              </p>
            </div>
          </div>
        )}

        <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-xl font-semibold">Referral records</h2>
          <div className="flex flex-wrap gap-1 rounded-full border border-border p-1">
            {(["all", ...STATUS_ORDER] as const).map(t => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`rounded-full px-3.5 py-1.5 text-sm transition-colors ${
                  tab === t
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t === "all" ? "All" : STATUS_META[t].short}
              </button>
            ))}
          </div>
        </div>

        {listQuery.isLoading ? (
          <div className="flex justify-center py-16">
            <Spinner className="h-6 w-6" />
          </div>
        ) : rows.length === 0 ? (
          <div className="mt-6 rounded-lg border border-dashed border-border py-16 text-center">
            {tab === "all" ? (
              <Handshake className="mx-auto h-8 w-8 text-muted-foreground" />
            ) : (
              <Inbox className="mx-auto h-8 w-8 text-muted-foreground" />
            )}
            <p className="mt-3 font-medium">
              {tab === "all" ? "No referrals yet" : `Nothing marked ${STATUS_META[tab].short}`}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              {tab === "all"
                ? "Referrals submitted on the Refer a Business page will appear here."
                : "Referrals you move to this status will be listed here."}
            </p>
          </div>
        ) : (
          <ul className="mt-6 space-y-4">
            {rows.map(row => (
              <ReferralCard
                key={row.id}
                row={row}
                saving={setStatusMut.isPending}
                onSetStatus={input => setStatusMut.mutate(input)}
              />
            ))}
          </ul>
        )}

        <div className="mt-10 flex items-start gap-3 rounded-lg border border-border bg-muted/30 p-5 text-sm text-muted-foreground">
          <Gift className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
          <p>
            Changing a status here is for your own tracking only — it never emails the referrer.
            Credits still need to be entered on the invoice in Zoho Books.
          </p>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
