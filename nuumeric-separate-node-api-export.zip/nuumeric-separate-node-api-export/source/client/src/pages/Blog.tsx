import { useAuth } from "@/_core/hooks/useAuth";
import Seo from "@/components/Seo";
import { SiteLayout } from "@/components/SiteLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { formatPostDate } from "@/lib/blogFormat";
import { trpc } from "@/lib/trpc";
import { ArrowRight, Newspaper, PenSquare, Search, X } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "wouter";

const PAGE_SIZE = 12;

export default function Blog() {
  const { data: posts, isLoading } = trpc.blog.list.useQuery();
  const { user } = useAuth();
  const [category, setCategory] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);

  const categories = useMemo(() => {
    if (!posts) return [];
    return Array.from(
      new Set(posts.map(p => p.category).filter((c): c is string => Boolean(c))),
    );
  }, [posts]);

  const filtered = useMemo(() => {
    if (!posts) return [];
    const byCategory = category ? posts.filter(p => p.category === category) : posts;
    const q = query.trim().toLowerCase();
    if (!q) return byCategory;
    const terms = q.split(/\s+/);
    return byCategory.filter(p => {
      const haystack = [p.title, p.excerpt, p.tags, p.category]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return terms.every(t => haystack.includes(t));
    });
  }, [posts, category, query]);

  const visible = useMemo(() => filtered.slice(0, visibleCount), [filtered, visibleCount]);
  const hasMore = filtered.length > visibleCount;

  const selectCategory = (c: string | null) => {
    setCategory(c);
    setVisibleCount(PAGE_SIZE);
  };

  const updateQuery = (value: string) => {
    setQuery(value);
    setVisibleCount(PAGE_SIZE);
  };

  return (
    <SiteLayout>
      <Seo
        title="Blog — Insights on Bookkeeping, Payroll & Cloud Accounting — Nuumeric Inc"
        description="Practical guidance on bookkeeping, payroll, Zoho Books, Xero, and QuickBooks from the Nuumeric team — written for owners of growing enterprises."
      />

      {/* ————— Page Header ————— */}
      <section className="bg-ink pt-40 pb-20 text-ink-foreground">
        <div className="container">
          <p className="eyebrow fade-up">Blog</p>
          <h1 className="fade-up mt-4 max-w-3xl text-balance font-display text-5xl font-bold leading-[1.08] md:text-6xl">
            Numbers, explained in plain English
          </h1>
          <p className="fade-up mt-5 max-w-2xl text-lg leading-relaxed text-ink-foreground/75">
            Practical insights on bookkeeping, payroll, and the cloud accounting
            platforms we work in every day — written for business owners, not
            accountants.
          </p>
        </div>
      </section>

      {/* ————— Posts ————— */}
      <section className="py-20">
        <div className="container">
          {!isLoading && posts && posts.length > 0 && (
            <div className="fade-up mb-6 flex flex-wrap items-center gap-3">
              <div className="relative w-full max-w-md">
                <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="search"
                  value={query}
                  onChange={e => updateQuery(e.target.value)}
                  placeholder="Search articles by keyword…"
                  aria-label="Search blog articles"
                  className="h-11 rounded-full bg-card pl-10 pr-10"
                />
                {query && (
                  <button
                    type="button"
                    aria-label="Clear search"
                    onClick={() => updateQuery("")}
                    className="absolute right-3 top-1/2 flex h-6 w-6 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              {user?.role === "admin" && (
                <Button
                  asChild
                  variant="outline"
                  className="h-11 rounded-full bg-background px-5 active:scale-[0.97]"
                >
                  <Link href="/admin/blog">
                    <PenSquare className="h-4 w-4" />
                    Manage Posts
                  </Link>
                </Button>
              )}
            </div>
          )}

          {categories.length > 0 && (
            <div className="fade-up mb-10 flex flex-wrap gap-2">
              <Button
                variant={category === null ? "default" : "outline"}
                size="sm"
                className="rounded-full"
                onClick={() => selectCategory(null)}
              >
                All
              </Button>
              {categories.map(c => (
                <Button
                  key={c}
                  variant={category === c ? "default" : "outline"}
                  size="sm"
                  className="rounded-full"
                  onClick={() => selectCategory(c)}
                >
                  {c}
                </Button>
              ))}
            </div>
          )}

          {isLoading ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[0, 1, 2].map(i => (
                <div key={i} className="rounded-lg border border-border bg-card p-4">
                  <Skeleton className="h-44 w-full rounded-md" />
                  <Skeleton className="mt-4 h-5 w-3/4" />
                  <Skeleton className="mt-2 h-4 w-full" />
                  <Skeleton className="mt-1 h-4 w-2/3" />
                </div>
              ))}
            </div>
          ) : visible.length === 0 ? (
            query.trim() ? (
              <div className="mx-auto max-w-md py-16 text-center">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/8">
                  <Search className="h-7 w-7 text-primary" strokeWidth={1.6} />
                </div>
                <h2 className="mt-5 font-display text-2xl font-semibold text-foreground">
                  No articles match "{query.trim()}"
                </h2>
                <p className="mt-2 text-muted-foreground">
                  Try a different keyword{category ? ` or search all categories` : ""}.
                </p>
                <Button
                  variant="outline"
                  className="mt-6 rounded-full bg-background px-6 active:scale-[0.97]"
                  onClick={() => {
                    updateQuery("");
                    selectCategory(null);
                  }}
                >
                  Clear Search
                </Button>
              </div>
            ) : (
            <div className="fade-up mx-auto max-w-md py-16 text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/8">
                <Newspaper className="h-7 w-7 text-primary" strokeWidth={1.6} />
              </div>
              <h2 className="mt-5 font-display text-2xl font-semibold text-foreground">
                Articles are on the way
              </h2>
              <p className="mt-2 text-muted-foreground">
                We're writing our first posts now. In the meantime, our team is a
                phone call away for any bookkeeping or payroll question.
              </p>
              <Button asChild className="mt-6 rounded-full px-6 active:scale-[0.97]">
                <Link href="/contact">
                  Ask Us Directly
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
            )
          ) : (
            <>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {visible.map((post, index) => (
                <Link
                  key={post.id}
                  href={`/blog/${post.slug}`}
                  className="fade-up group flex flex-col overflow-hidden rounded-lg border border-border bg-card shadow-sm transition-shadow hover:shadow-md"
                  style={{ animationDelay: `${(index % PAGE_SIZE) * 60}ms` }}
                >
                  {post.coverImageUrl ? (
                    <div className="aspect-[16/9] overflow-hidden bg-muted">
                      <img
                        src={post.coverImageUrl}
                        alt={post.title}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                      />
                    </div>
                  ) : (
                    <div className="flex aspect-[16/9] items-center justify-center bg-ink">
                      <Newspaper className="h-10 w-10 text-gold/70" strokeWidth={1.4} />
                    </div>
                  )}
                  <div className="flex flex-1 flex-col p-6">
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      {post.category && (
                        <Badge variant="secondary" className="rounded-full">
                          {post.category}
                        </Badge>
                      )}
                      <span>{formatPostDate(post.publishedAt)}</span>
                    </div>
                    <h2 className="mt-3 font-display text-xl font-semibold leading-snug text-foreground group-hover:text-primary">
                      {post.title}
                    </h2>
                    {post.excerpt && (
                      <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-muted-foreground">
                        {post.excerpt}
                      </p>
                    )}
                    <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-primary">
                      Read article
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>

            <div className="mt-12 flex flex-col items-center gap-3">
              <p className="text-sm text-muted-foreground">
                Showing {visible.length} of {filtered.length} article
                {filtered.length === 1 ? "" : "s"}
                {category ? ` in ${category}` : ""}
              </p>
              {hasMore && (
                <Button
                  variant="outline"
                  size="lg"
                  className="rounded-full bg-background px-8 active:scale-[0.97]"
                  onClick={() => setVisibleCount(n => n + PAGE_SIZE)}
                >
                  Load More Articles
                </Button>
              )}
            </div>
            </>
          )}
        </div>
      </section>
    </SiteLayout>
  );
}
