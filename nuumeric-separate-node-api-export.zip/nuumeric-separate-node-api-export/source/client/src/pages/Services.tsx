import { CredentialsBar } from "@/components/CredentialsBar";
import { PhoneLink } from "@/components/PhoneLink";
import Seo from "@/components/Seo";
import { SiteLayout } from "@/components/SiteLayout";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { useJsonLd } from "@/hooks/useJsonLd";
import { FAQ_ENTRIES } from "@/lib/faq";
import {
  INDIVIDUAL_TAX_DOCUMENTS,
  INDIVIDUAL_TAX_STEPS,
  INDIVIDUAL_TAX_TURNAROUND,
} from "@/lib/individualTax";
import { SITE } from "@shared/site";
import {
  ArrowRight,
  Check,
  Clock,
  FileText,
  Laptop,
  Mail,
  Phone,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";

const SERVICES = [
  {
    id: "bookkeeping",
    eyebrow: "Core Service",
    title: "Bookkeeping",
    image: "/manus-storage/nuumeric_bookkeeping_51bc6570.png",
    alt: "Neatly organized financial documents and ledger representing bookkeeping services",
    description:
      "Clean, current, and accurate books are the foundation of every sound business decision. Nuumeric's US-based team keeps your ledgers reconciled and your reports meaningful, whether you need weekly transaction entry or full-cycle monthly close.",
    features: [
      "Bank and credit card reconciliations",
      "Customer invoicing and receivables",
      "Accounts payable management",
      "Monthly financial reporting",
      "Catch-up and clean-up bookkeeping",
    ],
  },
  {
    id: "tax-preparation",
    eyebrow: "Core Service",
    title: "Tax Preparation",
    image: "/manus-storage/nuumeric_tax_f7dede83.png",
    alt: "A refined desk with organized documents representing tax preparation services",
    description:
      "Tax season shouldn't be a scramble. With books maintained year-round and nearly three decades of hands-on experience behind every return, Nuumeric prepares your filings thoroughly and on time — and helps you plan ahead, not just look back. We prepare both business and individual returns, so owners can keep their company and personal filings under one roof rather than coordinating between two preparers.",
    features: [
      "Small business tax return preparation",
      "Individual (personal) tax return preparation",
      "Owner returns handled alongside the business",
      "Year-round tax planning support",
      "Quarterly estimated tax guidance",
      "Coordination with your CPA when needed",
      "Organized, audit-ready records",
    ],
  },
  {
    id: "payroll-processing",
    eyebrow: "Core Service",
    title: "Payroll Processing",
    image: "/manus-storage/nuumeric_payroll_72bfb170.png",
    alt: "A modern workspace with a payroll dashboard representing payroll processing services",
    description:
      "Your people are your business — paying them accurately and on schedule is non-negotiable. As a Gusto Payroll partner and SurePayroll Accountant, Nuumeric runs payroll end to end so you never miss a run, a filing, or a deadline.",
    features: [
      "Full-service payroll runs",
      "Gusto Payroll administration",
      "SurePayroll Accountant support",
      "Payroll tax filings and deposits",
      "New hire onboarding support",
    ],
  },
  {
    id: "additional-services",
    eyebrow: "Beyond the Books",
    title: "Additional Services",
    image: "/manus-storage/nuumeric_additional_05ccac8d.png",
    alt: "A tablet showing a CRM dashboard representing technology and software support services",
    description:
      "Modern back offices run on modern tools. As a Zoho Finance Advisor with Xero Advisor and QuickBooks ProAdvisor certifications, Nuumeric helps you choose, implement, and get the most from the platforms that power your business.",
    features: [
      "Migrations to Zoho Books",
      "Zoho CRM support and configuration",
      "Xero setup, migration, and advisory",
      "QuickBooks setup and ongoing support",
      "Human resources and financial reporting",
    ],
  },
];

export default function Services() {
  // FAQ item to auto-expand when arriving via a search deep link (?q=<id>)
  const [openFaq, setOpenFaq] = useState<string | undefined>(undefined);

  // FAQPage structured data for Google rich results, generated from the same
  // FAQ_ENTRIES that render the visible accordion so they never drift apart.
  useJsonLd("faq-jsonld", {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: FAQ_ENTRIES.map(faq => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  });

  // Smooth-scroll to a section when arriving with a hash (e.g. /services#payroll-processing)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const q = params.get("q");
    if (q && FAQ_ENTRIES.some(f => f.id === q)) {
      setOpenFaq(q);
    }
    const hash = window.location.hash.replace("#", "");
    if (!hash) return;
    const t = setTimeout(() => {
      document.getElementById(hash)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 150);
    return () => clearTimeout(t);
  }, []);

  // Expand the matching FAQ item when a search selection happens while the
  // Services page is already mounted (no full navigation occurs).
  useEffect(() => {
    const onSearchNav = (e: Event) => {
      const { query } = (e as CustomEvent<{ query?: string }>).detail ?? {};
      const q = new URLSearchParams(query).get("q");
      if (q && FAQ_ENTRIES.some(f => f.id === q)) {
        setOpenFaq(q);
      }
    };
    window.addEventListener("site-search-navigate", onSearchNav);
    return () => window.removeEventListener("site-search-navigate", onSearchNav);
  }, []);

  return (
    <SiteLayout>
      <Seo
        title="Bookkeeping, Tax & Payroll Services — Nuumeric Inc"
        description="Explore Nuumeric services: bookkeeping, business and individual tax preparation, payroll processing, plus Zoho CRM, Xero, and QuickBooks support."
      />
      {/* ————— Page Header ————— */}
      <section className="bg-ink pt-40 pb-20 text-ink-foreground">
        <div className="container">
          <p className="eyebrow fade-up">What We Do</p>
          <h1 className="fade-up mt-4 max-w-3xl text-balance font-display text-5xl font-bold leading-[1.08] md:text-6xl">
            Services built around your business
          </h1>
          <p className="fade-up mt-5 max-w-2xl text-lg leading-relaxed text-ink-foreground/75">
            Four service areas, delivered by US-based professionals who scale
            with you. Explore each below — or tell us what you need and we'll
            shape the engagement around it.
          </p>
        </div>
      </section>

      <CredentialsBar />

      {/* ————— Service Detail Sections ————— */}
      {SERVICES.map((svc, i) => (
        <section
          key={svc.id}
          id={svc.id}
          className={`scroll-mt-24 py-24 ${i % 2 === 1 ? "bg-secondary border-y border-border" : ""}`}
        >
          <div
            className={`container grid items-center gap-14 lg:grid-cols-2 ${
              i % 2 === 1 ? "lg:[&>*:first-child]:order-2" : ""
            }`}
          >
            <div className="fade-up relative">
              <div
                className={`absolute -inset-3 rounded-xl border ${i % 2 === 1 ? "border-primary/20" : "border-gold/30"}`}
                aria-hidden
              />
              <img
                src={svc.image}
                alt={svc.alt}
                className="relative aspect-[4/3] w-full rounded-lg object-cover shadow-lg"
                loading={i === 0 ? "eager" : "lazy"}
              />
            </div>
            <div className="fade-up">
              <p className="eyebrow">{svc.eyebrow}</p>
              <h2 className="mt-3 font-display text-4xl font-bold text-foreground md:text-[44px]">
                {svc.title}
              </h2>
              <p className="mt-5 text-base leading-relaxed text-muted-foreground">
                {svc.description}
              </p>
              <ul className="mt-7 space-y-3">
                {svc.features.map(f => (
                  <li key={f} className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10">
                      <Check className="h-3 w-3 text-primary" strokeWidth={2.5} />
                    </span>
                    <span className="text-sm text-foreground/85">{f}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-9 flex flex-wrap items-center gap-3">
                <Button
                  asChild
                  className="rounded-full bg-primary px-6 text-primary-foreground transition-all duration-200 hover:bg-primary/90 active:scale-[0.97]"
                >
                  <Link href="/contact">
                    Request a Quote
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
                {svc.id === "tax-preparation" && (
                  <a
                    href="#individual-tax-returns"
                    className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 px-5 py-2 text-sm font-medium text-primary transition-colors duration-200 hover:bg-primary/10"
                  >
                    Filing as an individual?
                    <ArrowRight className="h-3.5 w-3.5" />
                  </a>
                )}
              </div>
            </div>
          </div>
        </section>
      ))}

      {/* ————— Individual Tax Returns: process, turnaround, documents ————— */}
      <section
        id="individual-tax-returns"
        className="scroll-mt-24 border-t border-border bg-ink py-24 text-ink-foreground"
      >
        <div className="container">
          <div className="fade-up max-w-3xl">
            <p className="eyebrow">Individual Returns</p>
            <h2 className="mt-4 text-balance font-display text-4xl font-bold md:text-5xl">
              Your personal return, handled remotely
            </h2>
            <p className="mt-5 text-lg leading-relaxed text-ink-foreground/75">
              We prepare individual returns for business owners and for
              individuals who simply want their return done properly. The whole
              process runs remotely —{" "}
              <strong className="font-semibold text-ink-foreground">
                no in-person appointment is required
              </strong>{" "}
              at any stage. Electronic documents are faster and easier to keep
              secure, so that is our default, but if you would rather work from
              paper we will happily process hard copies.
            </p>
          </div>

          {/* Delivery methods */}
          <div className="fade-up mt-12 grid gap-4 sm:grid-cols-2">
            <div className="rounded-xl border border-primary/30 bg-primary/10 p-6">
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/20">
                  <Laptop className="h-4 w-4 text-primary" />
                </span>
                <p className="font-display text-lg font-semibold">
                  Electronic — preferred
                </p>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-ink-foreground/70">
                Upload your documents through our secure client portal. It is
                faster, nothing can be lost in the post, and you keep a
                timestamped record of everything you sent.
              </p>
            </div>
            <div className="rounded-xl border border-ink-foreground/15 bg-ink-foreground/5 p-6">
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-ink-foreground/10">
                  <Mail className="h-4 w-4 text-gold" />
                </span>
                <p className="font-display text-lg font-semibold">
                  Hard copy — also fine
                </p>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-ink-foreground/70">
                Mail or drop off paper forms and we will process them exactly
                the same way. Call or text {SITE.phoneDisplay} first so we can
                tell you where to send them and watch for their arrival.
              </p>
            </div>
          </div>

          {/* How it works */}
          <div className="fade-up mt-16">
            <h3 className="font-display text-2xl font-bold">How it works</h3>
            <ol className="mt-7 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {INDIVIDUAL_TAX_STEPS.map((step, i) => (
                <li
                  key={step.title}
                  className="rounded-xl border border-ink-foreground/12 bg-ink-foreground/[0.04] p-6"
                >
                  <span className="font-display text-sm font-bold text-primary">
                    Step {i + 1}
                  </span>
                  <p className="mt-2 font-semibold">{step.title}</p>
                  <p className="mt-2 text-sm leading-relaxed text-ink-foreground/70">
                    {step.body}
                  </p>
                </li>
              ))}
            </ol>
          </div>

          {/* Turnaround */}
          <div className="fade-up mt-16">
            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-gold" />
              <h3 className="font-display text-2xl font-bold">
                Typical turnaround
              </h3>
            </div>
            <p className="mt-3 max-w-3xl text-sm leading-relaxed text-ink-foreground/70">
              Timings are business days measured from the point where we have a{" "}
              <strong className="font-semibold text-ink-foreground">
                complete
              </strong>{" "}
              set of documents — not from your first message. A missing form is
              the usual reason a return takes longer than expected.
            </p>
            <div className="mt-7 grid gap-4 md:grid-cols-3">
              {INDIVIDUAL_TAX_TURNAROUND.map(t => (
                <div
                  key={t.label}
                  className="rounded-xl border border-ink-foreground/12 bg-ink-foreground/[0.04] p-6"
                >
                  <p className="text-sm font-semibold text-ink-foreground/80">
                    {t.label}
                  </p>
                  <p className="mt-2 font-display text-xl font-bold text-gold">
                    {t.window}
                  </p>
                  <p className="mt-3 text-sm leading-relaxed text-ink-foreground/70">
                    {t.detail}
                  </p>
                </div>
              ))}
            </div>
            <p className="mt-5 max-w-3xl text-sm leading-relaxed text-ink-foreground/60">
              Filing deadlines are fixed, and the weeks immediately before them
              are the busiest of the year. If you send documents close to a
              deadline we will tell you honestly whether the return can be filed
              in time or whether an extension is the sensible route — an
              extension moves the filing date, not the payment date.
            </p>
          </div>

          {/* Document checklist */}
          <div className="fade-up mt-16">
            <div className="flex items-center gap-3">
              <FileText className="h-5 w-5 text-primary" />
              <h3 className="font-display text-2xl font-bold">
                What to send us
              </h3>
            </div>
            <p className="mt-3 max-w-3xl text-sm leading-relaxed text-ink-foreground/70">
              Send what you have and we will tell you what is missing — you do
              not need every item below. Most individual returns are built from
              the first two groups.
            </p>
            <div className="mt-7 grid gap-6 md:grid-cols-2">
              {INDIVIDUAL_TAX_DOCUMENTS.map(group => (
                <div
                  key={group.id}
                  className="rounded-xl border border-ink-foreground/12 bg-ink-foreground/[0.04] p-6"
                >
                  <p className="font-display text-lg font-semibold">
                    {group.title}
                  </p>
                  {group.note && (
                    <p className="mt-1.5 text-xs leading-relaxed text-ink-foreground/55">
                      {group.note}
                    </p>
                  )}
                  <ul className="mt-4 space-y-2.5">
                    {group.items.map(item => (
                      <li key={item} className="flex items-start gap-2.5">
                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                        <span className="text-sm leading-relaxed text-ink-foreground/75">
                          {item}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          <div className="fade-up mt-14 flex flex-wrap items-center gap-4">
            <Button
              asChild
              size="lg"
              className="rounded-full bg-primary px-7 text-primary-foreground transition-all duration-200 hover:bg-primary/90 active:scale-[0.97]"
            >
              <Link href="/contact">
                Start My Individual Return
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="rounded-full border-ink-foreground/25 px-7 text-ink-foreground hover:bg-ink-foreground/10"
            >
              <PhoneLink source="services_individual">
                <Phone className="h-4 w-4" />
                {SITE.phoneDisplay}
              </PhoneLink>
            </Button>
          </div>
        </div>
      </section>

      {/* ————— FAQ ————— */}
      <section id="faq" className="scroll-mt-24 border-t border-border py-24">
        <div className="container">
          <div className="fade-up mx-auto max-w-2xl text-center">
            <p className="eyebrow">Frequently Asked Questions</p>
            <h2 className="mt-4 text-balance font-display text-4xl font-bold text-foreground md:text-5xl">
              Answers before you ask
            </h2>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground">
              The questions we hear most from business owners considering
              Nuumeric. Don't see yours? Call or text {SITE.phoneDisplay}.
            </p>
          </div>
          <div className="fade-up mx-auto mt-12 max-w-3xl">
            <Accordion
              type="single"
              collapsible
              value={openFaq}
              onValueChange={v => setOpenFaq(v || undefined)}
              className="rounded-xl border border-border bg-card px-6 shadow-sm"
            >
              {FAQ_ENTRIES.map(faq => (
                <AccordionItem
                  key={faq.id}
                  value={faq.id}
                  id={`faq-${faq.id}`}
                  className="scroll-mt-28 border-border/70 last:border-b-0"
                >
                  <AccordionTrigger className="py-5 text-left text-base font-semibold text-foreground hover:no-underline">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="pb-5 text-sm leading-relaxed text-muted-foreground">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* ————— Bottom CTA ————— */}
      <section className="border-t border-border bg-secondary py-20">
        <div className="container fade-up text-center">
          <h2 className="text-balance font-display text-3xl font-bold text-foreground md:text-4xl">
            Not sure where to start?
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Call or text {SITE.phoneDisplay} and we'll help you figure out the
            right level of support — no obligation.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <Button
              asChild
              size="lg"
              className="rounded-full bg-gold px-8 font-semibold text-gold-foreground hover:bg-gold/90 active:scale-[0.97]"
            >
              <Link href="/contact">Get a Quote Today</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="rounded-full border-primary/40 px-8 text-primary hover:bg-primary hover:text-primary-foreground"
            >
              <PhoneLink source="services_cta">
                <Phone className="h-4 w-4" />
                {SITE.phoneDisplay}
              </PhoneLink>
            </Button>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
