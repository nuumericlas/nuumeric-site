import { useAuth } from "@/_core/hooks/useAuth";
import Seo from "@/components/Seo";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteNav } from "@/components/SiteNav";
import { StaleReviewAlert } from "@/components/StaleReviewAlert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Spinner } from "@/components/ui/spinner";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import {
  AlertTriangle,
  ArrowLeft,
  Check,
  Inbox,
  Plus,
  ShieldCheck,
  Handshake,
  Trash2,
  X,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";

/** Substring matching means very short phrases catch innocent words. */
const RISKY_LENGTH = 6;
const RISKY_SINGLE_WORDS = [
  "loan",
  "credit",
  "tax",
  "invoice",
  "payroll",
  "money",
  "bank",
  "cash",
  "help",
  "business",
  "service",
  "quote",
  "account",
];

function riskWarning(raw: string): string | null {
  const phrase = raw.trim().toLowerCase();
  if (!phrase) return null;
  if (RISKY_SINGLE_WORDS.includes(phrase)) {
    return `"${phrase}" is a word real clients use — this would block genuine inquiries.`;
  }
  if (!phrase.includes(" ") && phrase.length < RISKY_LENGTH) {
    return "Very short single words match inside other words. Consider a two-word phrase.";
  }
  if (!phrase.includes(" ")) {
    return "Single words match anywhere in a message. Two-word phrases are safer.";
  }
  return null;
}

function reasonLabel(reason: string): { label: string; tone: "phrase" | "other" } {
  if (reason.startsWith("phrase:")) {
    return { label: `Blocked phrase: "${reason.slice(7)}"`, tone: "phrase" };
  }
  const map: Record<string, string> = {
    honeypot: "Hidden field filled (bot)",
    "too-fast": "Submitted too quickly (bot)",
    "too-many-links": "Too many links",
    shouting: "Mostly capital letters",
    "rate-limit": "Too many submissions from one address",
  };
  return { label: map[reason] ?? reason, tone: "other" };
}

type FilteredRow = {
  id: number;
  formType: string;
  reason: string;
  payload: string;
  ip: string | null;
  userAgent: string | null;
  status: string;
  createdAt: Date | string;
};

function PayloadView({ payload }: { payload: string }) {
  const fields = useMemo(() => {
    try {
      const parsed = JSON.parse(payload) as Record<string, unknown>;
      return Object.entries(parsed).filter(([, v]) => v !== null && v !== "");
    } catch {
      return [];
    }
  }, [payload]);

  if (fields.length === 0) {
    return <p className="text-sm text-muted-foreground">Content could not be displayed.</p>;
  }
  return (
    <dl className="grid gap-x-6 gap-y-1.5 text-sm sm:grid-cols-[auto_1fr]">
      {fields.map(([key, value]) => (
        <div key={key} className="sm:col-span-2 sm:grid sm:grid-cols-[10rem_1fr] sm:gap-6">
          <dt className="font-medium capitalize text-muted-foreground">
            {key.replace(/([A-Z])/g, " $1").toLowerCase()}
          </dt>
          <dd className="break-words">{String(value)}</dd>
        </div>
      ))}
    </dl>
  );
}

export default function AdminSpam() {
  const { isAuthenticated, user, loading } = useAuth();
  const utils = trpc.useUtils();
  const [newPhrase, setNewPhrase] = useState("");
  const [newNote, setNewNote] = useState("");
  const [tab, setTab] = useState<"pending" | "released" | "dismissed">("pending");

  const isAdmin = isAuthenticated && user?.role === "admin";
  const phrasesQuery = trpc.spam.listPhrases.useQuery(undefined, { enabled: !!isAdmin });
  const staleQuery = trpc.spam.staleReview.useQuery(undefined, { enabled: !!isAdmin });
  const filteredQuery = trpc.spam.listFiltered.useQuery(
    { status: tab },
    { enabled: !!isAdmin },
  );

  const addMut = trpc.spam.addPhrase.useMutation({
    onSuccess: () => {
      toast.success("Phrase added to the filter");
      setNewPhrase("");
      setNewNote("");
      utils.spam.listPhrases.invalidate();
    },
    onError: err => toast.error(err.message),
  });
  const removeMut = trpc.spam.removePhrase.useMutation({
    onSuccess: () => {
      toast.success("Phrase removed");
      utils.spam.listPhrases.invalidate();
    },
    onError: err => toast.error(err.message),
  });
  const releaseMut = trpc.spam.release.useMutation({
    onSuccess: () => {
      toast.success("Released — the inquiry has been delivered to you");
      utils.spam.listFiltered.invalidate();
      utils.spam.staleReview.invalidate();
    },
    onError: err => toast.error(err.message),
  });
  const dismissMut = trpc.spam.dismiss.useMutation({
    onSuccess: () => {
      toast.success("Marked as spam");
      utils.spam.listFiltered.invalidate();
      utils.spam.staleReview.invalidate();
    },
    onError: err => toast.error(err.message),
  });
  const deleteMut = trpc.spam.remove.useMutation({
    onSuccess: () => {
      toast.success("Deleted");
      utils.spam.listFiltered.invalidate();
      utils.spam.staleReview.invalidate();
    },
    onError: err => toast.error(err.message),
  });

  const warning = riskWarning(newPhrase);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Spinner className="h-6 w-6" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background">
        <Seo title="Spam Filter — Nuumeric" description="Owner-only spam filter management." />
        <SiteNav />
        <main className="container flex min-h-[70vh] flex-col items-center justify-center pt-[72px] text-center">
          <ShieldCheck className="h-10 w-10 text-muted-foreground" />
          <h1 className="mt-4 text-2xl font-bold">Spam filter administration</h1>
          <p className="mt-2 max-w-md text-sm text-muted-foreground">
            {isAuthenticated
              ? "This area is reserved for the site owner. Your account doesn't have admin access."
              : "Please sign in with the site owner account to manage the spam filter."}
          </p>
          {!isAuthenticated && (
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <Button
                className="rounded-full bg-primary px-6 text-primary-foreground hover:bg-primary/90 active:scale-[0.97]"
                onClick={() => startLogin()}
              >
                Sign In as Owner
              </Button>
              <Button
                variant="outline"
                className="rounded-full bg-background px-6 active:scale-[0.97]"
                onClick={() => {
                  window.location.href = "/";
                }}
              >
                Back to the site
              </Button>
            </div>
          )}
        </main>
        <SiteFooter />
      </div>
    );
  }

  const phrases = phrasesQuery.data ?? [];
  const rows = (filteredQuery.data ?? []) as unknown as FilteredRow[];

  return (
    <div className="min-h-screen bg-background">
      <Seo title="Spam Filter — Nuumeric" description="Owner-only spam filter management." />
      <SiteNav />
      <main className="container max-w-4xl pb-24 pt-[120px]">
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
          <Link
            href="/admin/blog"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" /> Blog admin
          </Link>
          <Link
            href="/admin/referrals"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <Handshake className="h-4 w-4" /> Referral credits
          </Link>
        </div>
        <div className="mt-4">
          <p className="eyebrow">Form protection</p>
          <h1 className="mt-1 text-3xl font-bold">Spam filter</h1>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
            Messages caught by the filter are held here instead of reaching you. Review them
            periodically so a genuine inquiry never goes unanswered.
          </p>
          <StaleReviewAlert enabled={!!isAdmin} />
        </div>

        {/* ————— Filtered submissions review ————— */}
        <section className="mt-10">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-xl font-semibold">Held messages</h2>
            <div className="flex gap-1 rounded-full border border-border p-1">
              {(["pending", "released", "dismissed"] as const).map(t => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-sm capitalize transition-colors ${
                    tab === t
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {t === "pending" ? "To review" : t}
                  {t === "pending" && (staleQuery.data?.count ?? 0) > 0 && (
                    <span
                      title={`Waiting longer than ${staleQuery.data?.thresholdHours} hours`}
                      className={`rounded-full px-1.5 text-xs font-semibold ${
                        tab === t
                          ? "bg-primary-foreground/20 text-primary-foreground"
                          : "bg-amber-500/20 text-amber-700 dark:text-amber-400"
                      }`}
                    >
                      {staleQuery.data?.count}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {filteredQuery.isLoading ? (
            <div className="flex justify-center py-16">
              <Spinner className="h-6 w-6" />
            </div>
          ) : rows.length === 0 ? (
            <div className="mt-6 rounded-lg border border-dashed border-border py-16 text-center">
              <Inbox className="mx-auto h-8 w-8 text-muted-foreground" />
              <p className="mt-3 font-medium">
                {tab === "pending" ? "Nothing waiting for review" : `No ${tab} messages`}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                {tab === "pending"
                  ? "The filter hasn't held any messages. Anything it catches will appear here."
                  : "Messages you action will be listed here."}
              </p>
            </div>
          ) : (
            <ul className="mt-6 space-y-4">
              {rows.map(row => {
                const { label, tone } = reasonLabel(row.reason);
                return (
                  <li key={row.id} className="rounded-lg border border-border p-5">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant="outline" className="capitalize">
                        {row.formType === "contact" ? "Quote request" : "Referral"}
                      </Badge>
                      <Badge
                        variant="outline"
                        className={
                          tone === "phrase"
                            ? "border-amber-500/40 text-amber-700 dark:text-amber-400"
                            : "text-muted-foreground"
                        }
                      >
                        {label}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {new Date(row.createdAt).toLocaleString()}
                      </span>
                    </div>

                    <div className="mt-4 rounded-md bg-muted/40 p-4">
                      <PayloadView payload={row.payload} />
                    </div>

                    {row.status === "pending" && (
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          className="gap-1.5 rounded-full bg-primary px-4 text-primary-foreground hover:bg-primary/90 active:scale-[0.97]"
                          disabled={releaseMut.isPending}
                          onClick={() => releaseMut.mutate({ id: row.id })}
                        >
                          <Check className="h-3.5 w-3.5" /> This is genuine — deliver it
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1.5 rounded-full bg-background px-4 active:scale-[0.97]"
                          disabled={dismissMut.isPending}
                          onClick={() => dismissMut.mutate({ id: row.id })}
                        >
                          <X className="h-3.5 w-3.5" /> Confirm spam
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="gap-1.5 rounded-full px-4 text-muted-foreground hover:text-destructive active:scale-[0.97]"
                          disabled={deleteMut.isPending}
                          onClick={() => deleteMut.mutate({ id: row.id })}
                        >
                          <Trash2 className="h-3.5 w-3.5" /> Delete
                        </Button>
                      </div>
                    )}
                    {row.status !== "pending" && (
                      <div className="mt-4 flex items-center justify-between gap-3">
                        <span className="text-xs capitalize text-muted-foreground">
                          {row.status === "released"
                            ? "Released and delivered to you"
                            : "Confirmed spam"}
                        </span>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="gap-1.5 rounded-full px-4 text-muted-foreground hover:text-destructive active:scale-[0.97]"
                          disabled={deleteMut.isPending}
                          onClick={() => deleteMut.mutate({ id: row.id })}
                        >
                          <Trash2 className="h-3.5 w-3.5" /> Delete
                        </Button>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        {/* ————— Blocked phrase manager ————— */}
        <section className="mt-16">
          <h2 className="text-xl font-semibold">Blocked phrases</h2>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
            A message is held if any of these appears anywhere in its text, regardless of
            capitalisation. Two-word phrases are safest — single common words block real clients.
          </p>

          <form
            className="mt-5 flex flex-col gap-3 rounded-lg border border-border p-5 sm:flex-row sm:items-end"
            onSubmit={e => {
              e.preventDefault();
              if (!newPhrase.trim()) return;
              addMut.mutate({ phrase: newPhrase, note: newNote, category: "custom" });
            }}
          >
            <div className="flex-1">
              <Label htmlFor="phrase">Phrase to block</Label>
              <Input
                id="phrase"
                value={newPhrase}
                onChange={e => setNewPhrase(e.target.value)}
                placeholder="e.g. website audit offer"
                className="mt-1.5"
                maxLength={200}
              />
            </div>
            <div className="flex-1">
              <Label htmlFor="note">Note (optional)</Label>
              <Input
                id="note"
                value={newNote}
                onChange={e => setNewNote(e.target.value)}
                placeholder="Why you blocked it"
                className="mt-1.5"
                maxLength={500}
              />
            </div>
            <Button
              type="submit"
              className="gap-1.5 rounded-full bg-primary px-5 text-primary-foreground hover:bg-primary/90 active:scale-[0.97]"
              disabled={addMut.isPending || newPhrase.trim().length < 4}
            >
              <Plus className="h-4 w-4" /> Add
            </Button>
          </form>

          {warning && (
            <p className="mt-3 flex items-start gap-2 text-sm text-amber-700 dark:text-amber-400">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              {warning}
            </p>
          )}

          {phrasesQuery.isLoading ? (
            <div className="flex justify-center py-12">
              <Spinner className="h-6 w-6" />
            </div>
          ) : (
            <ul className="mt-6 divide-y divide-border rounded-lg border border-border">
              {phrases.map(p => (
                <li key={p.id} className="flex flex-wrap items-center gap-3 px-5 py-3">
                  <code className="rounded bg-muted px-2 py-0.5 text-sm">{p.phrase}</code>
                  {p.category && (
                    <Badge variant="outline" className="text-xs text-muted-foreground">
                      {p.category}
                    </Badge>
                  )}
                  {p.note && (
                    <span className="text-xs text-muted-foreground">{p.note}</span>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    className="ml-auto h-8 gap-1.5 rounded-full px-3 text-muted-foreground hover:text-destructive active:scale-[0.97]"
                    disabled={removeMut.isPending}
                    onClick={() => removeMut.mutate({ id: p.id })}
                  >
                    <Trash2 className="h-3.5 w-3.5" /> Remove
                  </Button>
                </li>
              ))}
            </ul>
          )}

          <div className="mt-8 rounded-lg border border-border bg-muted/30 p-5 text-sm text-muted-foreground">
            <p className="font-medium text-foreground">Rules that always apply</p>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              <li>More than one web link in a message</li>
              <li>Text that is over 60% capital letters</li>
              <li>A form completed in under 2.5 seconds (automated)</li>
              <li>A hidden field being filled in (automated)</li>
              <li>More than 5 submissions per hour from one address</li>
            </ul>
            <p className="mt-3">
              These are not editable here. Non-English messages are never penalised.
            </p>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
