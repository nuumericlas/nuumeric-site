import { useAuth } from "@/_core/hooks/useAuth";
import Seo from "@/components/Seo";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteNav } from "@/components/SiteNav";
import { StaleReviewAlert } from "@/components/StaleReviewAlert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { startLogin } from "@/const";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Spinner } from "@/components/ui/spinner";
import { Textarea } from "@/components/ui/textarea";
import { formatPostDate } from "@/lib/blogFormat";
import { trpc } from "@/lib/trpc";
import {
  ArrowLeft,
  Eye,
  FileText,
  History,
  Handshake,
  ImagePlus,
  Pencil,
  Plus,
  ShieldCheck,
  Trash2,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Streamdown } from "streamdown";
import { toast } from "sonner";
import { Link } from "wouter";

interface EditorState {
  id?: number;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  coverImageUrl: string;
  category: string;
  tags: string;
  seoTitle: string;
  seoDescription: string;
  status: "draft" | "published";
}

const EMPTY: EditorState = {
  title: "",
  slug: "",
  excerpt: "",
  content: "",
  coverImageUrl: "",
  category: "",
  tags: "",
  seoTitle: "",
  seoDescription: "",
  status: "draft",
};

// ————— Local draft backup (crash / session-expiry protection) —————
const BACKUP_PREFIX = "nuumeric-blog-backup:";
const backupKey = (id?: number) => `${BACKUP_PREFIX}${id ?? "new"}`;

function readBackup(id?: number): { state: EditorState; savedAt: number } | null {
  try {
    const raw = localStorage.getItem(backupKey(id));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { state: EditorState; savedAt: number };
    if (!parsed?.state || typeof parsed.savedAt !== "number") return null;
    return parsed;
  } catch {
    return null;
  }
}

function writeBackup(state: EditorState) {
  try {
    localStorage.setItem(
      backupKey(state.id),
      JSON.stringify({ state, savedAt: Date.now() }),
    );
  } catch {
    // localStorage full or unavailable — nothing else we can do
  }
}

function clearBackup(id?: number) {
  try {
    localStorage.removeItem(backupKey(id));
  } catch {
    // ignore
  }
}

function backupHasContent(state: EditorState): boolean {
  return Boolean(state.title.trim() || state.content.trim() || state.excerpt.trim());
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.slice(result.indexOf(",") + 1));
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export default function AdminBlog() {
  const { user, loading, isAuthenticated } = useAuth();
  const [editing, setEditing] = useState<EditorState | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [restoreOffer, setRestoreOffer] = useState<{
    state: EditorState;
    savedAt: number;
  } | null>(null);
  const [sessionExpired, setSessionExpired] = useState(false);

  // Continuously back up the editor state locally so an expired session,
  // closed tab, or crash never loses written work.
  useEffect(() => {
    if (!editing) return;
    const t = setTimeout(() => {
      if (backupHasContent(editing)) writeBackup(editing);
    }, 800);
    return () => clearTimeout(t);
  }, [editing]);

  // Warn before closing the tab with unsaved-to-server work in the editor.
  useEffect(() => {
    if (!editing) return;
    const handler = (e: BeforeUnloadEvent) => {
      if (backupHasContent(editing)) e.preventDefault();
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [editing]);

  /** Detect an auth failure from a mutation and switch to recovery mode. */
  function handleMutationError(e: { message: string; data?: { code?: string } | null }) {
    if (e.data?.code === "UNAUTHORIZED" || e.data?.code === "FORBIDDEN") {
      setSessionExpired(true);
      toast.error(
        "Your session expired — your work is backed up on this device. Sign in again, then save.",
        { duration: 10000 },
      );
    } else {
      toast.error(e.message);
    }
  }

  const utils = trpc.useUtils();
  const listQuery = trpc.blog.admin.list.useQuery(undefined, {
    enabled: !!user && user.role === "admin",
  });

  const invalidateAll = () => {
    utils.blog.admin.list.invalidate();
    utils.blog.list.invalidate();
  };

  const createMut = trpc.blog.admin.create.useMutation({
    onSuccess: (res, vars) => {
      invalidateAll();
      clearBackup(undefined);
      setEditing(prev => (prev ? { ...prev, id: res.id, slug: res.slug } : prev));
      toast.success(`Draft saved${vars.slug !== res.slug ? ` (slug: ${res.slug})` : ""}`);
    },
    onError: handleMutationError,
  });
  const updateMut = trpc.blog.admin.update.useMutation({
    onSuccess: res => {
      invalidateAll();
      setEditing(prev => (prev ? { ...prev, slug: res.slug } : prev));
      if (editing?.id) clearBackup(editing.id);
      toast.success("Post saved");
    },
    onError: handleMutationError,
  });
  const statusMut = trpc.blog.admin.setStatus.useMutation({
    onSuccess: (_res, vars) => {
      invalidateAll();
      setEditing(prev => (prev ? { ...prev, status: vars.status } : prev));
      toast.success(vars.status === "published" ? "Post published" : "Moved to drafts");
    },
    onError: e => toast.error(e.message),
  });
  const deleteMut = trpc.blog.admin.delete.useMutation({
    onSuccess: () => {
      invalidateAll();
      toast.success("Post deleted");
    },
    onError: handleMutationError,
  });
  const uploadMut = trpc.blog.admin.uploadImage.useMutation({
    onError: handleMutationError,
  });

  const utilsGet = utils.blog.admin.get;

  /** Open the editor for a brand-new post, offering to restore a local backup. */
  function openNewPost() {
    const backup = readBackup(undefined);
    setEditing({ ...EMPTY });
    setShowPreview(false);
    setSessionExpired(false);
    setRestoreOffer(backup && backupHasContent(backup.state) ? backup : null);
  }

  /** Open the editor for an existing post, fetching its full body first. */
  async function openForEdit(id: number) {
    try {
      const post = await utilsGet.fetch({ id });
      const backup = readBackup(id);
      setEditing({
        id: post.id,
        title: post.title,
        slug: post.slug,
        excerpt: post.excerpt ?? "",
        content: post.content,
        coverImageUrl: post.coverImageUrl ?? "",
        category: post.category ?? "",
        tags: post.tags ?? "",
        seoTitle: post.seoTitle ?? "",
        seoDescription: post.seoDescription ?? "",
        status: post.status,
      });
      setShowPreview(false);
      setSessionExpired(false);
      // Offer the local backup only if it's newer than the server copy.
      setRestoreOffer(
        backup &&
          backupHasContent(backup.state) &&
          backup.savedAt > new Date(post.updatedAt as unknown as string).getTime()
          ? backup
          : null,
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not load the post");
    }
  }

  const coverInputRef = useRef<HTMLInputElement>(null);
  const bodyImageInputRef = useRef<HTMLInputElement>(null);
  const contentRef = useRef<HTMLTextAreaElement>(null);

  const saving = createMut.isPending || updateMut.isPending;

  async function handleImageFile(file: File, target: "cover" | "body") {
    if (!file.type.startsWith("image/")) {
      toast.error("Please choose an image file");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image must be 5MB or smaller");
      return;
    }
    const base64 = await fileToBase64(file);
    const res = await uploadMut.mutateAsync({
      fileName: file.name,
      contentType: file.type,
      base64,
    });
    if (target === "cover") {
      setEditing(prev => (prev ? { ...prev, coverImageUrl: res.url } : prev));
      toast.success("Cover image uploaded");
    } else {
      // Insert markdown at the cursor position in the content textarea.
      const md = `\n\n![${file.name.replace(/\.[^.]+$/, "")}](${res.url})\n\n`;
      setEditing(prev => {
        if (!prev) return prev;
        const el = contentRef.current;
        const pos = el ? el.selectionStart : prev.content.length;
        return {
          ...prev,
          content: prev.content.slice(0, pos) + md + prev.content.slice(pos),
        };
      });
      toast.success("Image inserted into the article");
    }
  }

  function save() {
    if (!editing) return;
    if (!editing.title.trim()) {
      toast.error("Please add a title first");
      return;
    }
    if (!editing.content.trim()) {
      toast.error("The article body is empty");
      return;
    }
    const payload = {
      title: editing.title,
      slug: editing.slug,
      excerpt: editing.excerpt,
      content: editing.content,
      coverImageUrl: editing.coverImageUrl,
      category: editing.category,
      tags: editing.tags,
      seoTitle: editing.seoTitle,
      seoDescription: editing.seoDescription,
    };
    if (editing.id) {
      updateMut.mutate({ id: editing.id, ...payload });
    } else {
      createMut.mutate(payload);
    }
  }

  // ————— Access gating —————
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Spinner className="h-6 w-6" />
      </div>
    );
  }
  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background">
        <Seo title="Blog Admin — Nuumeric" description="Owner-only blog management." />
        <SiteNav />
        <main className="container flex min-h-[70vh] flex-col items-center justify-center pt-[72px] text-center">
          <FileText className="h-10 w-10 text-muted-foreground" />
          <h1 className="mt-4 text-2xl font-bold">Blog administration</h1>
          <p className="mt-2 max-w-md text-sm text-muted-foreground">
            {isAuthenticated
              ? "This area is reserved for the site owner. Your account doesn't have admin access."
              : "Please sign in with the site owner account to manage blog posts."}
          </p>
          {!isAuthenticated && (
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <Button
                className="rounded-full bg-primary px-6 text-primary-foreground hover:bg-primary/90 active:scale-[0.97]"
                onClick={() => startLogin()}
              >
                Sign In as Owner
              </Button>
              <Button
                variant="outline"
                className="rounded-full bg-background px-6 active:scale-[0.97]"
                onClick={() => {
                  window.location.href = "/blog";
                }}
              >
                Back to the blog
              </Button>
            </div>
          )}
        </main>
        <SiteFooter />
      </div>
    );
  }

  // ————— Editor view —————
  if (editing) {
    return (
      <div className="min-h-screen bg-background">
        <Seo title="Edit Post — Nuumeric Blog Admin" description="Blog post editor." />
        <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
          <div className="container flex h-14 items-center justify-between gap-3">
            <button
              onClick={() => {
                if (
                  backupHasContent(editing) &&
                  !window.confirm(
                    "Leave the editor? Your work is backed up on this device, but unsaved changes are not yet published to the blog.",
                  )
                ) {
                  return;
                }
                setEditing(null);
                setRestoreOffer(null);
              }}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-foreground/70 hover:text-primary"
            >
              <ArrowLeft className="h-4 w-4" /> All posts
            </button>
            <div className="flex items-center gap-2">
              <Badge variant={editing.status === "published" ? "default" : "secondary"}>
                {editing.status === "published" ? "Published" : "Draft"}
              </Badge>
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                onClick={() => setShowPreview(p => !p)}
              >
                <Eye className="h-4 w-4" /> {showPreview ? "Edit" : "Preview"}
              </Button>
              <Button size="sm" onClick={save} disabled={saving}>
                {saving ? <Spinner className="h-4 w-4" /> : "Save"}
              </Button>
              {editing.id && editing.status === "draft" && (
                <Button
                  size="sm"
                  className="bg-gold text-gold-foreground hover:bg-gold/90"
                  disabled={statusMut.isPending}
                  onClick={() => statusMut.mutate({ id: editing.id!, status: "published" })}
                >
                  Publish
                </Button>
              )}
              {editing.id && editing.status === "published" && (
                <Button
                  size="sm"
                  variant="outline"
                  disabled={statusMut.isPending}
                  onClick={() => statusMut.mutate({ id: editing.id!, status: "draft" })}
                >
                  Unpublish
                </Button>
              )}
            </div>
          </div>
        </header>

        <main className="container max-w-4xl py-8">
          {sessionExpired && (
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-destructive/40 bg-destructive/10 p-4 text-sm">
              <p className="font-medium">
                Your session expired, but your work is safely backed up on this
                device. Sign in again in a new tab, then come back and hit Save.
              </p>
              <Button
                size="sm"
                className="rounded-full"
                onClick={() => window.open("/admin/blog", "_blank")}
              >
                Sign in (new tab)
              </Button>
            </div>
          )}
          {restoreOffer && (
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-gold/50 bg-gold/10 p-4 text-sm">
              <p className="font-medium">
                <History className="mr-1.5 inline h-4 w-4" />
                Found an unsaved backup from{" "}
                {new Date(restoreOffer.savedAt).toLocaleString()} on this device.
                Restore it?
              </p>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  className="rounded-full"
                  onClick={() => {
                    setEditing({ ...restoreOffer.state, id: editing.id ?? restoreOffer.state.id });
                    setRestoreOffer(null);
                    toast.success("Backup restored — review it, then Save");
                  }}
                >
                  Restore backup
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="rounded-full"
                  onClick={() => {
                    clearBackup(editing.id);
                    setRestoreOffer(null);
                  }}
                >
                  <X className="mr-1 h-3.5 w-3.5" /> Discard
                </Button>
              </div>
            </div>
          )}
          {showPreview ? (
            <article>
              {editing.coverImageUrl && (
                <img
                  src={editing.coverImageUrl}
                  alt=""
                  className="mb-8 aspect-[2/1] w-full rounded-lg object-cover"
                />
              )}
              <h1 className="text-3xl font-bold">{editing.title || "Untitled post"}</h1>
              <div className="prose-nuumeric mt-6">
                <Streamdown>{editing.content || "*Nothing written yet.*"}</Streamdown>
              </div>
            </article>
          ) : (
            <div className="space-y-6">
              <div>
                <Label htmlFor="post-title">Title</Label>
                <Input
                  id="post-title"
                  className="mt-1.5 text-lg font-semibold"
                  placeholder="e.g. Zoho Books vs. Xero: which fits your business?"
                  value={editing.title}
                  onChange={e => setEditing({ ...editing, title: e.target.value })}
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="post-category">Category</Label>
                  <Input
                    id="post-category"
                    className="mt-1.5"
                    placeholder="e.g. Bookkeeping"
                    value={editing.category}
                    onChange={e => setEditing({ ...editing, category: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="post-tags">Tags (comma-separated)</Label>
                  <Input
                    id="post-tags"
                    className="mt-1.5"
                    placeholder="e.g. zoho books, migration, small business"
                    value={editing.tags}
                    onChange={e => setEditing({ ...editing, tags: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label>Cover image</Label>
                <div className="mt-1.5 flex items-start gap-3">
                  {editing.coverImageUrl ? (
                    <img
                      src={editing.coverImageUrl}
                      alt="Cover"
                      className="h-24 w-40 rounded-md border border-border object-cover"
                    />
                  ) : (
                    <div className="flex h-24 w-40 items-center justify-center rounded-md border border-dashed border-border text-xs text-muted-foreground">
                      No cover yet
                    </div>
                  )}
                  <div className="flex flex-col gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="gap-1.5"
                      disabled={uploadMut.isPending}
                      onClick={() => coverInputRef.current?.click()}
                    >
                      {uploadMut.isPending ? (
                        <Spinner className="h-4 w-4" />
                      ) : (
                        <ImagePlus className="h-4 w-4" />
                      )}
                      Upload cover
                    </Button>
                    {editing.coverImageUrl && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => setEditing({ ...editing, coverImageUrl: "" })}
                      >
                        Remove
                      </Button>
                    )}
                  </div>
                  <input
                    ref={coverInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={e => {
                      const f = e.target.files?.[0];
                      if (f) void handleImageFile(f, "cover");
                      e.target.value = "";
                    }}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="post-excerpt">Excerpt (shown on the blog index)</Label>
                <Textarea
                  id="post-excerpt"
                  className="mt-1.5"
                  rows={2}
                  placeholder="One or two sentences summarizing the article."
                  value={editing.excerpt}
                  onChange={e => setEditing({ ...editing, excerpt: e.target.value })}
                />
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="post-content">Article body (Markdown)</Label>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="gap-1.5 text-xs"
                    disabled={uploadMut.isPending}
                    onClick={() => bodyImageInputRef.current?.click()}
                  >
                    <ImagePlus className="h-3.5 w-3.5" /> Insert image
                  </Button>
                  <input
                    ref={bodyImageInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={e => {
                      const f = e.target.files?.[0];
                      if (f) void handleImageFile(f, "body");
                      e.target.value = "";
                    }}
                  />
                </div>
                <Textarea
                  id="post-content"
                  ref={contentRef}
                  className="mt-1.5 min-h-[420px] font-mono text-sm leading-relaxed"
                  placeholder={"## Start writing...\n\nUse Markdown: **bold**, *italic*, [links](https://example.com), lists, and headings. Click Preview to see the result."}
                  value={editing.content}
                  onChange={e => setEditing({ ...editing, content: e.target.value })}
                />
              </div>

              <div className="rounded-lg border border-border bg-card p-4">
                <p className="text-sm font-semibold">SEO overrides (optional)</p>
                <div className="mt-3 space-y-4">
                  <div>
                    <Label htmlFor="post-slug">URL slug</Label>
                    <Input
                      id="post-slug"
                      className="mt-1.5 font-mono text-sm"
                      placeholder="auto-generated-from-title"
                      value={editing.slug}
                      onChange={e => setEditing({ ...editing, slug: e.target.value })}
                    />
                    <p className="mt-1 text-xs text-muted-foreground">
                      Leave blank to generate from the title. The post will live at
                      /blog/{editing.slug || "your-slug"}.
                    </p>
                  </div>
                  <div>
                    <Label htmlFor="post-seo-title">SEO title</Label>
                    <Input
                      id="post-seo-title"
                      className="mt-1.5"
                      placeholder="Defaults to the post title"
                      value={editing.seoTitle}
                      onChange={e => setEditing({ ...editing, seoTitle: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="post-seo-desc">SEO description</Label>
                    <Textarea
                      id="post-seo-desc"
                      className="mt-1.5"
                      rows={2}
                      placeholder="Defaults to the excerpt"
                      value={editing.seoDescription}
                      onChange={e =>
                        setEditing({ ...editing, seoDescription: e.target.value })
                      }
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    );
  }

  // ————— List view —————
  const posts = listQuery.data ?? [];
  return (
    <div className="min-h-screen bg-background">
      <Seo title="Blog Admin — Nuumeric" description="Owner-only blog management." />
      <SiteNav />
      <main className="container max-w-4xl pb-24 pt-[120px]">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="eyebrow">Blog admin</p>
            <h1 className="mt-1 text-3xl font-bold">Manage posts</h1>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <StaleReviewAlert variant="link" enabled={user?.role === "admin"} />
            <Link
              href="/admin/referrals"
              className="inline-flex items-center gap-1.5 rounded-full border border-border px-4 py-2 text-sm transition-colors hover:bg-muted"
            >
              <Handshake className="h-4 w-4" /> Referral credits
            </Link>
            <Link
              href="/admin/spam"
              className="inline-flex items-center gap-1.5 rounded-full border border-border px-4 py-2 text-sm transition-colors hover:bg-muted"
            >
              <ShieldCheck className="h-4 w-4" /> Spam filter
            </Link>
            <Button
              className="gap-1.5 rounded-full bg-primary px-5 text-primary-foreground hover:bg-primary/90"
              onClick={openNewPost}
            >
              <Plus className="h-4 w-4" /> New post
            </Button>
          </div>
        </div>

        {listQuery.isLoading ? (
          <div className="flex justify-center py-20">
            <Spinner className="h-6 w-6" />
          </div>
        ) : posts.length === 0 ? (
          <div className="mt-10 rounded-lg border border-dashed border-border py-16 text-center">
            <FileText className="mx-auto h-8 w-8 text-muted-foreground" />
            <p className="mt-3 font-medium">No posts yet</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Click "New post" to write your first article.
            </p>
          </div>
        ) : (
          <div className="mt-8 divide-y divide-border rounded-lg border border-border bg-card">
            {posts.map(post => (
              <div
                key={post.id}
                className="flex flex-wrap items-center justify-between gap-3 p-4"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="truncate font-semibold">{post.title}</p>
                    <Badge
                      variant={post.status === "published" ? "default" : "secondary"}
                      className="shrink-0"
                    >
                      {post.status}
                    </Badge>
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    /blog/{post.slug}
                    {post.publishedAt
                      ? ` · published ${formatPostDate(post.publishedAt)}`
                      : ` · updated ${formatPostDate(post.updatedAt)}`}
                    {post.category ? ` · ${post.category}` : ""}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-1.5">
                  {post.status === "published" && (
                    <Button asChild variant="ghost" size="sm" className="gap-1">
                      <Link href={`/blog/${post.slug}`}>
                        <Eye className="h-4 w-4" /> View
                      </Link>
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1"
                    onClick={() => void openForEdit(post.id)}
                  >
                    <Pencil className="h-4 w-4" /> Edit
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    disabled={deleteMut.isPending}
                    onClick={() => {
                      if (
                        window.confirm(
                          `Delete "${post.title}"? This cannot be undone.`,
                        )
                      ) {
                        deleteMut.mutate({ id: post.id });
                      }
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
