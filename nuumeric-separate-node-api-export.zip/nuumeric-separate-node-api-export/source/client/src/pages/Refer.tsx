import { SiteLayout } from "@/components/SiteLayout";
import Seo from "@/components/Seo";
import { HoneypotField } from "@/components/HoneypotField";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { trackConversion } from "@/lib/conversions";
import { REFERRAL, SITE } from "@shared/site";
import {
  BadgeDollarSign,
  CheckCircle2,
  Gift,
  HandCoins,
  Loader2,
  Send,
  Users,
} from "lucide-react";
import { useRef, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";

const HOW_IT_WORKS = [
  {
    icon: Users,
    title: "Tell us who to call",
    text: "Share the business's name and a way to reach them — that's all we need to get started.",
  },
  {
    icon: Gift,
    title: "We take it from there",
    text: "We'll reach out within one business day, mention you sent them, and put together a tailored quote.",
  },
  {
    icon: HandCoins,
    title: `You earn ${REFERRAL.creditDisplay}`,
    text: "Once they complete their first paid month, the credit lands on your next invoice automatically.",
  },
] as const;

export default function Refer() {
  const [form, setForm] = useState({
    referrerName: "",
    referrerEmail: "",
    referrerPhone: "",
    referredBusiness: "",
    referredContact: "",
    referredEmail: "",
    referredPhone: "",
    notes: "",
  });
  const [hp, setHp] = useState("");
  const formLoadedAt = useRef(Date.now());
  const [submitted, setSubmitted] = useState(false);

  const submitMutation = trpc.referral.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Referral received — thank you!");
      trackConversion("referral", { source: "refer_page" });
    },
    onError: err => {
      toast.error(err.message || "Something went wrong. Please try again.");
    },
  });

  const set = (key: keyof typeof form) => (value: string) =>
    setForm(f => ({ ...f, [key]: value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !form.referrerName.trim() ||
      !form.referrerEmail.trim() ||
      !form.referredBusiness.trim()
    ) {
      toast.error(
        "Please fill in your name, your email, and the business you're referring.",
      );
      return;
    }
    if (
      !form.referredEmail.trim() &&
      !form.referredPhone.trim() &&
      !form.referredContact.trim()
    ) {
      toast.error(
        "Please give us at least one way to reach them — a contact name, email, or phone.",
      );
      return;
    }
    submitMutation.mutate({ ...form, hp, formLoadedAt: formLoadedAt.current });
  };

  return (
    <SiteLayout>
      <Seo
        title={`Refer a Business — Earn ${REFERRAL.creditDisplay} | Nuumeric Inc`}
        description={`Refer a business to Nuumeric and earn a ${REFERRAL.creditDisplay} credit toward your next invoice when they sign up for services.`}
      />

      {/* ————— Page Header ————— */}
      <section className="bg-ink pt-40 pb-20 text-ink-foreground">
        <div className="container">
          <p className="eyebrow fade-up">Client Referral Program</p>
          <h1 className="fade-up mt-4 max-w-3xl text-balance font-display text-5xl font-bold leading-[1.08] md:text-6xl">
            Refer a business, earn {REFERRAL.creditDisplay}
          </h1>
          <p className="fade-up mt-5 max-w-2xl text-lg leading-relaxed text-ink-foreground/75">
            Our best clients come from people like you. When a business you
            refer signs up for services, we apply a{" "}
            {REFERRAL.creditDisplay} credit toward your next invoice — every
            time, with no limit.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="container grid gap-14 lg:grid-cols-[1fr_1.4fr]">
          {/* ————— How it works ————— */}
          <div className="fade-up">
            <p className="eyebrow">How It Works</p>
            <h2 className="mt-3 font-display text-3xl font-bold text-foreground">
              Three steps, one thank-you
            </h2>
            <div className="mt-8 space-y-7">
              {HOW_IT_WORKS.map(({ icon: Icon, title, text }) => (
                <div key={title} className="flex items-start gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" strokeWidth={1.75} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                      {text}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-9 rounded-lg border border-border bg-secondary p-5">
              <div className="flex items-center gap-2">
                <BadgeDollarSign className="h-4 w-4 text-primary" strokeWidth={1.75} />
                <p className="text-sm font-semibold text-foreground">The fine print (kept short)</p>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {REFERRAL.terms} Prefer not to fill out a form? Just have them
                mention your name when they{" "}
                <Link href="/contact" className="font-medium text-primary hover:underline">
                  request a quote
                </Link>
                , or call or text us at {SITE.phoneDisplay}.
              </p>
            </div>
          </div>

          {/* ————— Referral Form ————— */}
          <div className="fade-up">
            {submitted ? (
              <div className="flex h-full flex-col items-center justify-center rounded-xl border border-border bg-card px-8 py-20 text-center">
                <CheckCircle2 className="h-12 w-12 text-primary" strokeWidth={1.5} />
                <h2 className="mt-5 font-display text-2xl font-bold text-card-foreground">
                  Referral received — thank you!
                </h2>
                <p className="mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  We'll reach out to {form.referredBusiness.trim() || "them"}{" "}
                  within one business day and mention you sent them. Once they
                  complete their first paid month, your{" "}
                  {REFERRAL.creditDisplay} credit will be applied to your next
                  invoice.
                </p>
                <Button
                  className="mt-7 rounded-full"
                  variant="outline"
                  onClick={() => {
                    setSubmitted(false);
                    setForm(f => ({
                      ...f,
                      referredBusiness: "",
                      referredContact: "",
                      referredEmail: "",
                      referredPhone: "",
                      notes: "",
                    }));
                  }}
                >
                  Refer another business
                </Button>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="rounded-xl border border-border bg-card p-7 md:p-9"
              >
                <h2 className="font-display text-2xl font-bold text-card-foreground">
                  Submit a referral
                </h2>
                <p className="mt-1.5 text-sm text-muted-foreground">
                  Fields marked * are required.
                </p>

                <HoneypotField value={hp} onChange={setHp} />

                <p className="mt-7 text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                  About you
                </p>
                <div className="mt-3 grid gap-5 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="referrerName">Your name *</Label>
                    <Input
                      id="referrerName"
                      placeholder="Jane Smith"
                      value={form.referrerName}
                      onChange={e => set("referrerName")(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="referrerEmail">Your email *</Label>
                    <Input
                      id="referrerEmail"
                      type="email"
                      placeholder="jane@company.com"
                      value={form.referrerEmail}
                      onChange={e => set("referrerEmail")(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="referrerPhone">Your phone (optional)</Label>
                    <Input
                      id="referrerPhone"
                      type="tel"
                      placeholder="(555) 123-4567"
                      value={form.referrerPhone}
                      onChange={e => set("referrerPhone")(e.target.value)}
                    />
                  </div>
                </div>

                <p className="mt-8 text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                  The business you're referring
                </p>
                <div className="mt-3 grid gap-5 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="referredBusiness">Business name *</Label>
                    <Input
                      id="referredBusiness"
                      placeholder="Acme Dental, LLC"
                      value={form.referredBusiness}
                      onChange={e => set("referredBusiness")(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="referredContact">Contact person</Label>
                    <Input
                      id="referredContact"
                      placeholder="John Doe"
                      value={form.referredContact}
                      onChange={e => set("referredContact")(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="referredEmail">Their email</Label>
                    <Input
                      id="referredEmail"
                      type="email"
                      placeholder="john@acmedental.com"
                      value={form.referredEmail}
                      onChange={e => set("referredEmail")(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="referredPhone">Their phone</Label>
                    <Input
                      id="referredPhone"
                      type="tel"
                      placeholder="(555) 987-6543"
                      value={form.referredPhone}
                      onChange={e => set("referredPhone")(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="notes">
                      What might they need help with? (optional)
                    </Label>
                    <Textarea
                      id="notes"
                      rows={4}
                      placeholder="e.g. They're drowning in bookkeeping and mentioned payroll headaches…"
                      value={form.notes}
                      onChange={e => set("notes")(e.target.value)}
                    />
                  </div>
                </div>

                <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
                  Please give us at least one way to reach them — a contact
                  name, email, or phone number.
                </p>

                <Button
                  type="submit"
                  size="lg"
                  disabled={submitMutation.isPending}
                  className="mt-6 h-12 rounded-full bg-primary px-8 text-base font-semibold text-primary-foreground transition-all duration-200 hover:bg-primary/90 active:scale-[0.97]"
                >
                  {submitMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                  Send Referral
                </Button>
              </form>
            )}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
