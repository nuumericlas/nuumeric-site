import { CredentialsBar } from "@/components/CredentialsBar";
import { PhoneLink } from "@/components/PhoneLink";
import { SiteLayout } from "@/components/SiteLayout";
import { Button } from "@/components/ui/button";
import { useJsonLd } from "@/hooks/useJsonLd";
import {
  BUSINESS_HOURS,
  REFERRAL,
  SITE,
  formatStreetAddress,
} from "@shared/site";
import {
  ArrowRight,
  BookOpenCheck,
  Building2,
  Calculator,
  Car,
  FileSpreadsheet,
  HandCoins,
  Layers,
  Phone,
  ShoppingBag,
  Stethoscope,
  TrendingUp,
  Users,
  UtensilsCrossed,
  Warehouse,
} from "lucide-react";
import { useEffect } from "react";
import { Link } from "wouter";

const HERO_IMG_DESKTOP = "/manus-storage/nuumeric_hero_desktop_7f0f7119.webp";
const HERO_IMG_MOBILE = "/manus-storage/nuumeric_hero_mobile_30a25777.webp";
const INDUSTRIES_IMG = "/manus-storage/nuumeric_industries_57e364fa.png";

const SERVICES = [
  {
    title: "Bookkeeping",
    icon: BookOpenCheck,
    href: "/services#bookkeeping",
    blurb:
      "Accurate books, clean reconciliations, and clear financial reporting — so you always know where your business stands.",
  },
  {
    title: "Tax Preparation",
    icon: Calculator,
    href: "/services#tax-preparation",
    blurb:
      "Thorough, deadline-ready tax preparation for small businesses and individuals, backed by decades of hands-on experience.",
  },
  {
    title: "Payroll Processing",
    icon: HandCoins,
    href: "/services#payroll-processing",
    blurb:
      "Reliable, on-time payroll through trusted platforms — your team gets paid correctly, every time.",
  },
  {
    title: "Additional Services",
    icon: Layers,
    href: "/services#additional-services",
    blurb:
      "Zoho CRM and Sites support, Xero, QuickBooks, invoicing, HR, and more — flexible support that scales with you.",
  },
];

const INDUSTRIES = [
  { label: "Medical & Professional Services", icon: Stethoscope },
  { label: "Wholesale Distributors", icon: Warehouse },
  { label: "Auto Repair & Body Shops", icon: Car },
  { label: "Restaurants", icon: UtensilsCrossed },
  { label: "B2B Services", icon: Users },
  { label: "Online Retail", icon: ShoppingBag },
  { label: "Holding Companies", icon: Building2 },
  { label: "Manufacturers", icon: FileSpreadsheet },
];

export default function Home() {
  // LocalBusiness structured data for search engines (Google/Bing rich results)
  useJsonLd("jsonld-local-business", {
    "@context": "https://schema.org",
    "@type": "AccountingService",
    "@id": "https://www.nuumeric.com/#organization",
    name: SITE.legalName,
    alternateName: SITE.formerName,
    url: "https://www.nuumeric.com/",
    telephone: "+19363375446",
    foundingDate: SITE.foundingYear,
    description:
      "US-based back-office support for growing enterprises — bookkeeping, business and individual tax preparation, payroll processing, and financial reporting.",
    address: {
      "@type": "PostalAddress",
      // Google matches the suite line, so keep it in streetAddress rather than
      // dropping it — the sign, the Business Profile, and this markup must agree.
      streetAddress: formatStreetAddress(),
      addressLocality: SITE.address.city,
      addressRegion: SITE.address.region,
      postalCode: SITE.address.postalCode,
      addressCountry: SITE.address.country,
    },
    openingHoursSpecification: {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: [...BUSINESS_HOURS.schemaDays],
      opens: BUSINESS_HOURS.schemaOpens,
      closes: BUSINESS_HOURS.schemaCloses,
    },
    sameAs: [
      SITE.social.linkedin,
      SITE.social.instagram,
      SITE.social.facebook,
    ],
    priceRange: "$$",
    knowsAbout: [
      "Bookkeeping",
      "Tax Preparation",
      "Individual Tax Return Preparation",
      "Small Business Tax Return Preparation",
      "Payroll Processing",
      "Zoho Books",
      "Xero",
      "QuickBooks",
    ],
  });

  // Smooth-scroll to a section when arriving with a hash (e.g. /#industries)
  useEffect(() => {
    const hash = window.location.hash.replace("#", "");
    if (!hash) return;
    const t = setTimeout(() => {
      document
        .getElementById(hash)
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 150);
    return () => clearTimeout(t);
  }, []);

  return (
    <SiteLayout>
      {/* ————— Hero ————— */}
      <section className="relative flex min-h-[92vh] items-center overflow-hidden">
        <img
          src={HERO_IMG_DESKTOP}
          srcSet={`${HERO_IMG_MOBILE} 828w, ${HERO_IMG_DESKTOP} 1920w`}
          sizes="100vw"
          alt=""
          aria-hidden
          fetchPriority="high"
          decoding="async"
          className="absolute inset-0 h-full w-full object-cover object-center"
        />
        <div
          className="absolute inset-0 bg-gradient-to-r from-ink/92 via-ink/72 to-ink/25"
          aria-hidden
        />
        <div className="container relative z-10 pt-24 pb-16">
          <div className="max-w-2xl">
            <p className="eyebrow fade-up">US-Based Back-Office Support</p>
            <h1 className="fade-up mt-5 text-balance font-display text-5xl font-bold leading-[1.05] text-ink-foreground md:text-6xl lg:text-7xl">
              Expert Solutions for Growing Enterprises
            </h1>
            <p className="fade-up mt-6 max-w-xl text-lg leading-relaxed text-ink-foreground/80">
              Your focus is on driving revenue. Ours is everything behind it —
              dedicated US-based team members handling your bookkeeping,
              reconciliations, invoicing, and payroll, scaling up or down as
              your needs change.
            </p>
            <div className="fade-up mt-10 flex flex-wrap items-center gap-4">
              <Button
                asChild
                size="lg"
                className="h-13 rounded-full bg-gold px-8 text-base font-semibold text-gold-foreground shadow-lg shadow-gold/25 transition-all duration-200 hover:bg-gold/90 active:scale-[0.97]"
              >
                <Link href="/contact">
                  Request a Quote
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="h-13 rounded-full border-ink-foreground/30 px-8 text-base text-ink-foreground transition-all duration-200 hover:bg-ink-foreground/10 hover:text-ink-foreground active:scale-[0.97]"
              >
                <Link href="/services">Browse Our Services</Link>
              </Button>
            </div>
            <PhoneLink
              source="hero"
              className="fade-up mt-8 inline-flex items-center gap-2 text-sm font-medium text-ink-foreground/70 transition-colors hover:text-gold"
            >
              <Phone className="h-4 w-4 text-gold" strokeWidth={1.75} />
              Call or Text {SITE.phoneDisplay}
            </PhoneLink>
          </div>
        </div>
      </section>

      {/* ————— Trust & Credentials Bar ————— */}
      <CredentialsBar variant="dark" />

      {/* ————— Services Preview ————— */}
      <section className="py-24">
        <div className="container">
          <div className="fade-up mx-auto max-w-2xl text-center">
            <p className="eyebrow">What We Do</p>
            <h2 className="mt-4 text-balance font-display text-4xl font-bold text-foreground md:text-5xl">
              Back-office excellence, delivered quietly
            </h2>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground">
              Four core service areas, one dependable partner. Every engagement
              is tailored to your business and scales with your growth.
            </p>
          </div>

          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {SERVICES.map(({ title, icon: Icon, blurb, href }, i) => (
              <Link
                key={title}
                href={href}
                className="fade-up group flex flex-col rounded-lg border border-border bg-card p-7 shadow-[0_1px_2px_rgb(0_0_0/0.04)] transition-all duration-300 hover:-translate-y-1 hover:border-primary/30 hover:shadow-[0_16px_40px_-16px_oklch(0.38_0.085_165/0.25)]"
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/8 text-primary transition-colors duration-300 group-hover:bg-gold/15 group-hover:text-gold-foreground">
                  <Icon className="h-5.5 w-5.5" strokeWidth={1.6} />
                </div>
                <h3 className="mt-5 font-display text-2xl font-semibold text-foreground">
                  {title}
                </h3>
                <p className="mt-2.5 flex-1 text-sm leading-relaxed text-muted-foreground">
                  {blurb}
                </p>
                <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-primary">
                  Learn more
                  <ArrowRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-1" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ————— Why Nuumeric ————— */}
      <section className="border-y border-border bg-secondary py-24">
        <div className="container grid items-center gap-14 lg:grid-cols-2">
          <div className="fade-up">
            <p className="eyebrow">Why Nuumeric</p>
            <h2 className="mt-4 text-balance font-display text-4xl font-bold text-foreground md:text-5xl">
              A partner who has run businesses, not just books
            </h2>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground">
              Nuumeric is the evolution of Montgomery Business Solutions — a
              firm built on more than 28 years of hands-on financial
              leadership. We pair certified expertise with the practicality of
              someone who has managed teams, met payroll, and balanced daily
              operations.
            </p>
            <div className="mt-8 space-y-5">
              {[
                {
                  title: "US-based team members",
                  text: "Real people, in your time zone, who learn your business.",
                },
                {
                  title: "Scales with your needs",
                  text: "Expand or reduce support as your workload changes — no friction.",
                },
                {
                  title: "Insured and bondable",
                  text: "Certificate of Insurance (COI) available upon request.",
                },
              ].map(item => (
                <div key={item.title} className="flex gap-4">
                  <TrendingUp className="mt-1 h-5 w-5 shrink-0 text-gold" strokeWidth={1.75} />
                  <div>
                    <p className="font-semibold text-foreground">{item.title}</p>
                    <p className="text-sm text-muted-foreground">{item.text}</p>
                  </div>
                </div>
              ))}
            </div>
            <Button
              asChild
              variant="outline"
              className="mt-9 rounded-full border-primary/40 px-6 text-primary hover:bg-primary hover:text-primary-foreground"
            >
              <Link href="/about">
                Meet Your Trusted Partner
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
          <div className="fade-up relative">
            <div className="absolute -inset-3 rounded-xl border border-gold/30" aria-hidden />
            <img
              src="/manus-storage/nuumeric_about_64e4d565.png"
              alt="A warm, refined office interior reflecting Nuumeric's approachable professionalism"
              className="relative aspect-[3/4] w-full rounded-lg object-cover shadow-xl"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      {/* ————— Client Industries ————— */}
      <section id="industries" className="relative scroll-mt-24 overflow-hidden py-24">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${INDUSTRIES_IMG})` }}
          aria-hidden
        />
        <div className="absolute inset-0 bg-ink/85" aria-hidden />
        <div className="container relative z-10">
          <div className="fade-up mx-auto max-w-2xl text-center">
            <p className="eyebrow">Who We Serve</p>
            <h2 className="mt-4 text-balance font-display text-4xl font-bold text-ink-foreground md:text-5xl">
              Trusted across industries
            </h2>
            <p className="mt-4 text-base leading-relaxed text-ink-foreground/75">
              From medical practices to main-street restaurants, Nuumeric keeps
              the numbers precise so owners can focus on what they do best.
            </p>
          </div>
          <div className="mt-14 grid grid-cols-2 gap-4 md:grid-cols-4">
            {INDUSTRIES.map(({ label, icon: Icon }, i) => (
              <div
                key={label}
                className="fade-up flex flex-col items-center gap-3 rounded-lg border border-ink-foreground/12 bg-ink-foreground/5 px-4 py-7 text-center backdrop-blur-sm transition-colors duration-300 hover:border-gold/40 hover:bg-ink-foreground/10"
                style={{ transitionDelay: `${i * 40}ms` }}
              >
                <Icon className="h-6 w-6 text-gold" strokeWidth={1.5} />
                <span className="text-sm font-medium text-ink-foreground">
                  {label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ————— CTA ————— */}
      <section className="border-t border-border bg-secondary py-24">
        <div className="container">
          <div className="grid items-center gap-10 lg:grid-cols-[1fr_auto]">
            <div className="fade-up max-w-2xl">
              <p className="eyebrow">Client Referral Program</p>
              <h2 className="mt-4 text-balance font-display text-4xl font-bold md:text-5xl">
                Know a business that needs us? Earn {REFERRAL.creditDisplay}.
              </h2>
              <p className="mt-4 text-base leading-relaxed text-muted-foreground">
                Our best clients come from people like you. Refer a business
                owner to Nuumeric, and when they sign up for services, we'll
                apply a <strong className="text-foreground">{REFERRAL.creditDisplay} credit toward your next
                invoice</strong> as a thank-you.
              </p>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {REFERRAL.terms}
              </p>
            </div>
            <div className="fade-up flex flex-col items-start gap-4 lg:items-end">
              <Button
                asChild
                size="lg"
                className="h-13 rounded-full bg-primary px-8 text-base font-semibold text-primary-foreground transition-all duration-200 hover:bg-primary/90 active:scale-[0.97]"
              >
                <Link href="/refer">
                  Refer a Business
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <p className="text-xs text-muted-foreground">
                Or just have them mention your name when they reach out.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ————— CTA ————— */}
      <section className="py-24">
        <div className="container">
          <div className="fade-up relative overflow-hidden rounded-2xl bg-primary px-8 py-16 text-center md:px-16">
            <div
              className="pointer-events-none absolute -top-24 -right-24 h-72 w-72 rounded-full bg-gold/20 blur-3xl"
              aria-hidden
            />
            <div
              className="pointer-events-none absolute -bottom-32 -left-16 h-72 w-72 rounded-full bg-ink/40 blur-3xl"
              aria-hidden
            />
            <h2 className="relative text-balance font-display text-4xl font-bold text-primary-foreground md:text-5xl">
              Ready to hand off the back office?
            </h2>
            <p className="relative mx-auto mt-4 max-w-xl text-base leading-relaxed text-primary-foreground/80">
              Tell us what you need and we'll put together a tailored quote —
              no pressure, no obligation.
            </p>
            <div className="relative mt-9 flex flex-wrap items-center justify-center gap-4">
              <Button
                asChild
                size="lg"
                className="h-13 rounded-full bg-gold px-8 text-base font-semibold text-gold-foreground shadow-lg transition-all duration-200 hover:bg-gold/90 active:scale-[0.97]"
              >
                <Link href="/contact">
                  Get a Quote Today
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <PhoneLink
                source="home_cta"
                className="inline-flex items-center gap-2 text-sm font-medium text-primary-foreground/85 transition-colors hover:text-gold"
              >
                <Phone className="h-4 w-4" strokeWidth={1.75} />
                {SITE.phoneDisplay}
              </PhoneLink>
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
