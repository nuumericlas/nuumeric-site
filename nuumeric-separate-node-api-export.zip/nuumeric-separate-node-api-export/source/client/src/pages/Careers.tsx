import { CredentialsBar } from "@/components/CredentialsBar";
import Seo from "@/components/Seo";
import { SiteLayout } from "@/components/SiteLayout";
import { Button } from "@/components/ui/button";
import { SITE } from "@shared/site";
import {
  ArrowUpRight,
  Clock,
  ExternalLink,
  HeartHandshake,
  Laptop,
  TrendingUp,
} from "lucide-react";

const HIGHLIGHTS = [
  {
    icon: HeartHandshake,
    title: "Boutique team, real relationships",
    description:
      "You won't be a cog in a call center. Our bookkeepers work directly with their own clients and build relationships that last years.",
  },
  {
    icon: Laptop,
    title: "Modern cloud tools",
    description:
      "Zoho Books, Xero, QuickBooks Online, Gusto, SurePayroll — we work in the platforms that define modern accounting, and we'll keep you certified in them.",
  },
  {
    icon: Clock,
    title: "Flexibility that works",
    description:
      "Structured processes and clear expectations, without the rigid big-firm grind. We measure results, not hours in a seat.",
  },
  {
    icon: TrendingUp,
    title: "Room to grow",
    description:
      "As our clients grow, so do the opportunities — from bookkeeping into advisory, payroll, systems consulting, and client leadership.",
  },
];

export default function Careers() {
  return (
    <SiteLayout>
      <Seo
        title="Careers — Join Our Team — Nuumeric Inc"
        description="Explore open positions at Nuumeric Inc. Join a boutique, US-based bookkeeping and back-office team working with modern cloud accounting tools."
      />

      {/* ————— Page Header ————— */}
      <section className="bg-ink pt-40 pb-20 text-ink-foreground">
        <div className="container">
          <p className="eyebrow fade-up">Careers</p>
          <h1 className="fade-up mt-4 max-w-3xl text-balance font-display text-5xl font-bold leading-[1.08] md:text-6xl">
            Do work that adds up
          </h1>
          <p className="fade-up mt-5 max-w-2xl text-lg leading-relaxed text-ink-foreground/75">
            We're a boutique, US-based team helping growing enterprises keep
            their books clean, their payroll on time, and their decisions
            grounded in real numbers. If that sounds like your kind of work,
            we'd love to meet you.
          </p>
          <div className="fade-up mt-9 flex flex-wrap items-center gap-4">
            <Button
              asChild
              size="lg"
              className="rounded-full bg-gold px-8 font-semibold text-gold-foreground hover:bg-gold/90 active:scale-[0.97]"
            >
              <a
                href={SITE.careersPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                View Open Positions
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
            <p className="text-sm text-ink-foreground/60">
              Opens our career portal in a new tab
            </p>
          </div>
        </div>
      </section>

      {/* ————— Why Nuumeric ————— */}
      <section className="py-24">
        <div className="container">
          <p className="eyebrow fade-up">Why Nuumeric</p>
          <h2 className="fade-up mt-3 max-w-2xl text-balance font-display text-3xl font-bold text-foreground md:text-4xl">
            What it's like to work here
          </h2>
          <div className="mt-12 grid gap-6 md:grid-cols-2">
            {HIGHLIGHTS.map((item, index) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.title}
                  className="fade-up flex gap-5 rounded-lg border border-border bg-card p-7 shadow-sm transition-shadow hover:shadow-md"
                  style={{ animationDelay: `${index * 60}ms` }}
                >
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/8">
                    <Icon className="h-6 w-6 text-primary" strokeWidth={1.6} />
                  </div>
                  <div>
                    <h3 className="font-display text-xl font-semibold text-foreground">
                      {item.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                      {item.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <CredentialsBar variant="dark" />

      {/* ————— CTA ————— */}
      <section className="py-20">
        <div className="container fade-up text-center">
          <h2 className="text-balance font-display text-3xl font-bold text-foreground md:text-4xl">
            Ready to see what's open?
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Browse current openings and apply directly through our career
            portal. New roles are posted as our client base grows.
          </p>
          <Button
            asChild
            size="lg"
            className="mt-8 rounded-full bg-primary px-8 font-semibold text-primary-foreground hover:bg-primary/90 active:scale-[0.97]"
          >
            <a
              href={SITE.careersPortalUrl}
              target="_blank"
              rel="noopener noreferrer"
            >
              Visit the Career Portal
              <ArrowUpRight className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </section>
    </SiteLayout>
  );
}
