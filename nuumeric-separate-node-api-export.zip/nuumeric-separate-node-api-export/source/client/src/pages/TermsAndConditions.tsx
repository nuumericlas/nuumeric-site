import { LegalPageShell } from "@/components/LegalPageShell";
import { TermlyPolicy } from "@/components/TermlyPolicy";
import { TERMLY } from "@shared/site";

export default function TermsAndConditions() {
  return (
    <LegalPageShell
      eyebrow="Legal"
      title="Terms & Conditions"
      seoTitle="Terms & Conditions — Nuumeric Inc"
      seoDescription="Review the terms and conditions governing the use of Nuumeric Inc's website, bookkeeping, tax preparation, and payroll services."
    >
      <TermlyPolicy dataId={TERMLY.termsId} />
    </LegalPageShell>
  );
}
