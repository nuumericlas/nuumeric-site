import { LegalPageShell } from "@/components/LegalPageShell";
import { TermlyPolicy } from "@/components/TermlyPolicy";
import { TERMLY } from "@shared/site";

export default function CookiePolicy() {
  return (
    <LegalPageShell
      eyebrow="Legal"
      title="Cookie Policy"
      seoTitle="Cookie Policy — Nuumeric Inc"
      seoDescription="Learn which cookies the Nuumeric Inc website uses, why we use them, and how you can manage your cookie consent preferences."
    >
      <TermlyPolicy dataId={TERMLY.cookiePolicyId} />
    </LegalPageShell>
  );
}
