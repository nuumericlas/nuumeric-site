import { LegalPageShell } from "@/components/LegalPageShell";
import { TermlyPolicy } from "@/components/TermlyPolicy";
import { TERMLY } from "@shared/site";

export default function PrivacyPolicy() {
  return (
    <LegalPageShell
      eyebrow="Legal"
      title="Privacy Policy"
      seoTitle="Privacy Policy — Nuumeric Inc"
      seoDescription="Read the Nuumeric Inc privacy policy: how we collect, use, and protect your personal information across our website and services."
    >
      <TermlyPolicy dataId={TERMLY.privacyPolicyId} />
    </LegalPageShell>
  );
}
