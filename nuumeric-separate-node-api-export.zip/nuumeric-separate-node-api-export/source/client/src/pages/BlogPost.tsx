import Seo from "@/components/Seo";
import { ShareButtons } from "@/components/ShareButtons";
import { SiteLayout } from "@/components/SiteLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatPostDate, readingTimeMinutes, splitTags } from "@/lib/blogFormat";
import { trpc } from "@/lib/trpc";
import { SITE } from "@shared/site";
import { ArrowLeft, ArrowRight, Clock } from "lucide-react";
import { useMemo } from "react";
import { Streamdown } from "streamdown";
import { Link, useParams } from "wouter";

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const { data: post, isLoading, error } = trpc.blog.getBySlug.useQuery(
    { slug: slug ?? "" },
    { enabled: Boolean(slug), retry: false },
  );

  const jsonLd = useMemo(() => {
    if (!post) return undefined;
    return {
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      headline: post.title,
      description: post.seoDescription || post.excerpt || undefined,
      image: post.coverImageUrl || undefined,
      datePublished: post.publishedAt ? new Date(post.publishedAt).toISOString() : undefined,
      dateModified: post.updatedAt ? new Date(post.updatedAt).toISOString() : undefined,
      mainEntityOfPage: `${SITE.canonicalOrigin}/blog/${post.slug}`,
      url: `${SITE.canonicalOrigin}/blog/${post.slug}`,
      author: { "@type": "Organization", name: SITE.legalName },
      publisher: {
        "@type": "Organization",
        name: SITE.legalName,
        url: SITE.canonicalOrigin,
      },
    };
  }, [post]);

  if (isLoading) {
    return (
      <SiteLayout>
        <section className="bg-ink pt-40 pb-16 text-ink-foreground">
          <div className="container max-w-3xl">
            <Skeleton className="h-4 w-24 bg-ink-foreground/10" />
            <Skeleton className="mt-4 h-12 w-full bg-ink-foreground/10" />
            <Skeleton className="mt-2 h-12 w-2/3 bg-ink-foreground/10" />
          </div>
        </section>
        <section className="py-16">
          <div className="container max-w-3xl space-y-3">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-4 w-full" />
            ))}
          </div>
        </section>
      </SiteLayout>
    );
  }

  if (error || !post) {
    return (
      <SiteLayout>
        <Seo title="Article Not Found — Nuumeric Inc" />
        <section className="bg-ink pt-40 pb-20 text-ink-foreground">
          <div className="container max-w-3xl text-center">
            <h1 className="font-display text-4xl font-bold">Article not found</h1>
            <p className="mt-4 text-ink-foreground/75">
              This article may have been moved or unpublished.
            </p>
            <Button asChild variant="outline" className="mt-8 rounded-full border-ink-foreground/30 px-6 text-ink-foreground hover:bg-ink-foreground/10">
              <Link href="/blog">
                <ArrowLeft className="h-4 w-4" />
                Back to the Blog
              </Link>
            </Button>
          </div>
        </section>
      </SiteLayout>
    );
  }

  const tags = splitTags(post.tags);

  return (
    <SiteLayout>
      <Seo
        title={post.seoTitle || `${post.title} — Nuumeric Inc`}
        description={post.seoDescription || post.excerpt || undefined}
        jsonLd={jsonLd}
      />

      {/* ————— Article Header ————— */}
      <section className="bg-ink pt-40 pb-16 text-ink-foreground">
        <div className="container max-w-3xl">
          <Link
            href="/blog"
            className="inline-flex items-center gap-1.5 text-sm text-ink-foreground/70 transition-colors hover:text-gold"
          >
            <ArrowLeft className="h-4 w-4" />
            All articles
          </Link>
          <div className="mt-6 flex flex-wrap items-center gap-3 text-sm text-ink-foreground/70">
            {post.category && (
              <Badge className="rounded-full bg-gold/15 text-gold hover:bg-gold/15">
                {post.category}
              </Badge>
            )}
            <span>{formatPostDate(post.publishedAt)}</span>
            {post.updatedAt &&
              post.publishedAt &&
              post.createdAt &&
              new Date(post.updatedAt).getTime() - new Date(post.publishedAt).getTime() >
                24 * 60 * 60 * 1000 &&
              new Date(post.updatedAt).getTime() - new Date(post.createdAt).getTime() >
                24 * 60 * 60 * 1000 && (
                <span className="text-ink-foreground/55">
                  Updated {formatPostDate(post.updatedAt)}
                </span>
              )}
            <span className="inline-flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              {readingTimeMinutes(post.content)} min read
            </span>
          </div>
          <h1 className="fade-up mt-4 text-balance font-display text-4xl font-bold leading-[1.12] md:text-5xl">
            {post.title}
          </h1>
          {post.excerpt && (
            <p className="fade-up mt-5 text-lg leading-relaxed text-ink-foreground/75">
              {post.excerpt}
            </p>
          )}
          <ShareButtons slug={post.slug} title={post.title} tone="dark" className="fade-up mt-7" />
        </div>
      </section>

      {/* ————— Cover Image ————— */}
      {post.coverImageUrl && (
        <div className="container max-w-4xl">
          <div className="-mt-8 overflow-hidden rounded-lg border border-border shadow-md">
            <img src={post.coverImageUrl} alt={post.title} className="w-full object-cover" />
          </div>
        </div>
      )}

      {/* ————— Article Body ————— */}
      <article className="py-16">
        <div className="container max-w-3xl">
          <div className="prose-nuumeric">
            <Streamdown>{post.content}</Streamdown>
          </div>
          {tags.length > 0 && (
            <div className="mt-12 flex flex-wrap gap-2 border-t border-border pt-6">
              {tags.map(tag => (
                <Badge key={tag} variant="secondary" className="rounded-full">
                  {tag}
                </Badge>
              ))}
            </div>
          )}
          <div className={tags.length > 0 ? "mt-6" : "mt-12 border-t border-border pt-6"}>
            <ShareButtons slug={post.slug} title={post.title} tone="light" />
          </div>
        </div>
      </article>

      {/* ————— CTA ————— */}
      <section className="border-t border-border bg-muted/40 py-16">
        <div className="container fade-up max-w-3xl text-center">
          <h2 className="text-balance font-display text-3xl font-bold text-foreground">
            Want this handled for you?
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Start with a free, one-hour consultation — we'll look at your books
            and tell you honestly what we'd do.
          </p>
          <Button
            asChild
            size="lg"
            className="mt-7 rounded-full bg-primary px-8 font-semibold text-primary-foreground hover:bg-primary/90 active:scale-[0.97]"
          >
            <Link href="/contact">
              Request a Quote
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </SiteLayout>
  );
}
