import { SiteLayout } from "@/components/SiteLayout";
import Seo from "@/components/Seo";
import { HoneypotField } from "@/components/HoneypotField";
import { PhoneLink } from "@/components/PhoneLink";
import { identifySalesIQVisitor } from "@/components/ZohoSalesIQ";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { trackConversion } from "@/lib/conversions";
import {
  BUSINESS_HOURS,
  SERVICE_OPTIONS,
  SITE,
  formatCityLine,
  formatStreetAddress,
  mapsUrl,
} from "@shared/site";
import { CheckCircle2, Clock, Loader2, MapPin, Phone, Send } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";

export default function Contact() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });
  const [hp, setHp] = useState("");
  const formLoadedAt = useRef(Date.now());
  const [submitted, setSubmitted] = useState(false);

  const submitMutation = trpc.contact.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Thank you! We'll be in touch shortly.");
      // Lead conversion: GA4 generate_lead + Google Ads (when a label is set).
      // Fired only on a confirmed server success, so spam-filtered or failed
      // submissions are never counted as conversions.
      trackConversion("quote", {
        source: "contact_form",
        service: form.service,
      });
      // Identify this visitor to Zoho SalesIQ so the CRM integration can
      // auto-link their live-chat sessions to the lead created in Zoho CRM.
      identifySalesIQVisitor({
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim() || undefined,
        info: { "Lead Source": "Website", "Service Needed": form.service },
      });
    },
    onError: err => {
      toast.error(err.message || "Something went wrong. Please try again.");
    },
  });

  const set = (key: keyof typeof form) => (value: string) =>
    setForm(f => ({ ...f, [key]: value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.service) {
      toast.error("Please fill in your name, email, and the service you need.");
      return;
    }
    submitMutation.mutate({ ...form, hp, formLoadedAt: formLoadedAt.current });
  };

  return (
    <SiteLayout>
      <Seo
        title="Contact & Quote Request — Nuumeric Inc"
        description="Request a quote from Nuumeric for bookkeeping, business or individual tax prep, or payroll. Call or text 1 (936) 337-5446 — replies within one business day."
      />
      {/* ————— Page Header ————— */}
      <section className="bg-ink pt-40 pb-20 text-ink-foreground">
        <div className="container">
          <p className="eyebrow fade-up">Contact &amp; Quote Request</p>
          <h1 className="fade-up mt-4 max-w-3xl text-balance font-display text-5xl font-bold leading-[1.08] md:text-6xl">
            Let's get your numbers working for you
          </h1>
          <p className="fade-up mt-5 max-w-2xl text-lg leading-relaxed text-ink-foreground/75">
            Tell us a little about your business and what you need. We'll reply
            with a tailored quote — usually within one business day.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="container grid gap-14 lg:grid-cols-[1fr_1.4fr]">
          {/* ————— Contact Info ————— */}
          <div className="fade-up">
            <p className="eyebrow">Reach Us Directly</p>
            <h2 className="mt-3 font-display text-3xl font-bold text-foreground">
              Prefer to talk it through?
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Call or text and you'll reach a real person who can answer your
              questions on the spot.
            </p>

            <PhoneLink
              source="contact_page"
              className="mt-8 flex items-center gap-4 rounded-lg border border-gold/40 bg-gold/8 p-6 transition-colors duration-200 hover:bg-gold/15"
            >
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gold/20">
                <Phone className="h-5.5 w-5.5 text-gold-foreground" strokeWidth={1.75} />
              </span>
              <span>
                <span className="block text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                  Call or Text
                </span>
                <span className="mt-0.5 block font-display text-3xl font-bold text-foreground">
                  {SITE.phoneDisplay}
                </span>
              </span>
            </PhoneLink>

            {/*
              Visible office address and hours. These mirror the door-door signage
              and the LocalBusiness structured data; all three must agree, so they
              are driven from the shared SITE/BUSINESS_HOURS constants.
            */}
            <div className="mt-6 rounded-lg border border-border bg-secondary/60 p-6">
              <address className="flex gap-4 not-italic">
                <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-primary" strokeWidth={1.75} />
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                    Office
                  </p>
                  <a
                    href={mapsUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-1 block text-base font-semibold leading-snug text-foreground transition-colors hover:text-primary"
                  >
                    {formatStreetAddress()}
                    <br />
                    {formatCityLine()}
                  </a>
                  <p className="mt-1.5 text-xs text-muted-foreground">
                    Visits by appointment — please call ahead.
                  </p>
                </div>
              </address>

              <div className="mt-5 flex gap-4 border-t border-border pt-5">
                <Clock className="mt-0.5 h-5 w-5 shrink-0 text-primary" strokeWidth={1.75} />
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                    Hours
                  </p>
                  <p className="mt-1 text-base font-semibold leading-snug text-foreground">
                    {BUSINESS_HOURS.daysDisplay}
                    <br />
                    {BUSINESS_HOURS.timeDisplay} {BUSINESS_HOURS.timezoneDisplay}
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8 space-y-5">
              <div className="flex gap-4">
                <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-primary" strokeWidth={1.75} />
                <div>
                  <p className="text-sm font-semibold text-foreground">US-Based Team</p>
                  <p className="text-sm text-muted-foreground">
                    All work is performed by team members based in the United
                    States.
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <Send className="mt-0.5 h-5 w-5 shrink-0 text-primary" strokeWidth={1.75} />
                <div>
                  <p className="text-sm font-semibold text-foreground">Fast Response</p>
                  <p className="text-sm text-muted-foreground">
                    Quote requests are typically answered within one business
                    day.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* ————— Quote Form ————— */}
          <div className="fade-up">
            {submitted ? (
              <div className="flex h-full flex-col items-center justify-center rounded-xl border border-primary/20 bg-secondary p-12 text-center">
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                  <CheckCircle2 className="h-8 w-8 text-primary" strokeWidth={1.5} />
                </span>
                <h3 className="mt-6 font-display text-3xl font-bold text-foreground">
                  Request received
                </h3>
                <p className="mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  Thank you, {form.name.split(" ")[0]}. We've received your
                  quote request and will be in touch shortly. If it's urgent,
                  call or text {SITE.phoneDisplay}.
                </p>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="rounded-xl border border-border bg-card p-8 shadow-[0_2px_20px_-8px_rgb(0_0_0/0.08)] md:p-10"
              >
                <h2 className="font-display text-3xl font-bold text-foreground">
                  Request a Quote
                </h2>
                <p className="mt-2 text-sm text-muted-foreground">
                  Fields marked * are required.
                </p>

                <HoneypotField value={hp} onChange={setHp} />

                <div className="mt-8 grid gap-6 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name *</Label>
                    <Input
                      id="name"
                      value={form.name}
                      onChange={e => set("name")(e.target.value)}
                      placeholder="Jane Smith"
                      autoComplete="name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={form.email}
                      onChange={e => set("email")(e.target.value)}
                      placeholder="jane@company.com"
                      autoComplete="email"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={form.phone}
                      onChange={e => set("phone")(e.target.value)}
                      placeholder="(555) 123-4567"
                      autoComplete="tel"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="service">Service Needed *</Label>
                    <Select value={form.service} onValueChange={set("service")}>
                      <SelectTrigger id="service" className="w-full">
                        <SelectValue placeholder="Select a service" />
                      </SelectTrigger>
                      <SelectContent>
                        {SERVICE_OPTIONS.map(opt => (
                          <SelectItem key={opt} value={opt}>
                            {opt}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea
                      id="message"
                      rows={5}
                      value={form.message}
                      onChange={e => set("message")(e.target.value)}
                      placeholder="Tell us a bit about your business and what you're looking for…"
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  disabled={submitMutation.isPending}
                  className="mt-8 w-full rounded-full bg-primary text-base font-semibold text-primary-foreground transition-all duration-200 hover:bg-primary/90 active:scale-[0.98] sm:w-auto sm:px-10"
                >
                  {submitMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Sending…
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      Send Quote Request
                    </>
                  )}
                </Button>
              </form>
            )}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
