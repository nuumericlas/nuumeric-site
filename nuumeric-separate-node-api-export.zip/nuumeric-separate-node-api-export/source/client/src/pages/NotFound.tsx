import Seo from "@/components/Seo";
import { PhoneLink } from "@/components/PhoneLink";
import { SearchDialog } from "@/components/SearchDialog";
import { SiteLayout } from "@/components/SiteLayout";
import { Button } from "@/components/ui/button";
import { SITE } from "@shared/site";
import {
  ArrowRight,
  Briefcase,
  Home,
  Mail,
  Phone,
  Search,
  Users,
} from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

const HELPFUL_LINKS = [
  {
    href: "/",
    label: "Home",
    description: "Back to the main page and an overview of what we do",
    icon: Home,
  },
  {
    href: "/services",
    label: "Services",
    description: "Bookkeeping, tax preparation, payroll, and more",
    icon: Briefcase,
  },
  {
    href: "/about",
    label: "About Us",
    description: "Meet Leigh Ann Smith and learn our story",
    icon: Users,
  },
  {
    href: "/contact",
    label: "Contact",
    description: "Request a quote or ask us a question",
    icon: Mail,
  },
];

export default function NotFound() {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <SiteLayout>
      <Seo
        title="Page Not Found — Nuumeric Inc"
        description="The page you're looking for doesn't exist. Explore Nuumeric's bookkeeping, tax preparation, and payroll services, or contact us for a quote."
      />
      {/* ————— 404 Header ————— */}
      <section className="bg-ink pt-40 pb-20 text-ink-foreground">
        <div className="container text-center">
          <p className="eyebrow fade-up">Error 404</p>
          <p
            className="fade-up mt-6 font-display text-7xl font-extrabold leading-none text-primary md:text-8xl"
            aria-hidden
          >
            404
          </p>
          <h1 className="fade-up mx-auto mt-6 max-w-2xl text-balance font-display text-4xl font-bold leading-[1.1] md:text-5xl">
            This page didn't make it into the ledger
          </h1>
          <p className="fade-up mx-auto mt-5 max-w-xl text-lg leading-relaxed text-ink-foreground/75">
            The page you're looking for may have been moved or no longer
            exists. Let's get you back to where the numbers add up.
          </p>
          <div className="fade-up mx-auto mt-8 max-w-md">
            <button
              onClick={() => setSearchOpen(true)}
              className="flex w-full items-center gap-3 rounded-full border border-ink-foreground/25 bg-ink-foreground/5 px-5 py-3.5 text-left transition-colors duration-200 hover:border-primary/60 hover:bg-ink-foreground/10"
              aria-label="Search the site"
            >
              <Search className="h-4 w-4 shrink-0 text-primary" />
              <span className="flex-1 text-sm text-ink-foreground/60">
                Search for services, pages, or information...
              </span>
              <kbd className="hidden rounded border border-ink-foreground/20 px-1.5 py-0.5 text-[10px] font-semibold text-ink-foreground/50 sm:inline-block">
                Ctrl K
              </kbd>
            </button>
          </div>
          <div className="fade-up mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button asChild size="lg">
              <Link href="/">
                Back to Home
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-ink-foreground/30 text-ink-foreground hover:bg-ink-foreground/10"
            >
              <PhoneLink source="404_page">
                <Phone className="mr-2 h-4 w-4" />
                {SITE.phoneDisplay}
              </PhoneLink>
            </Button>
          </div>
        </div>
      </section>

      {/* ————— Helpful Links ————— */}
      <section className="py-20">
        <div className="container">
          <p className="eyebrow fade-up text-center">Where to next?</p>
          <h2 className="fade-up mt-3 text-center font-display text-3xl font-bold text-foreground md:text-4xl">
            Explore the main sections
          </h2>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {HELPFUL_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="fade-up group rounded-lg border border-border bg-card p-6 shadow-sm transition-all duration-200 hover:-translate-y-1 hover:border-primary/40 hover:shadow-md"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-md bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  <link.icon className="h-5 w-5" />
                </span>
                <p className="mt-4 flex items-center gap-1.5 font-display text-lg font-bold text-card-foreground">
                  {link.label}
                  <ArrowRight className="h-4 w-4 -translate-x-1 opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:opacity-100" />
                </p>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                  {link.description}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <SearchDialog open={searchOpen} onOpenChange={setSearchOpen} />
    </SiteLayout>
  );
}
