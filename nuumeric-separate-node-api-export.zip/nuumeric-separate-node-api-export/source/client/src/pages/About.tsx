import { CredentialsBar } from "@/components/CredentialsBar";
import Seo from "@/components/Seo";
import { SiteLayout } from "@/components/SiteLayout";
import { Button } from "@/components/ui/button";
import { SITE } from "@shared/site";
import { ArrowRight, Award, ShieldCheck, Sparkles } from "lucide-react";
import { Link } from "wouter";

export default function About() {
  return (
    <SiteLayout>
      <Seo
        title="About Us — Leigh Ann Smith & Our Story — Nuumeric Inc"
        description="Meet Leigh Ann Smith and the story behind Nuumeric, formerly Montgomery Bookkeeping Solutions — 28+ years of insured, certified financial expertise."
      />
      {/* ————— Page Header ————— */}
      <section className="bg-ink pt-40 pb-20 text-ink-foreground">
        <div className="container">
          <p className="eyebrow fade-up">About Us</p>
          <h1 className="fade-up mt-4 max-w-3xl text-balance font-display text-5xl font-bold leading-[1.08] md:text-6xl">
            Your trusted partner in the numbers
          </h1>
          <p className="fade-up mt-5 max-w-2xl text-lg leading-relaxed text-ink-foreground/75">
            Nuumeric pairs certified expertise with the perspective of someone
            who has actually run businesses — because clarity in your finances
            should come from experience, not just software.
          </p>
        </div>
      </section>

      {/* ————— Leigh Ann Bio ————— */}
      <section className="py-24">
        <div className="container grid items-start gap-14 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="fade-up relative lg:sticky lg:top-28">
            <div className="absolute -inset-3 rounded-xl border border-gold/30" aria-hidden />
            <img
              src="/manus-storage/leigh_ann_smith_d5c12150.jpg"
              alt="Leigh Ann Smith, President of Nuumeric"
              className="relative aspect-[4/5] w-full rounded-lg object-cover shadow-xl"
            />
            <div className="relative mt-6 rounded-lg border border-border bg-card p-5 text-center shadow-sm">
              <p className="font-display text-2xl font-semibold text-foreground">
                Leigh Ann Smith
              </p>
              <p className="mt-1 text-xs font-semibold uppercase tracking-[0.18em] text-gold">
                President, Nuumeric Inc
              </p>
            </div>
          </div>

          <div className="fade-up">
            <p className="eyebrow">Leadership</p>
            <h2 className="mt-3 text-balance font-display text-4xl font-bold text-foreground md:text-[44px]">
              More than 28 years of helping owners find clarity
            </h2>
            <div className="mt-6 space-y-5 text-base leading-relaxed text-muted-foreground">
              <p>
                At <strong className="text-foreground">Nuumeric</strong>, you'll
                work directly with{" "}
                <strong className="text-foreground">Leigh Ann Smith</strong>, a
                trusted financial professional who has spent more than 28 years
                helping business owners simplify their finances and focus on
                growth.
              </p>
              <p>
                Leigh Ann understands the challenges small businesses face
                because she's been in your shoes — running companies, managing
                teams, and balancing the demands of daily operations. From
                bookkeeping and payroll to tax planning and business strategy,
                she knows how to cut through complexity and deliver practical
                solutions that make a real difference.
              </p>
              <p>
                Clients value her down-to-earth approach, clear communication,
                and commitment to their success. With Leigh Ann's guidance,
                you'll gain not just accurate numbers but the confidence and
                clarity to take your business where you want it to go.
              </p>
            </div>

            {/* Origin story */}
            <div className="mt-10 rounded-lg border-l-2 border-gold bg-secondary p-7">
              <div className="flex items-center gap-2.5">
                <Sparkles className="h-4.5 w-4.5 text-gold" strokeWidth={1.75} />
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">
                  Our Story
                </p>
              </div>
              <p className="mt-3 text-base leading-relaxed text-foreground/85">
                Founded in 2017 as <strong>Montgomery Business Solutions</strong>,{" "}
                <strong>Nuumeric</strong> is the evolution of that practice. As
                our business has grown — expanding our services and the
                customers we serve — we've taken on a new name and identity to
                better reflect who we are today and where we're headed.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ————— Trust Signals ————— */}
      <section className="border-y border-border bg-secondary py-20">
        <div className="container">
          <div className="fade-up mx-auto max-w-2xl text-center">
            <p className="eyebrow">Why You Can Rely on Us</p>
            <h2 className="mt-4 text-balance font-display text-4xl font-bold text-foreground">
              Credentials that back the confidence
            </h2>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-2">
            <div className="fade-up flex gap-5 rounded-lg border border-border bg-card p-7 shadow-sm">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/8">
                <ShieldCheck className="h-6 w-6 text-primary" strokeWidth={1.6} />
              </div>
              <div>
                <h3 className="font-display text-2xl font-semibold text-foreground">
                  Insured &amp; Bondable
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  Nuumeric is insured and bondable. Our Certificate of Insurance
                  (COI) is available upon request — because trust should be
                  verifiable, not just promised.
                </p>
              </div>
            </div>
            <div className="fade-up flex gap-5 rounded-lg border border-border bg-card p-7 shadow-sm">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gold/15">
                <Award className="h-6 w-6 text-gold" strokeWidth={1.6} />
              </div>
              <div>
                <h3 className="font-display text-2xl font-semibold text-foreground">
                  Certified Expertise
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  Zoho Finance Advisor, Xero Advisor, QuickBooks
                  ProAdvisor, Gusto Payroll, and SurePayroll
                  Accountant — credentials earned across the platforms your
                  business already uses.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <CredentialsBar variant="dark" />

      {/* ————— CTA ————— */}
      <section className="py-20">
        <div className="container fade-up text-center">
          <h2 className="text-balance font-display text-3xl font-bold text-foreground md:text-4xl">
            Let's talk about your back office
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            A short conversation is all it takes to see whether we're the right
            fit for your business.
          </p>
          <Button
            asChild
            size="lg"
            className="mt-8 rounded-full bg-primary px-8 font-semibold text-primary-foreground hover:bg-primary/90 active:scale-[0.97]"
          >
            <Link href="/contact">
              Get in Touch
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </SiteLayout>
  );
}
