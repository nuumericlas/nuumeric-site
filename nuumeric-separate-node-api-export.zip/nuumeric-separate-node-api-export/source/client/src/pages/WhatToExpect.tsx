import { CredentialsBar } from "@/components/CredentialsBar";
import Seo from "@/components/Seo";
import { SiteLayout } from "@/components/SiteLayout";
import { Button } from "@/components/ui/button";
import {
  ArrowRight,
  BadgeCheck,
  CalendarCheck,
  Clock,
  Receipt,
  SearchCheck,
  UserCheck,
} from "lucide-react";
import { Link } from "wouter";

const PROMISES = [
  {
    icon: CalendarCheck,
    title: "Evaluate",
    kicker: "Step one, on us",
    description:
      "A free, one-hour consultation to discuss your needs — no obligation, no sales pressure, just an honest look at where your books stand.",
  },
  {
    icon: UserCheck,
    title: "Boutique Services",
    kicker: "A person, not a queue",
    description:
      "One primary, dedicated bookkeeper who knows your business — accessible via phone, email, and text whenever you need them.",
  },
  {
    icon: Receipt,
    title: "Clear Invoicing",
    kicker: "No surprises",
    description:
      "Fixed fees automatically debited monthly or weekly via ACH or credit card, so you always know exactly what you're paying.",
  },
  {
    icon: BadgeCheck,
    title: "Guarantee",
    kicker: "Zero-risk commitment",
    description:
      "Cancel at any time and receive a refund of the current month's fee. We earn your business every month — or you don't pay for it.",
  },
  {
    icon: SearchCheck,
    title: "Transparency",
    kicker: "See everything",
    description:
      "Task tracking and a secure communication portal with our office, so you always know what's being worked on and what's done.",
  },
  {
    icon: Clock,
    title: "Timeliness",
    kicker: "Fast turnarounds",
    description:
      "24-hour or less turnaround on requests for simple, non-routine work deliverables — because your questions can't wait a week.",
  },
];

export default function WhatToExpect() {
  return (
    <SiteLayout>
      <Seo
        title="What to Expect — How We Work — Nuumeric Inc"
        description="What you can expect as a Nuumeric customer: a free consultation, a dedicated bookkeeper, fixed transparent fees, a cancel-anytime guarantee, and 24-hour turnarounds."
      />

      {/* ————— Page Header ————— */}
      <section className="bg-ink pt-40 pb-20 text-ink-foreground">
        <div className="container">
          <p className="eyebrow fade-up">What to Expect</p>
          <h1 className="fade-up mt-4 max-w-3xl text-balance font-display text-5xl font-bold leading-[1.08] md:text-6xl">
            Six promises we make to every client
          </h1>
          <p className="fade-up mt-5 max-w-2xl text-lg leading-relaxed text-ink-foreground/75">
            Handing your books to someone new shouldn't feel like a leap of
            faith. Here's exactly how the relationship works — from the first
            conversation to the day-to-day — so you know what you're signing up
            for before you sign anything.
          </p>
        </div>
      </section>

      {/* ————— Promise Cards ————— */}
      <section className="py-24">
        <div className="container">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {PROMISES.map((promise, index) => {
              const Icon = promise.icon;
              return (
                <div
                  key={promise.title}
                  className="fade-up group relative flex flex-col rounded-lg border border-border bg-card p-7 shadow-sm transition-shadow hover:shadow-md"
                  style={{ animationDelay: `${index * 60}ms` }}
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/8">
                    <Icon className="h-6 w-6 text-primary" strokeWidth={1.6} />
                  </div>
                  <p className="mt-5 text-xs font-semibold uppercase tracking-[0.18em] text-gold">
                    {promise.kicker}
                  </p>
                  <h2 className="mt-1.5 font-display text-2xl font-semibold text-foreground">
                    {promise.title}
                  </h2>
                  <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">
                    {promise.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <CredentialsBar variant="dark" />

      {/* ————— CTA ————— */}
      <section className="py-20">
        <div className="container fade-up text-center">
          <h2 className="text-balance font-display text-3xl font-bold text-foreground md:text-4xl">
            Start with the free consultation
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            One hour, no obligation. Tell us where your books stand and we'll
            tell you honestly what we'd do — whether or not you hire us.
          </p>
          <Button
            asChild
            size="lg"
            className="mt-8 rounded-full bg-primary px-8 font-semibold text-primary-foreground hover:bg-primary/90 active:scale-[0.97]"
          >
            <Link href="/contact">
              Request a Quote
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </SiteLayout>
  );
}
