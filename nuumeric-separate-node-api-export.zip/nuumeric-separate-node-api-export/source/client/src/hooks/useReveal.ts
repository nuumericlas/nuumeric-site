import { useEffect } from "react";

/**
 * Adds the `.in-view` class to `.fade-up` elements as they enter the viewport,
 * producing a subtle staggered reveal.
 *
 * Uses a MutationObserver so elements mounted AFTER the initial effect run
 * (e.g. cards rendered once an async query resolves) are also picked up.
 * Previously only elements present at mount were observed, which left
 * late-rendered content permanently at opacity 0 (blank blog page bug).
 */
export function useReveal() {
  useEffect(() => {
    const seen = new WeakSet<Element>();

    const io = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 },
    );

    const observeAll = () => {
      document.querySelectorAll<HTMLElement>(".fade-up").forEach(el => {
        if (seen.has(el)) return;
        seen.add(el);
        io.observe(el);
      });
    };

    observeAll();

    const mo = new MutationObserver(() => observeAll());
    mo.observe(document.body, { childList: true, subtree: true });

    return () => {
      mo.disconnect();
      io.disconnect();
    };
  }, []);
}
