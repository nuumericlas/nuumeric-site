import { useEffect } from "react";

/**
 * Injects a JSON-LD structured-data script into <head> while the component
 * is mounted, and removes it on unmount so other routes stay clean.
 */
export function useJsonLd(id: string, data: object) {
  useEffect(() => {
    // Replace any stale script with the same id (e.g. after HMR)
    document.getElementById(id)?.remove();

    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.id = id;
    script.textContent = JSON.stringify(data);
    document.head.appendChild(script);

    return () => {
      document.getElementById(id)?.remove();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
}
