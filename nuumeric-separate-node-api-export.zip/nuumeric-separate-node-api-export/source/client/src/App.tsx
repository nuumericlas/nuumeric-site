import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Suspense, lazy } from "react";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import GoogleAnalytics from "./components/GoogleAnalytics";
import ZohoSalesIQ from "./components/ZohoSalesIQ";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

// Public routes are statically imported so server-side rendering emits their
// real HTML (React.lazy under Suspense would bake the loading fallback into
// the SSR output — crawlers would see an empty shell). Only the auth-gated
// admin editor stays lazy: it is heavy and never needs to be crawlable.
import About from "./pages/About";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import Careers from "./pages/Careers";
import Contact from "./pages/Contact";
import CookiePolicy from "./pages/CookiePolicy";
import NotFound from "./pages/NotFound";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import Refer from "./pages/Refer";
import Services from "./pages/Services";
import TermsAndConditions from "./pages/TermsAndConditions";
import WhatToExpect from "./pages/WhatToExpect";
const AdminBlog = lazy(() => import("./pages/AdminBlog"));
const AdminSpam = lazy(() => import("./pages/AdminSpam"));
const AdminReferrals = lazy(() => import("./pages/AdminReferrals"));

// Minimal, layout-stable fallback shown only on slow connections while a
// route chunk downloads (routes share the same nav/footer shell inside pages).
function RouteFallback() {
  return <div className="min-h-screen bg-background" aria-busy="true" />;
}

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Suspense fallback={<RouteFallback />}>
      <Switch>
        <Route path={"/"} component={Home} />
        <Route path={"/services"} component={Services} />
        <Route path={"/about"} component={About} />
        <Route path={"/what-to-expect"} component={WhatToExpect} />
        <Route path={"/careers"} component={Careers} />
        <Route path={"/blog"} component={Blog} />
        <Route path={"/blog/:slug"} component={BlogPost} />
        <Route path={"/admin/blog"} component={AdminBlog} />
        <Route path={"/admin/spam"} component={AdminSpam} />
        <Route path={"/admin/referrals"} component={AdminReferrals} />
        <Route path={"/contact"} component={Contact} />
        <Route path={"/refer"} component={Refer} />
        <Route path={"/privacy-policy"} component={PrivacyPolicy} />
        <Route path={"/terms-and-conditions"} component={TermsAndConditions} />
        <Route path={"/cookie-policy"} component={CookiePolicy} />
        <Route path={"/404"} component={NotFound} />
        {/* Final fallback route */}
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <GoogleAnalytics />
          <ZohoSalesIQ />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
