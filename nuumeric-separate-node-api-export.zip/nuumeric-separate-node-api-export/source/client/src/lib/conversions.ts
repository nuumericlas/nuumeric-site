/**
 * Conversion tracking for Google Ads and GA4.
 *
 * Two separate things happen on every lead:
 *
 *   1. A GA4 `generate_lead` event, which needs nothing but the measurement ID
 *      that is already installed. This works today.
 *   2. A Google Ads conversion, which needs BOTH the account ID (`AW-...`) and
 *      a per-action conversion label. The label is issued when a conversion
 *      action is created in the Ads UI and cannot be derived from the ID.
 *
 * Until the labels below are filled in, the Ads call is skipped rather than
 * sent with a malformed `send_to` — a wrong send_to is silently dropped by
 * Google, which would look identical to working tracking while recording
 * nothing. Skipping keeps the failure visible in dev logs instead.
 *
 * NOTE: labels are optional. Google now hides the manual label flow in many
 * accounts. The GA4 events below can be imported into Ads directly by marking
 * `generate_lead` as a key event in Analytics — no label and no code change.
 * See GOOGLE_ADS_CONVERSIONS.md ("Route B") for the steps.
 */

export const GOOGLE_ADS_ID = "AW-18380599483";

/**
 * Per-action conversion labels from Google Ads → Goals → Conversions →
 * (action) → Tag setup → "Use Google tag". The snippet shown there contains
 * `send_to: 'AW-18380599483/XXXXXXXXXXXXXXXXX'` — the part after the slash is
 * the label. Leave a value empty to disable the Ads hit for that action while
 * still recording it in GA4.
 */
export const ADS_CONVERSION_LABELS = {
  /** Quote request submitted on /contact. */
  quote: "",
  /** Referral submitted on /refer. */
  referral: "",
  /** Visitor tapped or clicked the phone number. */
  phone: "",
} as const;

export type ConversionAction = keyof typeof ADS_CONVERSION_LABELS;

/** Where the interaction happened, for GA4 reporting. */
export interface ConversionContext {
  /** Human-readable origin, e.g. "contact_form", "nav", "hero". */
  source?: string;
  /** Service selected on the quote form, when applicable. */
  service?: string;
}

/** GA4 event name for each action. */
const GA4_EVENT: Record<ConversionAction, string> = {
  quote: "generate_lead",
  referral: "generate_lead",
  phone: "phone_click",
};

/**
 * Fires the GA4 event and, when a label is configured, the Google Ads
 * conversion. Safe to call before the tag has loaded or when a visitor's
 * ad blocker has removed gtag entirely — every call is optional-chained.
 */
export function trackConversion(
  action: ConversionAction,
  context: ConversionContext = {},
): void {
  if (typeof window === "undefined") return;

  const params: Record<string, unknown> = {
    event_category: "lead",
    event_label: action,
  };
  if (context.source) params.lead_source = context.source;
  if (context.service) params.service = context.service;

  // 1. GA4 — always sent.
  window.gtag?.("event", GA4_EVENT[action], params);

  // 2. GTM dataLayer — lets tags be added from the GTM UI without a code change.
  window.dataLayer?.push({
    event: `nuumeric_${action}`,
    ...params,
  });

  // 3. Google Ads conversion — only when a label has been configured.
  const label = ADS_CONVERSION_LABELS[action];
  if (label) {
    window.gtag?.("event", "conversion", {
      send_to: `${GOOGLE_ADS_ID}/${label}`,
    });
  } else if (import.meta.env.DEV) {
    console.info(
      `[conversions] "${action}" recorded in GA4; Google Ads hit skipped ` +
        `(no conversion label configured in ADS_CONVERSION_LABELS).`,
    );
  }
}

/** True when at least one Ads conversion label has been configured. */
export function hasAdsLabels(): boolean {
  return Object.values(ADS_CONVERSION_LABELS).some(l => l.length > 0);
}
