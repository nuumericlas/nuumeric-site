import { describe, expect, it } from "vitest";
import { SERVICE_OPTIONS } from "@shared/site";
import { FAQ_ENTRIES } from "./faq";
import { SEARCH_INDEX } from "./searchIndex";
import {
  INDIVIDUAL_TAX_DOCUMENTS,
  INDIVIDUAL_TAX_STEPS,
  INDIVIDUAL_TAX_TURNAROUND,
} from "./individualTax";

/**
 * Individual tax return preparation is offered but was previously invisible on
 * the site — every tax mention implied business returns only. These tests pin
 * the places a prospective individual client could plausibly look: the quote
 * form's service picker, the FAQ, and site search.
 */
describe("quote form service options", () => {
  it("offers a distinct individual tax return option", () => {
    expect(SERVICE_OPTIONS).toContain("Individual Tax Return");
  });

  it("distinguishes business tax prep from individual returns", () => {
    expect(SERVICE_OPTIONS).toContain("Business Tax Preparation");
    // The old ambiguous label should be gone, so submissions are unambiguous.
    expect(SERVICE_OPTIONS).not.toContain("Tax Preparation");
  });

  it("keeps every option within the database column limit", () => {
    // contact_submissions.service is varchar(100).
    for (const option of SERVICE_OPTIONS) {
      expect(option.length).toBeLessThanOrEqual(100);
    }
  });

  it("has no duplicate options", () => {
    expect(new Set(SERVICE_OPTIONS).size).toBe(SERVICE_OPTIONS.length);
  });

  it("keeps the catch-all option last so it does not lead the list", () => {
    expect(SERVICE_OPTIONS[SERVICE_OPTIONS.length - 1]).toBe("Other / Not Sure");
  });
});

describe("individual tax FAQ entry", () => {
  const entry = FAQ_ENTRIES.find(f => f.id === "individual-returns");

  it("exists", () => {
    expect(entry).toBeDefined();
  });

  it("answers the business-only ambiguity directly", () => {
    expect(entry!.answer.toLowerCase()).toContain("individual");
    expect(entry!.answer.toLowerCase()).toContain("business");
  });

  it("states that non-bookkeeping clients are also served", () => {
    // A visitor who only wants a personal return should not have to guess.
    expect(entry!.answer.toLowerCase()).toContain("not bookkeeping clients");
  });

  it("carries search terms an individual would actually type", () => {
    const keywords = entry!.keywords.toLowerCase();
    for (const term of ["personal", "1040", "individual"]) {
      expect(keywords).toContain(term);
    }
  });

  it("uses a unique id", () => {
    const ids = FAQ_ENTRIES.map(f => f.id);
    expect(new Set(ids).size).toBe(ids.length);
  });
});

describe("search index coverage", () => {
  it("has a dedicated individual tax return entry", () => {
    const entry = SEARCH_INDEX.find(e => e.title === "Individual Tax Return Preparation");
    expect(entry).toBeDefined();
    // Points at the dedicated section, not the general tax card.
    expect(entry!.href).toBe("/services#individual-tax-returns");
  });

  it("matches a search for personal returns", () => {
    // Mirrors how SearchDialog filters: title + description + keywords.
    const haystack = (e: (typeof SEARCH_INDEX)[number]) =>
      `${e.title} ${e.description} ${e.keywords}`.toLowerCase();
    for (const query of ["personal", "1040", "individual", "my taxes"]) {
      const hits = SEARCH_INDEX.filter(e => haystack(e).includes(query));
      expect(hits.length, `no search hit for "${query}"`).toBeGreaterThan(0);
    }
  });

  it("still surfaces the general tax preparation section", () => {
    const entry = SEARCH_INDEX.find(e => e.title === "Tax Preparation");
    expect(entry).toBeDefined();
    expect(entry!.description.toLowerCase()).toContain("individual");
  });
});

describe("individual tax section content", () => {
  it("describes the full engagement from documents to filing", () => {
    expect(INDIVIDUAL_TAX_STEPS.length).toBeGreaterThanOrEqual(3);
    const all = INDIVIDUAL_TAX_STEPS.map(s => `${s.title} ${s.body}`)
      .join(" ")
      .toLowerCase();
    // The remote-first promise and the paper fallback must both be stated.
    expect(all).toContain("no appointment");
    expect(all).toContain("hard copies");
    // The client approves before anything is filed.
    expect(all).toContain("approved");
    expect(all).toContain("e-file");
  });

  it("states turnaround as business days from a complete document set", () => {
    expect(INDIVIDUAL_TAX_TURNAROUND.length).toBeGreaterThanOrEqual(2);
    const simple = INDIVIDUAL_TAX_TURNAROUND[0];
    expect(simple.window.toLowerCase()).toContain("business days");
    // Every tier needs a window and an explanation of what it covers.
    for (const tier of INDIVIDUAL_TAX_TURNAROUND) {
      expect(tier.label.length).toBeGreaterThan(0);
      expect(tier.window.length).toBeGreaterThan(0);
      expect(tier.detail.length).toBeGreaterThan(20);
    }
  });

  it("groups the document checklist and covers the core tax forms", () => {
    const ids = INDIVIDUAL_TAX_DOCUMENTS.map(g => g.id);
    expect(new Set(ids).size).toBe(ids.length);
    const all = INDIVIDUAL_TAX_DOCUMENTS.flatMap(g => g.items)
      .join(" ")
      .toLowerCase();
    // Forms nearly every individual filer will encounter.
    for (const form of ["w-2", "1099-nec", "1099-int", "1098", "k-1", "ssa-1099"]) {
      expect(all, `checklist is missing ${form}`).toContain(form);
    }
    // Identity essentials, without which a return cannot be filed.
    expect(all).toContain("social security number");
    expect(all).toContain("routing");
  });

  it("prompts for life changes that alter the outcome", () => {
    const group = INDIVIDUAL_TAX_DOCUMENTS.find(g => g.id === "life-changes");
    expect(group).toBeDefined();
    const all = group!.items.join(" ").toLowerCase();
    for (const change of ["marriage", "dependent", "home", "state"]) {
      expect(all).toContain(change);
    }
  });

  it("gives every group at least a few items", () => {
    for (const group of INDIVIDUAL_TAX_DOCUMENTS) {
      expect(group.items.length, `${group.id} is too sparse`).toBeGreaterThanOrEqual(3);
      expect(group.title.length).toBeGreaterThan(0);
    }
  });
});

describe("individual tax FAQ additions", () => {
  it("answers whether an in-person appointment is needed", () => {
    const entry = FAQ_ENTRIES.find(f => f.id === "individual-remote");
    expect(entry).toBeDefined();
    const answer = entry!.answer.toLowerCase();
    expect(answer).toContain("no in-person appointment");
    // Electronic preferred, paper accepted — both halves must be present.
    expect(answer).toContain("electronic");
    expect(answer).toContain("hard copies");
  });

  it("answers how long a return takes, with the caveat about missing forms", () => {
    const entry = FAQ_ENTRIES.find(f => f.id === "individual-turnaround");
    expect(entry).toBeDefined();
    const answer = entry!.answer.toLowerCase();
    expect(answer).toContain("five to seven business days");
    expect(answer).toContain("complete set of documents");
    // An extension defers filing, not payment: worth stating explicitly.
    expect(answer).toContain("not the payment date");
  });
});

describe("search routes to the individual tax section", () => {
  const sectionHref = "/services#individual-tax-returns";

  it("links the individual return entries to the dedicated section", () => {
    const entries = SEARCH_INDEX.filter(e => e.href === sectionHref);
    expect(entries.length).toBeGreaterThanOrEqual(3);
  });

  it("matches document and turnaround searches", () => {
    const haystack = (e: (typeof SEARCH_INDEX)[number]) =>
      `${e.title} ${e.description} ${e.keywords}`.toLowerCase();
    for (const query of ["w-2", "1099", "what to send", "how long", "turnaround", "hard copy"]) {
      const hits = SEARCH_INDEX.filter(e => haystack(e).includes(query));
      expect(hits.length, `no search hit for "${query}"`).toBeGreaterThan(0);
    }
  });
});
