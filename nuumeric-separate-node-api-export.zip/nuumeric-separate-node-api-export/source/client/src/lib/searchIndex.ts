import { BUSINESS_HOURS, formatCityLine, formatStreetAddress } from "@shared/site";
import { FAQ_ENTRIES } from "./faq";

/**
 * Client-side search index covering every page and major section of the site.
 * Each entry deep-links to a route (optionally with a #hash handled by the
 * target page's scroll effect).
 */
export interface SearchEntry {
  /** Route to navigate to, may include a #section hash */
  href: string;
  /** Short display title */
  title: string;
  /** Page group shown as the section heading in results */
  page: string;
  /** Longer description shown under the title */
  description: string;
  /** Extra terms matched during search but not displayed */
  keywords: string;
}

export const SEARCH_INDEX: SearchEntry[] = [
  // ————— Pages —————
  {
    href: "/",
    title: "Home",
    page: "Pages",
    description: "Expert Solutions for Growing Enterprises — US-based back-office support",
    keywords: "homepage main landing start nuumeric",
  },
  {
    href: "/services",
    title: "Services",
    page: "Pages",
    description: "Bookkeeping, tax preparation, payroll processing, and additional services",
    keywords: "what we do offerings pricing",
  },
  {
    href: "/about",
    title: "About Us",
    page: "Pages",
    description: "Leigh Ann Smith, our story, and why businesses rely on Nuumeric",
    keywords: "team history company leigh ann smith montgomery",
  },
  {
    href: "/what-to-expect",
    title: "What to Expect",
    page: "Pages",
    description:
      "Six promises to every client: free consultation, dedicated bookkeeper, fixed fees, cancel-anytime guarantee, transparency, 24-hour turnaround",
    keywords:
      "how we work process expectations onboarding guarantee consultation dedicated bookkeeper fixed fees transparency turnaround promises",
  },
  {
    href: "/careers",
    title: "Careers",
    page: "Pages",
    description:
      "Join the Nuumeric team — browse open positions on our career portal",
    keywords:
      "jobs hiring employment careers work for us open positions apply recruiting bookkeeper accountant zoho recruit",
  },
  {
    href: "/blog",
    title: "Blog",
    page: "Pages",
    description:
      "Insights on bookkeeping, payroll, and cloud accounting — written for business owners",
    keywords:
      "articles posts news insights tips guides bookkeeping payroll zoho books xero quickbooks accounting blog",
  },
  {
    href: "/contact",
    title: "Contact & Quote Request",
    page: "Pages",
    description: "Request a quote or call 1 (936) 337-5446",
    keywords: "phone email form quote estimate pricing reach",
  },
  // ————— Legal —————
  {
    href: "/privacy-policy",
    title: "Privacy Policy",
    page: "Legal",
    description: "How Nuumeric collects, uses, and protects your personal information",
    keywords: "privacy data protection gdpr ccpa personal information legal",
  },
  {
    href: "/terms-and-conditions",
    title: "Terms & Conditions",
    page: "Legal",
    description: "Terms governing the use of Nuumeric's website and services",
    keywords: "terms of service tos conditions agreement legal",
  },
  {
    href: "/cookie-policy",
    title: "Cookie Policy",
    page: "Legal",
    description: "Which cookies we use and how to manage your consent preferences",
    keywords: "cookies consent tracking preferences banner legal",
  },
  // ————— Services —————
  {
    href: "/services#bookkeeping",
    title: "Bookkeeping",
    page: "Services",
    description: "Reconciliations, invoicing, payables, monthly reporting, catch-up books",
    keywords: "bank credit card reconciliation invoicing receivables accounts payable monthly financial reporting catch-up clean-up ledger books",
  },
  {
    href: "/services#tax-preparation",
    title: "Tax Preparation",
    page: "Services",
    description: "Business and individual returns, year-round planning, quarterly estimates",
    keywords: "tax return filing irs quarterly estimated planning cpa audit-ready season business individual personal 1040",
  },
  {
    href: "/services#individual-tax-returns",
    title: "Individual Tax Return Preparation",
    page: "Services",
    description: "Personal returns handled remotely — process, turnaround, and what to send",
    keywords:
      "individual personal 1040 own taxes owner self household married joint single family income tax return prepare filing remote no appointment",
  },
  {
    href: "/services#individual-tax-returns",
    title: "Individual Return Turnaround Time",
    page: "Services",
    description: "5–7 business days for a straightforward return from a complete document set",
    keywords:
      "turnaround how long time days fast quick deadline extension when ready wait timeline individual personal return",
  },
  {
    href: "/services#individual-tax-returns",
    title: "Documents to Send for Your Tax Return",
    page: "Services",
    description: "Checklist: W-2, 1099, 1098, K-1, deductions, credits, and life changes",
    keywords:
      "documents checklist what to send bring w-2 w2 1099 1098 1095 k-1 ssa-1099 receipts records paperwork forms upload portal hard copy mail paper social security number dependents",
  },
  {
    href: "/services#payroll-processing",
    title: "Payroll Processing",
    page: "Services",
    description: "Full-service payroll with Gusto and SurePayroll, tax filings, onboarding",
    keywords: "gusto surepayroll payroll runs employees pay tax deposits new hire onboarding",
  },
  {
    href: "/services#additional-services",
    title: "Additional Services",
    page: "Services",
    description: "Zoho CRM/Sites support, Xero, QuickBooks, HR and financial reporting",
    keywords: "zoho crm sites xero quickbooks setup migration advisory software hr human resources technology",
  },
  // ————— About —————
  {
    href: "/about",
    title: "Leigh Ann Smith",
    page: "About Us",
    description: "President of Nuumeric — more than 28 years of financial expertise",
    keywords: "founder president bio leadership experience owner",
  },
  {
    href: "/about",
    title: "Our Story — Formerly Montgomery Bookkeeping Solutions",
    page: "About Us",
    description: "How Montgomery Bookkeeping Solutions became Nuumeric Inc",
    keywords: "history origin rebrand montgomery bookkeeping solutions name change",
  },
  {
    href: "/about",
    title: "Trust & Credentials",
    page: "About Us",
    description: "Insured and bondable; Zoho, Xero, QuickBooks, Gusto, SurePayroll certified",
    keywords: "insured bondable certificate insurance coi certifications zoho authorized partner xero advisor quickbooks proadvisor gusto surepayroll accountant",
  },
  // ————— Industries —————
  {
    href: "/#industries",
    title: "Industries We Serve",
    page: "Client Industries",
    description: "Medical, wholesale, auto repair, restaurants, B2B, and online retail",
    keywords: "medical practices wholesale distribution auto repair shops restaurants b2b services online retail ecommerce clients businesses who we serve",
  },
  // ————— Contact —————
  {
    href: "/contact",
    title: "Request a Quote",
    page: "Contact",
    description: "Tell us what you need and get a tailored quote within one business day",
    keywords: "lead form estimate pricing cost consultation free",
  },
  {
    href: "/contact",
    title: "Call or Text 1 (936) 337-5446",
    page: "Contact",
    description: "Reach a real person who can answer your questions on the spot",
    keywords: "phone number telephone call text whatsapp",
  },
  {
    href: "/contact",
    title: "Office Location",
    page: "Contact",
    description: `${formatStreetAddress()}, ${formatCityLine()}`,
    keywords:
      "address office directions where located charlotte north carolina nc tower point suite b14 map visit",
  },
  {
    href: "/contact",
    title: "Business Hours",
    page: "Contact",
    description: `${BUSINESS_HOURS.daysDisplay}, ${BUSINESS_HOURS.timeDisplay} ${BUSINESS_HOURS.timezoneDisplay}`,
    keywords: "hours open opening times when available schedule weekday monday friday",
  },
  // ————— FAQ (generated from the Services page FAQ entries) —————
  ...FAQ_ENTRIES.map(faq => ({
    href: `/services?q=${faq.id}#faq-${faq.id}`,
    title: faq.question,
    page: "FAQ",
    description:
      faq.answer.length > 90 ? `${faq.answer.slice(0, 87).trimEnd()}...` : faq.answer,
    keywords: `faq question ${faq.keywords}`,
  })),
];
