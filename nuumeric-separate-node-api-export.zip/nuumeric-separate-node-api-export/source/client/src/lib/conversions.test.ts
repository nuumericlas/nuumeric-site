// @vitest-environment jsdom
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
  ADS_CONVERSION_LABELS,
  GOOGLE_ADS_ID,
  hasAdsLabels,
  trackConversion,
} from "./conversions";

const indexHtml = readFileSync(
  resolve(__dirname, "../../index.html"),
  "utf-8",
);

describe("Google Ads tag installation", () => {
  it("uses the account's conversion ID", () => {
    expect(GOOGLE_ADS_ID).toBe("AW-18380599483");
  });

  it("configures the Ads account in index.html", () => {
    expect(indexHtml).toContain(`gtag("config", "AW-18380599483")`);
  });

  it("keeps the GA4 measurement config alongside it", () => {
    // Both must be configured on the same gtag instance, otherwise the Ads
    // conversion and the GA4 lead event cannot share one page load.
    expect(indexHtml).toContain(`gtag("config", "G-ECKM2GTE74"`);
  });

  it("still defaults ad storage to denied for Consent Mode", () => {
    // The Termly banner grants consent later; defaulting to denied is what
    // keeps the site compliant before a visitor chooses.
    expect(indexHtml).toContain(`ad_storage: "denied"`);
    expect(indexHtml).toContain(`ad_user_data: "denied"`);
  });
});

describe("trackConversion", () => {
  let gtagCalls: unknown[][];
  let dataLayer: unknown[];

  beforeEach(() => {
    gtagCalls = [];
    dataLayer = [];
    (window as any).gtag = (...args: unknown[]) => gtagCalls.push(args);
    (window as any).dataLayer = dataLayer;
  });

  afterEach(() => {
    (window as any).gtag = undefined;
    (window as any).dataLayer = undefined;
  });

  it("sends a GA4 generate_lead event for quote submissions", () => {
    trackConversion("quote", { source: "contact_form", service: "Bookkeeping" });
    const ga4 = gtagCalls.find(c => c[1] === "generate_lead");
    expect(ga4).toBeDefined();
    const params = ga4![2] as Record<string, unknown>;
    expect(params.lead_source).toBe("contact_form");
    expect(params.service).toBe("Bookkeeping");
  });

  it("treats referrals as leads too", () => {
    trackConversion("referral", { source: "refer_page" });
    expect(gtagCalls.some(c => c[1] === "generate_lead")).toBe(true);
  });

  it("uses a distinct event name for phone clicks", () => {
    trackConversion("phone", { source: "nav_desktop" });
    const call = gtagCalls.find(c => c[1] === "phone_click");
    expect(call).toBeDefined();
    expect((call![2] as Record<string, unknown>).lead_source).toBe("nav_desktop");
  });

  it("pushes a namespaced dataLayer event so GTM can trigger on it", () => {
    trackConversion("quote", { source: "contact_form" });
    const pushed = dataLayer.find(
      (d: any) => d?.event === "nuumeric_quote",
    ) as Record<string, unknown> | undefined;
    expect(pushed).toBeDefined();
    expect(pushed!.lead_source).toBe("contact_form");
  });

  it("skips the Ads conversion hit while no label is configured", () => {
    // A send_to of "AW-.../" with an empty label is silently discarded by
    // Google, which would masquerade as working tracking. We must not send it.
    trackConversion("quote", { source: "contact_form" });
    const adsCall = gtagCalls.find(c => c[1] === "conversion");
    if (!ADS_CONVERSION_LABELS.quote) {
      expect(adsCall).toBeUndefined();
    } else {
      expect(adsCall).toBeDefined();
    }
  });

  it("never throws when gtag and dataLayer are missing", () => {
    (window as any).gtag = undefined;
    (window as any).dataLayer = undefined;
    // Ad blockers routinely strip gtag; a lead must still be able to submit.
    expect(() => trackConversion("quote", { source: "contact_form" })).not.toThrow();
  });

  it("reports whether any Ads label has been configured", () => {
    const expected = Object.values(ADS_CONVERSION_LABELS).some(l => l.length > 0);
    expect(hasAdsLabels()).toBe(expected);
  });
});

describe("conversion wiring in the pages", () => {
  const read = (p: string) => readFileSync(resolve(__dirname, "..", p), "utf-8");

  it("fires the quote conversion only from the mutation's onSuccess", () => {
    const contact = read("pages/Contact.tsx");
    expect(contact).toContain('trackConversion("quote"');
    // Must sit after onSuccess so failed/filtered submissions aren't counted.
    const onSuccessIdx = contact.indexOf("onSuccess");
    const trackIdx = contact.indexOf('trackConversion("quote"');
    expect(onSuccessIdx).toBeGreaterThan(-1);
    expect(trackIdx).toBeGreaterThan(onSuccessIdx);
  });

  it("fires the referral conversion on success", () => {
    expect(read("pages/Refer.tsx")).toContain('trackConversion("referral"');
  });

  it("routes every phone link through the tracking component", () => {
    for (const file of [
      "components/SiteNav.tsx",
      "components/SiteFooter.tsx",
      "pages/Contact.tsx",
      "pages/Home.tsx",
      "pages/Services.tsx",
      "pages/NotFound.tsx",
    ]) {
      const src = read(file);
      expect(src, `${file} still has an untracked tel: link`).not.toMatch(
        /href=\{SITE\.phoneHref\}/,
      );
      expect(src, `${file} should use PhoneLink`).toContain("PhoneLink");
    }
  });
});
