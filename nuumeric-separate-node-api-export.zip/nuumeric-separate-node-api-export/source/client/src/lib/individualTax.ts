/**
 * Content for the "Individual Tax Returns" section on the Services page.
 *
 * Kept in its own module (rather than inline JSX) so the same copy can feed the
 * visible section, the search index, and any future structured data without the
 * three drifting apart. Turnaround figures are business days and deliberately
 * expressed as ranges with a stated start point — the clock begins when the
 * document set is complete, not when the client first makes contact, which is
 * the single most common cause of disputes about timing.
 */

export interface DocumentGroup {
  id: string;
  title: string;
  /** Shown when the group does not apply to everyone. */
  note?: string;
  items: string[];
}

/** How the engagement runs, start to finish. */
export const INDIVIDUAL_TAX_STEPS: { title: string; body: string }[] = [
  {
    title: "Send your documents",
    body: "Upload everything through our secure client portal, or drop off / mail hard copies if that suits you better. No appointment and no office visit is required at any point.",
  },
  {
    title: "We review and follow up",
    body: "We read through what you have sent and come back with a short list of anything missing or unclear. Most returns need one round of follow-up; answering it quickly is what keeps the timeline short.",
  },
  {
    title: "Preparation and your review",
    body: "We prepare the return and send it to you with a summary of the outcome and anything worth noting for next year. Nothing is filed until you have read it and approved it.",
  },
  {
    title: "E-file and confirmation",
    body: "Once you sign, we e-file and send you confirmation along with a complete copy of the return for your records.",
  },
];

/** Turnaround expectations, in business days from a complete document set. */
export const INDIVIDUAL_TAX_TURNAROUND: {
  label: string;
  window: string;
  detail: string;
}[] = [
  {
    label: "Straightforward return",
    window: "5 – 7 business days",
    detail:
      "W-2 income, standard deduction, common credits. Prepared and back to you for review within about a week of receiving a complete set of documents.",
  },
  {
    label: "Itemized or multi-source",
    window: "7 – 12 business days",
    detail:
      "Itemized deductions, investment or rental income, multiple states, or self-employment income on Schedule C.",
  },
  {
    label: "Owner return with the business",
    window: "Alongside the business filing",
    detail:
      "When we also prepare your business return, the personal return follows it, since the figures flow from one to the other.",
  },
];

/** What to gather. Grouped so people can skip what does not apply. */
export const INDIVIDUAL_TAX_DOCUMENTS: DocumentGroup[] = [
  {
    id: "identity",
    title: "Identity and basics",
    items: [
      "Full legal name, date of birth, and Social Security number for you, your spouse, and any dependents",
      "Current mailing address and best contact number",
      "Last year's filed tax return, if we did not prepare it",
      "Bank routing and account number for direct deposit or payment",
      "IRS Identity Protection PIN, if one has been issued to you",
    ],
  },
  {
    id: "income",
    title: "Income",
    items: [
      "W-2 forms from each employer",
      "1099-NEC or 1099-MISC for contract and freelance work",
      "1099-INT, 1099-DIV, and 1099-B for interest, dividends, and investment sales",
      "1099-R for retirement plan and pension distributions",
      "SSA-1099 for Social Security benefits",
      "1099-G for unemployment compensation or state tax refunds",
      "K-1 statements from partnerships, S corporations, estates, or trusts",
      "Records of rental income and expenses, if you own rental property",
      "Records of self-employment income and expenses not reported on a 1099",
    ],
  },
  {
    id: "deductions",
    title: "Deductions and credits",
    note: "Only what applies to you — most people need just a few of these.",
    items: [
      "1098 mortgage interest statement and property tax records",
      "1098-T tuition statement and 1098-E student loan interest",
      "1095-A if you had Marketplace health coverage",
      "Childcare provider details, including their tax ID, and amounts paid",
      "Charitable contribution receipts, cash and non-cash",
      "Records of estimated tax payments made during the year",
      "Retirement contributions to an IRA or HSA",
      "Medical expenses, if they were unusually high this year",
    ],
  },
  {
    id: "life-changes",
    title: "Life changes worth telling us about",
    note: "These often change the outcome, and they are easy to forget to mention.",
    items: [
      "Marriage, divorce, or a change in filing status",
      "A new dependent, or a dependent who is no longer one",
      "Buying or selling a home",
      "Moving to or from another state",
      "Starting or closing a business",
      "An inheritance, or a significant gift given or received",
    ],
  },
];
