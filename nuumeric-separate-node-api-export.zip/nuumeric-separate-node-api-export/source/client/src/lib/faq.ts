/**
 * Frequently asked questions shown on the Services page and indexed by the
 * command-palette search. Each entry has a stable id used as both the
 * accordion item value and the URL hash (/services#faq&q=<id> style deep
 * links are handled via the `q` query param on the services route).
 */
export interface FaqEntry {
  id: string;
  question: string;
  answer: string;
  /** Extra search-only terms */
  keywords: string;
}

export const FAQ_ENTRIES: FaqEntry[] = [
  {
    id: "pricing",
    question: "How much do your services cost?",
    answer:
      "Every engagement is quoted individually, because no two businesses need the same level of support. After a short conversation about your volume, tools, and goals, we provide a tailored flat-rate quote — no hourly surprises, and you can scale services up or down as your needs change. Request a quote and we'll respond within one business day.",
    keywords: "price pricing cost fees rates quote flat rate monthly how much",
  },
  {
    id: "getting-started",
    question: "What does getting started look like?",
    answer:
      "We begin with a brief discovery call to understand your business, then review the current state of your books. If catch-up or clean-up work is needed, we handle that first so you start from a clean baseline. Most clients are fully onboarded within one to two weeks.",
    keywords: "onboarding start begin process discovery call setup switch timeline",
  },
  {
    id: "switching",
    question: "Can you take over from our current bookkeeper or software?",
    answer:
      "Yes. We regularly take over books mid-year and migrate clients between platforms. As certified advisors for QuickBooks, Xero, and Zoho, we can either work in your existing system or recommend and manage a migration if a different platform would serve you better.",
    keywords: "switch change bookkeeper accountant migrate migration transfer takeover mid-year convert",
  },
  {
    id: "individual-returns",
    question: "Do you prepare individual tax returns, or only business returns?",
    answer:
      "We prepare both. Alongside small business returns, we handle individual (personal) returns — including for business owners whose personal filing depends on how the business year closed. Keeping both with one preparer means the figures that flow from your business to your personal return are consistent, and you are not coordinating between two firms at the busiest time of year. We also prepare individual returns for people who are not bookkeeping clients.",
    keywords:
      "individual personal 1040 own return owner self me my taxes household married joint single filing family not a business",
  },
  {
    id: "individual-remote",
    question: "Do I need to come into the office to have my tax return prepared?",
    answer:
      "No. Individual returns are handled entirely remotely, and no in-person appointment is required at any stage. We prefer to collect everything electronically through our secure client portal, because it is faster and nothing can go missing in the post. That said, we understand not everyone wants to work that way — if you would rather send paper forms and statements, we will process hard copies just the same. Call or text us first so we know to watch for them.",
    keywords:
      "in person appointment office visit come in remote virtual online electronic upload portal secure hard copy paper mail drop off scan email",
  },
  {
    id: "individual-turnaround",
    question: "How long does an individual tax return take?",
    answer:
      "A straightforward return — W-2 income, standard deduction, common credits — is usually prepared and back to you for review within five to seven business days. Returns with itemized deductions, investment or rental income, multiple states, or self-employment income typically take seven to twelve. Those timings start from the point we have a complete set of documents, not from your first message, so a single missing form is the usual reason a return takes longer than expected. If you come to us close to a filing deadline we will tell you honestly whether it can be filed in time or whether an extension makes more sense — and note that an extension moves the filing date, not the payment date.",
    keywords:
      "how long turnaround time days weeks fast quick when ready deadline extension april late rush timeline expect",
  },
  {
    id: "why-bookkeeper",
    question: "What does a bookkeeper provide to my business that I can't do myself?",
    answer:
      "Honestly? Nothing you couldn't do yourself — the same way you could cut your own hair. The real question is whether you should. A professional bookkeeper brings three things that are hard to replicate: time (the hours you spend reconciling are hours not spent selling), accuracy (we catch miscategorized expenses, duplicate charges, and missed deductions that quietly cost you money), and perspective (clean books reveal trends — shrinking margins, creeping costs — while there's still time to act). Most owners who hand off their books tell us the same thing: they wish they'd done it sooner.",
    keywords: "why bookkeeper diy do it myself value benefit worth hire professional vs self",
  },
  {
    id: "software-benefits",
    question: "What are the benefits of using bookkeeping software or apps?",
    answer:
      "Modern platforms like QuickBooks, Xero, and Zoho Books do the heavy lifting that used to fill shoeboxes: they pull transactions straight from your bank, match receipts automatically, invoice your customers, and keep everything in one searchable place. The result is fewer errors, faster month-end closes, and reports you can pull on demand instead of waiting for tax season. The catch is that software is only as good as its setup and upkeep — a misconfigured chart of accounts produces very tidy-looking wrong numbers. That's where we come in: we set the system up correctly, keep it maintained, and make sure the automation works for you rather than against you.",
    keywords: "software apps quickbooks xero zoho books benefits automation cloud accounting technology tools",
  },
  {
    id: "real-time-data",
    question: "Will I see my data in real time?",
    answer:
      "Yes — that's one of the best parts of cloud-based bookkeeping. Your books live in your accounting platform, not on our hard drive, so you can log in any time from your laptop or phone and see the same numbers we see. Bank feeds sync transactions daily, and we keep everything reconciled on a regular schedule, so what you're looking at is current — not a snapshot from three months ago. You own your data and your account; we're simply the ones keeping it accurate.",
    keywords: "real time realtime live data access dashboard visibility cloud login anytime transparency",
  },
  {
    id: "training",
    question: "Do you provide training?",
    answer:
      "Yes — with one clarification. We don't teach bookkeeping as a discipline, but we absolutely teach you and your team how to use your bookkeeping systems. Whether it's running reports in QuickBooks, sending invoices from Xero, or navigating Zoho Books, we'll walk you through the parts of the platform you need day to day, so the software works for you instead of intimidating you. Think of it this way: we handle the accounting; we make sure you're comfortable with the tools.",
    keywords: "training teach learn how to use quickbooks xero zoho onboarding tutorial help support education",
  },
  {
    id: "sales-channel-reports",
    question: "Doesn't my sales channels' tools provide all that I need to generate financial reports?",
    answer:
      "They're a great start, but they only tell part of the story. Shopify, Amazon, Square, and similar platforms report what happened inside their own walls — sales, refunds, and their own fees. What they can't see is everything else: payroll, rent, insurance, software subscriptions, loan payments, inventory purchased elsewhere, and how it all rolls up into actual profit. Real financial reports reconcile every channel against your bank accounts and expenses in one place — that's how you learn not just what you sold, but what you kept. If you sell across multiple channels, consolidated books aren't a luxury; they're the only way to see the whole picture.",
    keywords: "shopify amazon square stripe etsy sales channel reports ecommerce platform profit consolidated multichannel",
  },
  {
    id: "software",
    question: "Which accounting and payroll platforms do you support?",
    answer:
      "We are a Zoho Finance Advisor, Xero Advisor, and QuickBooks ProAdvisor, and we process payroll through Gusto and SurePayroll as certified partners. If you use something else, ask — chances are we've worked with it.",
    keywords: "quickbooks xero zoho gusto surepayroll software platforms tools apps supported",
  },
  {
    id: "us-based",
    question: "Is your team really US-based?",
    answer:
      "Yes — all work is performed by our US-based team. Your books are never outsourced overseas, and you communicate directly with the people doing the work, led personally by Leigh Ann Smith.",
    keywords: "us based usa american team outsourced overseas offshore who does the work",
  },
  {
    id: "security",
    question: "How do you keep our financial data secure?",
    answer:
      "Nuumeric is insured and bondable, and a Certificate of Insurance (COI) is available upon request. We work inside your accounting platforms using bank-level encrypted connections and least-privilege access, and we never store your credentials in plain text.",
    keywords: "security secure data privacy insured bondable coi certificate insurance confidential safe",
  },
  {
    id: "industries",
    question: "Do you work with businesses in my industry?",
    answer:
      "We serve a wide range of industries, including medical and professional practices, wholesale distributors, auto repair shops, restaurants, B2B service companies, and online retailers. If your industry isn't listed, reach out — our processes adapt to almost any small or mid-sized business.",
    keywords: "industry medical wholesale auto repair restaurant b2b online retail ecommerce niche vertical",
  },
  {
    id: "communication",
    question: "How often will we hear from you?",
    answer:
      "As often as you'd like. Most clients receive monthly financial reports with a summary of what changed and why, and you can call or text 1 (936) 337-5446 any time a question comes up — you'll reach a real person, not a ticket queue.",
    keywords: "communication reports monthly updates contact responsiveness support meetings",
  },
];
