import { SITE } from "@shared/site";

/**
 * Build the canonical, share-safe URL for a blog post.
 * Always uses the production origin (www.nuumeric.com) so links shared
 * from previews or other bound domains still point readers to the
 * canonical site.
 */
export function canonicalPostUrl(slug: string): string {
  return `${SITE.canonicalOrigin}/blog/${encodeURIComponent(slug)}`;
}

export interface ShareTarget {
  name: string;
  /** Builds the share intent URL for the given page url + title. */
  href: (url: string, title: string) => string;
}

export const SHARE_TARGETS: Record<
  "linkedin" | "facebook" | "x" | "whatsapp" | "email",
  ShareTarget
> = {
  linkedin: {
    name: "LinkedIn",
    href: url =>
      `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
  },
  facebook: {
    name: "Facebook",
    href: url =>
      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
  },
  x: {
    name: "X",
    href: (url, title) =>
      `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`,
  },
  whatsapp: {
    name: "WhatsApp",
    href: (url, title) =>
      `https://wa.me/?text=${encodeURIComponent(`${title} ${url}`)}`,
  },
  email: {
    name: "Email",
    href: (url, title) =>
      `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(
        `I thought you might find this useful:\n\n${title}\n${url}`,
      )}`,
  },
};
