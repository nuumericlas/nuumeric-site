import type { QueryClient } from "@tanstack/react-query";
import { getQueryKey } from "@trpc/react-query";
// Value import of @trpc/server is safe HERE ONLY: this file is imported by the
// server entry graph (entry-server.tsx / ssrCaller), never by entry-client.
import { TRPCError } from "@trpc/server";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../server/routers";
import { trpc } from "@/lib/trpc";
import { SITE } from "@shared/site";

export type HeadMeta = {
  title: string;
  description: string;
  ogType?: "website" | "article";
  ogImage?: string;
  ogImageWidth?: number;
  ogImageHeight?: number;
  ogImageAlt?: string;
  publishedTime?: string;
  modifiedTime?: string;
  /** path only (e.g. "/blog/foo"); composeHtml prepends the canonical origin */
  canonicalPath?: string;
  /** 200 but not indexable (auth-gated shells) */
  noindex?: boolean;
  /** unknown route / slug miss → server responds 404 + noindex */
  notFound?: boolean;
};

type RO = inferRouterOutputs<AppRouter>;

// Allowlist: only these procedures are reachable from SSR prefetch.
export type SsrPrefetch = {
  blogList: () => Promise<RO["blog"]["list"]>;
  blogBySlug: (slug: string) => Promise<RO["blog"]["getBySlug"]>;
};

async function seed(qc: QueryClient, key: unknown, data: unknown) {
  qc.setQueryData(key as never, data as never);
}

const SITE_TITLE = "Nuumeric Inc — Expert Solutions for Growing Enterprises";
const DEFAULT_DESC =
  "US-based bookkeeping, business and individual tax preparation, and payroll for growing enterprises. Nuumeric — expert back-office support in Charlotte, NC.";

/** Static public routes: title + description + canonical path. */
const STATIC_ROUTES: Record<string, { title: string; description: string }> = {
  "/": {
    title: SITE_TITLE,
    description: DEFAULT_DESC,
  },
  "/services": {
    title: `Services — Bookkeeping, Tax & Payroll · ${SITE.name}`,
    description:
      "Explore Nuumeric's bookkeeping, business and individual tax preparation, payroll, and back-office services for growing US businesses, with FAQs.",
  },
  "/about": {
    title: `About Us · ${SITE.name}`,
    description:
      "Learn about Nuumeric Inc (formerly Montgomery Bookkeeping Solutions): our story, values, and the team behind your books since 2017.",
  },
  "/what-to-expect": {
    title: `What to Expect · ${SITE.name}`,
    description:
      "What to expect when you work with Nuumeric: onboarding, communication, timelines, and how we keep your books accurate month after month.",
  },
  "/careers": {
    title: `Careers · ${SITE.name}`,
    description:
      "Join the Nuumeric team. See open roles in bookkeeping, tax, and client services.",
  },
  "/blog": {
    title: `Blog — Small Business Finance Insights · ${SITE.name}`,
    description:
      "Practical articles on bookkeeping, taxes, payroll, QuickBooks, and running a small business, from the Nuumeric team.",
  },
  "/contact": {
    title: `Contact Us — Request a Quote · ${SITE.name}`,
    description:
      "Request a quote or ask a question. Call 1 (936) 337-5446 or send us a message — we respond within one business day.",
  },
  "/refer": {
    title: `Refer a Business, Earn $100 · ${SITE.name}`,
    description:
      "Know a business that needs bookkeeping, tax, or payroll help? Refer them to Nuumeric and earn a $100 credit toward your next invoice.",
  },
  "/privacy-policy": {
    title: `Privacy Policy · ${SITE.name}`,
    description: "How Nuumeric Inc collects, uses, and protects your information.",
  },
  "/terms-and-conditions": {
    title: `Terms & Conditions · ${SITE.name}`,
    description: "The terms and conditions governing use of the Nuumeric website and services.",
  },
  "/cookie-policy": {
    title: `Cookie Policy · ${SITE.name}`,
    description: "How the Nuumeric website uses cookies and how you can manage your preferences.",
  },
};

export async function prefetchForPath(
  url: string,
  qc: QueryClient,
  p: SsrPrefetch
): Promise<HeadMeta> {
  let pathOnly = url.split("?")[0];
  try {
    pathOnly = decodeURI(pathOnly);
  } catch {
    /* malformed: use raw, as wouter does */
  }
  const clean = pathOnly.replace(/\/+$/, "") || "/";

  // Blog index: seed the list under the exact key Blog.tsx uses (input undefined).
  if (clean === "/blog") {
    const posts = await p.blogList();
    await seed(qc, getQueryKey(trpc.blog.list, undefined, "query"), posts);
    const meta = STATIC_ROUTES["/blog"];
    return { ...meta, ogType: "website", canonicalPath: "/blog" };
  }

  // Blog article detail.
  const blogMatch = clean.match(/^\/blog\/([^/]+)$/);
  if (blogMatch) {
    const slug = blogMatch[1];
    let post: RO["blog"]["getBySlug"] | null;
    try {
      post = await p.blogBySlug(slug);
    } catch (e) {
      // Only a genuine miss becomes a 404 — rethrow outages so the outer
      // handler serves the 200 shell instead of deindexing real pages.
      if (e instanceof TRPCError && e.code === "NOT_FOUND") post = null;
      else throw e;
    }
    if (!post) return { title: SITE_TITLE, description: DEFAULT_DESC, notFound: true };
    await seed(qc, getQueryKey(trpc.blog.getBySlug, { slug }, "query"), post);
    return {
      title: post.title?.trim() ? `${post.title} · ${SITE.name}` : SITE_TITLE,
      description: post.seoDescription || post.excerpt || DEFAULT_DESC,
      ogType: "article",
      ogImage: post.coverImageUrl ?? undefined,
      publishedTime: post.publishedAt ? new Date(post.publishedAt).toISOString() : undefined,
      modifiedTime: post.updatedAt ? new Date(post.updatedAt).toISOString() : undefined,
      canonicalPath: clean,
    };
  }

  // Auth-gated admin routes: 200 + noindex, never prefetch private data.
  if (clean === "/admin" || clean.startsWith("/admin/")) {
    return { title: SITE_TITLE, description: DEFAULT_DESC, noindex: true };
  }

  // Head-only static public routes.
  const staticMeta = STATIC_ROUTES[clean];
  if (staticMeta) {
    return { ...staticMeta, ogType: "website", canonicalPath: clean };
  }

  // Anything else (including /404): real 404 + noindex.
  return { title: SITE_TITLE, description: DEFAULT_DESC, notFound: true };
}
