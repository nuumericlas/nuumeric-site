# Google Ads conversion tracking — finishing the setup

The Google Ads tag is installed and live. Remarketing and audience collection
are already working. What is **not** yet working is conversion *reporting* —
telling Ads which clicks turned into leads — because that requires one more
value per conversion action that only exists inside your Ads account.

## What is already installed

| Item | Value | Status |
|---|---|---|
| Google Ads account tag | `AW-18380599483` | Live |
| GA4 measurement | `G-ECKM2GTE74` | Live |
| GTM container | `GTM-P3S4KDRK` | Live |
| GA4 `generate_lead` on quote form | — | Live |
| GA4 `generate_lead` on referral form | — | Live |
| GA4 `phone_click` on every phone link | — | Live |
| Ads conversion hits | needs labels | **Pending** |

## Why a second value is needed

The ID you provided (`AW-18380599483`) identifies your *account*. Each
individual conversion action — "quote form submitted", "phone call clicked" —
also gets its own **label**, and the Ads tag needs both:

```
send_to: 'AW-18380599483/AbC-D_efGhIjKlMnOp'
          ^^^^^^^^^^^^^^^ ^^^^^^^^^^^^^^^^^
          account ID      conversion label
```

Without the label there is nothing to attribute the conversion to.

## Where to find each label

> **If you cannot find a conversion label at all, this is normal.** Google has
> been steadily hiding the manual (`AW-ID` + label) path. Many accounts now
> only offer the GA4-import route. See "Route B" below — it needs no label and
> is arguably the better option for this site, because the GA4 lead events are
> already firing.

### Route A — manual label (only if the option appears)

1. Sign in to Google Ads.
2. Go to **Goals → Conversions → Summary**.
3. If you have no conversion actions yet, click **+ New conversion action →
   Website**, enter `nuumeric.com`, and create one. Choose **Submit lead form**
   as the category for the forms, and **Phone call clicks** — or another
   **Contact** action — for the phone links.
4. Click the conversion action, then **Tag setup → Use Google tag → See event
   snippet**.
5. In the snippet you will see a line like:

   ```js
   gtag('event', 'conversion', {'send_to': 'AW-18380599483/AbC-D_efGhIjKlMnOp'});
   ```

   The part **after the slash** is the label.

Repeat for each action you want tracked separately.

#### Why the option is often missing

In current Google Ads accounts, the "Use Google Tag Manager" / manual snippet
view only appears after you have gone through the full creation flow *and* the
account has verified a live Google tag on the site. Even then, some accounts
are on a rollout that offers **only** GA4 import. If, under Goals →
Conversions, your sole option is to import from Google Analytics, you are on
that rollout and no amount of searching will reveal a label. Use Route B.

### Route B — import the GA4 lead events (recommended, no label needed)

The site already sends GA4 events on every lead. Ads can consume those
directly, which means **nothing further needs to change in the website code**.

1. In **Google Analytics** (property G-ECKM2GTE74), go to **Admin → Data
   display → Events**.
2. Find `generate_lead` in the list and switch on **Mark as key event**. Do the
   same for `phone_click` if you want calls counted.
   - If an event is not listed yet, it has not fired since the tag went live.
     Submit a test quote request on the site, wait up to 24 hours, then look
     again under **Recent events**.
3. Confirm Ads and Analytics are linked: in Google Ads, **Tools → Linked
   accounts → Google Analytics (GA4)**. Also confirm **auto-tagging** is on
   (**Tools → Account settings → Auto-tagging**), since without the GCLID
   parameter conversions cannot be attributed back to a click.
4. In Google Ads, go to **Goals → Conversions → Summary → + Create conversion
   action → Import → Google Analytics 4**.
5. Select `generate_lead` (and `phone_click`), then **Save and continue**.

Data appears within about 24 hours. Historical activity from before the import
is not backfilled, so the sooner this is done the sooner the data starts.

### Which route to choose

| | Route A (manual label) | Route B (GA4 import) |
|---|---|---|
| Code change needed | Yes — paste labels | **None** |
| Available in all accounts | No, increasingly hidden | Yes |
| Conversion latency | Near real-time | Up to 24 hours |
| Single source of truth | Ads | Analytics |
| Best for this site | Only if labels are visible | **Recommended** |

Route B is the pragmatic choice here. The one trade-off is latency and the
fact that Analytics becomes the place where lead definitions live — which is
arguably where they belong anyway.

## Where the labels go

In `client/src/lib/conversions.ts`:

```ts
export const ADS_CONVERSION_LABELS = {
  quote: "",     // <- paste the quote-form label here
  referral: "",  // <- paste the referral label here
  phone: "",     // <- paste the phone-click label here
} as const;
```

You can fill in one, two, or all three. Any left empty simply keeps recording
in GA4 without sending an Ads conversion. It is fine to reuse the same label
for more than one action if you would rather see a single combined "lead"
conversion in Ads.

## Why empty labels are skipped rather than sent

Sending `send_to: 'AW-18380599483/'` with an empty label would be accepted by
the browser and silently discarded by Google. Reporting would show zero
conversions with no error anywhere — indistinguishable from having no traffic.
The code therefore skips the Ads hit entirely while a label is blank, and logs
the skip in the browser console during development.

## Verifying it works, once labels are in

1. Install the **Google Tag Assistant** extension, or use **Ads → Goals →
   Conversions → (action) → Diagnostics**.
2. Submit a test quote request on the live site.
3. Accept the cookie banner first — see the consent note below.
4. Conversions typically appear in Ads reporting within 3–24 hours, not
   instantly.

## Consent mode: an important caveat

The Termly banner sets `ad_storage` and `ad_user_data` to `denied` by default
until a visitor accepts cookies. This is deliberate and keeps the site
compliant. The practical consequence is that conversions from visitors who
decline, or who leave without answering, are **modelled** by Google rather
than directly observed.

Expect Ads conversion counts to run somewhat lower than the number of leads
actually in your inbox. That gap is the consent framework working as intended,
not a tracking fault — worth remembering before concluding a campaign is
underperforming.

## Events available in GTM

If you prefer to manage tags from the GTM interface rather than in code, these
custom events are pushed to the dataLayer and can be used as triggers:

| Event name | Fires when |
|---|---|
| `nuumeric_quote` | Quote request accepted by the server |
| `nuumeric_referral` | Referral submitted |
| `nuumeric_phone` | Phone number clicked or tapped |
| `spa_page_view` | Any client-side page navigation |

Each carries `lead_source` (where on the site it happened) and, for quotes,
`service` (which service was selected).
