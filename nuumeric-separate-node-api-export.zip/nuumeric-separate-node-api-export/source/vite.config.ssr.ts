import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";

// Dedicated SSR build config. Omits the template's dev-only plugins
// (jsxLocPlugin, manus runtime, debug collector) which are no-ops in an
// --ssr build; keeps react + tailwind which transform application source.
export default defineConfig({
  root: import.meta.dirname,
  mode: "production",
  define: { "process.env.NODE_ENV": JSON.stringify("production") },
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
    },
  },
  envDir: path.resolve(import.meta.dirname),
  // streamdown's import chain includes katex.min.css which Node's ESM loader
  // cannot evaluate; bundling it through Vite compiles the css import away
  // while keeping the exact markdown renderer for crawlable article bodies.
  ssr: { noExternal: ["streamdown"] },
  build: {
    ssr: path.resolve(import.meta.dirname, "client/src/entry-server.tsx"),
    outDir: path.resolve(import.meta.dirname, "dist/server-ssr"),
    emptyOutDir: true,
    rollupOptions: { output: { entryFileNames: "entry-server.js" } },
  },
});
