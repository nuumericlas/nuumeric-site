import { describe, expect, it } from "vitest";
import {
  BUSINESS_HOURS,
  SITE,
  formatCityLine,
  formatFullAddress,
  formatStreetAddress,
  mapsUrl,
} from "./site";

/**
 * The office address and hours appear in four places: the Contact page, the
 * footer, the homepage LocalBusiness structured data, and the printed door sign
 * used for Google Business Profile verification. A mismatch between any of them
 * is a verification risk, so these tests pin the values and the formatting.
 */
describe("office address", () => {
  it("holds the Charlotte address with the suite in street2", () => {
    expect(SITE.address.street).toBe("8501 Tower Point Dr");
    expect(SITE.address.street2).toBe("Ste B14");
    expect(SITE.address.city).toBe("Charlotte");
    expect(SITE.address.region).toBe("NC");
    expect(SITE.address.postalCode).toBe("28227");
    expect(SITE.address.country).toBe("US");
  });

  it("formats the street line with the suite appended", () => {
    expect(formatStreetAddress()).toBe("8501 Tower Point Dr, Ste B14");
  });

  it("formats the city line as City, ST ZIP", () => {
    expect(formatCityLine()).toBe("Charlotte, NC 28227");
  });

  it("composes a single-line full address", () => {
    expect(formatFullAddress()).toBe(
      "8501 Tower Point Dr, Ste B14, Charlotte, NC 28227",
    );
  });

  it("keeps the ZIP as a string so leading zeros would survive", () => {
    // Guards against someone changing this to a number for a 0-prefixed ZIP.
    expect(typeof SITE.address.postalCode).toBe("string");
  });

  describe("maps link", () => {
    it("points at Google Maps search with the business name and address", () => {
      const url = mapsUrl();
      expect(url.startsWith("https://www.google.com/maps/search/?api=1&query=")).toBe(true);
      const query = decodeURIComponent(url.split("query=")[1]);
      expect(query).toContain(SITE.legalName);
      expect(query).toContain("8501 Tower Point Dr, Ste B14");
      expect(query).toContain("Charlotte, NC 28227");
    });

    it("percent-encodes the query so spaces and commas are safe", () => {
      const url = mapsUrl();
      expect(url).not.toMatch(/query=[^&]*\s/);
      expect(url).toContain("%20");
    });
  });
});

describe("business hours", () => {
  it("publishes Monday-Friday 9 to 5 Eastern", () => {
    expect(BUSINESS_HOURS.daysDisplay).toBe("Monday – Friday");
    expect(BUSINESS_HOURS.timeDisplay).toBe("9:00 AM – 5:00 PM");
    expect(BUSINESS_HOURS.timezoneDisplay).toBe("Eastern Time");
  });

  it("uses an en dash rather than a hyphen in the display ranges", () => {
    // Typographic detail that also appears on the printed sign.
    expect(BUSINESS_HOURS.daysDisplay).toContain("–");
    expect(BUSINESS_HOURS.timeDisplay).toContain("–");
  });

  it("lists exactly the five weekdays for schema.org", () => {
    expect(BUSINESS_HOURS.schemaDays).toEqual([
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
    ]);
  });

  it("uses 24-hour HH:MM times for schema.org", () => {
    expect(BUSINESS_HOURS.schemaOpens).toMatch(/^\d{2}:\d{2}$/);
    expect(BUSINESS_HOURS.schemaCloses).toMatch(/^\d{2}:\d{2}$/);
    expect(BUSINESS_HOURS.schemaOpens).toBe("09:00");
    expect(BUSINESS_HOURS.schemaCloses).toBe("17:00");
  });

  it("keeps the schema times consistent with the displayed times", () => {
    // 9:00 AM -> 09:00 and 5:00 PM -> 17:00
    const to24 = (display: string) => {
      const match = display.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
      if (!match) throw new Error(`unparseable time: ${display}`);
      let hour = Number(match[1]) % 12;
      if (match[3].toUpperCase() === "PM") hour += 12;
      return `${String(hour).padStart(2, "0")}:${match[2]}`;
    };
    const [opensDisplay, closesDisplay] = BUSINESS_HOURS.timeDisplay.split("–").map(s => s.trim());
    expect(to24(opensDisplay)).toBe(BUSINESS_HOURS.schemaOpens);
    expect(to24(closesDisplay)).toBe(BUSINESS_HOURS.schemaCloses);
  });

  it("opens before it closes", () => {
    expect(BUSINESS_HOURS.schemaOpens < BUSINESS_HOURS.schemaCloses).toBe(true);
  });
});
