export const SITE = {
  name: "Nuumeric",
  legalName: "Nuumeric Inc",
  formerName: "Montgomery Bookkeeping Solutions",
  canonicalOrigin: "https://www.nuumeric.com",
  phoneDisplay: "1 (936) 337-5446",
  phoneHref: "tel:19363375446",
  foundingYear: "2017",
  address: {
    street: "8501 Tower Point Dr",
    street2: "Ste B14",
    city: "Charlotte",
    region: "NC",
    postalCode: "28227",
    country: "US",
  },
  social: {
    linkedin: "https://www.linkedin.com/company/nuumeric/",
    instagram: "https://www.instagram.com/nuumericinc",
    facebook: "https://www.facebook.com/people/Nuumeric-Inc/61586619862905/",
    whatsapp: "http://wa.me/19363375446",
  },
  privacyPolicyUrl: "https://www.nuumeric.com/privacy-policy.html",
  careersPortalUrl: "https://careers.nuumeric.com/jobs/Careers",
} as const;

/**
 * Published business hours. These are displayed on the site, printed on the
 * office door sign, and emitted as schema.org openingHoursSpecification, so all
 * three surfaces must be changed together — a visible mismatch between the site
 * and the Google Business Profile is a verification risk.
 */
export const BUSINESS_HOURS = {
  daysDisplay: "Monday – Friday",
  timeDisplay: "9:00 AM – 5:00 PM",
  timezoneDisplay: "Eastern Time",
  /** schema.org values, kept adjacent so they cannot drift from the display text. */
  schemaDays: [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
  ],
  schemaOpens: "09:00",
  schemaCloses: "17:00",
} as const;

/** Street + suite on one line, e.g. "8501 Tower Point Dr, Ste B14". */
export function formatStreetAddress(): string {
  const { street, street2 } = SITE.address;
  return street2 ? `${street}, ${street2}` : street;
}

/** City, state and ZIP, e.g. "Charlotte, NC 28227". */
export function formatCityLine(): string {
  const { city, region, postalCode } = SITE.address;
  return `${city}, ${region} ${postalCode}`;
}

/** Single-line address for links and metadata. */
export function formatFullAddress(): string {
  return `${formatStreetAddress()}, ${formatCityLine()}`;
}

/** Google Maps search URL for the office, used by the address links. */
export function mapsUrl(): string {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    `${SITE.legalName}, ${formatFullAddress()}`,
  )}`;
}

/**
 * Client referral program. Change `creditDisplay` to adjust the incentive
 * everywhere it appears on the site.
 */
export const REFERRAL = {
  creditDisplay: "$100",
  terms:
    "Credit is applied to your next invoice after the business you refer completes their first paid month of service. No limit — every qualifying referral earns a credit.",
} as const;

/**
 * Termly.io consent & policy configuration.
 * - websiteUuid powers the site-wide consent banner (resource blocker).
 * - dataId values are Termly document ids embedded via embed-policy.min.js.
 */
export const TERMLY = {
  websiteUuid: "c732da90-366a-47be-a7f8-fb75f613b71c",
  privacyPolicyId: "879af2eb-42d9-4e89-88ea-16edac593faa",
  cookiePolicyId: "c7264ea9-c265-4359-baf6-acffb82b6434",
  termsId: "b784e644-0ef8-46ae-9987-b5ec59de25eb",
} as const;

export const CREDENTIALS = [
  "Zoho Finance Advisor",
  "Xero Advisor",
  "QuickBooks ProAdvisor",
  "Gusto Payroll",
  "SurePayroll Accountant",
] as const;

export const SERVICE_OPTIONS = [
  "Bookkeeping",
  "Business Tax Preparation",
  "Individual Tax Return",
  "Payroll Processing",
  "Zoho CRM / Sites Support",
  "Xero Support",
  "QuickBooks Support",
  "Other / Not Sure",
] as const;
