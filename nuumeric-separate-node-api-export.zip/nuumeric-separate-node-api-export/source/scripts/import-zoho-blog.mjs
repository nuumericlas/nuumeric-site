/**
 * Import old Zoho Sites blog posts (WXR/WordPress export XML) into blog_posts.
 *
 * - Parses /home/ubuntu/upload/ZohoSitesBlogexport.xml
 * - Strips Zoho Sites zp* wrapper markup, converts HTML → Markdown
 * - Removes dead images (old montgomerybusinesssolutions.com host is offline)
 * - Maps proper categories → category, hashtag categories → tags
 * - Idempotent: skips slugs that already exist
 *
 * Run: DATABASE_URL=... node scripts/import-zoho-blog.mjs [--dry-run]
 */
import fs from "node:fs";
import "dotenv/config";
import { XMLParser } from "fast-xml-parser";
import TurndownService from "turndown";
import mysql from "mysql2/promise";

const DRY = process.argv.includes("--dry-run");
const XML_PATH = "/home/ubuntu/upload/ZohoSitesBlogexport.xml";

// ---------- parse XML ----------
const parser = new XMLParser({
  ignoreAttributes: false,
  cdataPropName: "__cdata",
  isArray: name => ["item", "category"].includes(name),
});
const doc = parser.parse(fs.readFileSync(XML_PATH, "utf8"));
const items = doc?.rss?.channel?.item ?? [];
if (!items.length) {
  console.error("No <item> entries found — aborting.");
  process.exit(1);
}

const text = v =>
  v == null ? "" : typeof v === "object" ? String(v.__cdata ?? v["#text"] ?? "") : String(v);

// ---------- HTML cleanup + markdown conversion ----------
const turndown = new TurndownService({
  headingStyle: "atx",
  bulletListMarker: "-",
  codeBlockStyle: "fenced",
});
// Old-site images are dead (404) — drop all <img> from the legacy host.
turndown.addRule("deadImages", {
  filter: node =>
    node.nodeName === "IMG" &&
    /montgomerybusinesssolutions\.com/i.test(node.getAttribute("src") || ""),
  replacement: () => "",
});

function cleanHtml(html) {
  let h = html;
  h = h.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "");
  h = h.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "");
  // Zoho wraps everything in nested zp* divs — turndown handles divs as blocks,
  // but the deep nesting creates excess blank lines; flatten wrapper divs.
  h = h.replace(/<div[^>]*class="[^"]*zp[^"]*"[^>]*>/gi, "<div>");
  return h;
}

function toMarkdown(html) {
  let md = turndown.turndown(cleanHtml(html));
  md = md.replace(/\u00a0/g, " ");
  // The old montgomerybusinesssolutions.com site is offline — rewrite its links.
  // Root/contact-ish links → new site /contact; deep content links → drop the link, keep text.
  md = md.replace(
    /\[([^\]]*)\]\(https?:\/\/(?:www\.)?montgomerybusinesssolutions\.com\/?(?:contact[^)]*)?\)/gi,
    (m, label, offset) => (label.trim() ? `[${label}](/contact)` : ""),
  );
  md = md.replace(
    /\[([^\]]*)\]\(https?:\/\/(?:www\.)?montgomerybusinesssolutions\.com[^)]+\)/gi,
    (m, label) => label,
  );
  // Old email links (plain or percent-encoded, with or without mailto:) → /contact
  md = md.replace(
    /\[([^\]]*)\]\((?:mailto:)?[^)\s]*(?:%40|@)montgomerybusinesssolutions\.com[^)]*\)/gi,
    (m, label) => (label.trim() ? `[${label}](/contact)` : ""),
  );
  md = md.replace(/\n{3,}/g, "\n\n").trim();
  return md;
}

// ---------- helpers ----------
function slugify(s) {
  return (
    s
      .toLowerCase()
      .normalize("NFKD")
      .replace(/[\u2018\u2019']/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 190) || "post"
  );
}

function plainText(md) {
  return md
    .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
    .replace(/\[([^\]]*)\]\([^)]*\)/g, "$1")
    .replace(/[#>*_`~-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function makeExcerpt(md, fallback) {
  const t = fallback?.trim() || plainText(md);
  if (t.length <= 180) return t;
  const cut = t.slice(0, 180);
  return `${cut.slice(0, Math.max(cut.lastIndexOf(" "), 120))}…`;
}

const CATEGORY_NORMALIZE = {
  taxes: "Taxes",
  zoho: "Technology",
  "our company news": "Company News",
};

function mapCategories(rawCats) {
  const proper = [];
  const tags = [];
  for (const c of rawCats) {
    const name = c.trim();
    if (!name) continue;
    if (name.startsWith("#")) {
      tags.push(name.slice(1));
    } else if (/^[a-z]/.test(name) && name !== name.toLowerCase().replace(/\b\w/g, m => m)) {
      tags.push(name);
    } else if (name === name.toLowerCase()) {
      // lowercase categories like "taxes", "rebranding", "vendorbills" → tag,
      // but normalized ones can also drive the category
      tags.push(name);
    } else {
      proper.push(name);
    }
  }
  let category = proper[0] ?? null;
  // normalize
  if (!category) {
    for (const t of tags) {
      const norm = CATEGORY_NORMALIZE[t.toLowerCase()];
      if (norm) {
        category = norm;
        break;
      }
    }
  } else {
    category = CATEGORY_NORMALIZE[category.toLowerCase()] ?? category;
  }
  // extra proper categories become tags too
  for (const extra of proper.slice(1)) tags.push(extra);
  const uniqueTags = [...new Set(tags.map(t => t.trim()).filter(Boolean))];
  return { category, tags: uniqueTags.join(", ").slice(0, 490) };
}

// ---------- build rows ----------
const rows = [];
const seenSlugs = new Set();
for (const it of items) {
  const title = text(it.title).trim();
  const contentHtml = text(it["content:encoded"]);
  const excerptRaw = text(it["excerpt:encoded"]).trim();
  const postDate = text(it["wp:post_date"]).trim(); // "YYYY-MM-DD HH:MM:SS"
  const status = text(it["wp:status"]).trim();
  if (status !== "publish" || !title || !contentHtml) continue;

  let slug = slugify(title);
  while (seenSlugs.has(slug)) slug = `${slug}-2`;
  seenSlugs.add(slug);

  const md = toMarkdown(contentHtml);
  if (!md) continue;

  const rawCats = (it.category ?? []).map(c => text(c)).filter(Boolean);
  const { category, tags } = mapCategories(rawCats);

  rows.push({
    slug,
    title: title.slice(0, 300),
    excerpt: makeExcerpt(md, excerptRaw),
    content: md,
    category: category ?? "Accounting",
    tags,
    status: "published",
    publishedAt: postDate ? new Date(`${postDate.replace(" ", "T")}Z`) : new Date(),
  });
}

console.log(`prepared ${rows.length} posts`);

if (DRY) {
  fs.writeFileSync("/tmp/zoho_import_preview.json", JSON.stringify(rows, null, 2));
  console.log("full preview written to /tmp/zoho_import_preview.json");
  for (const r of rows.slice(0, 5)) {
    console.log("—".repeat(60));
    console.log(`slug: ${r.slug}\ntitle: ${r.title}\ncategory: ${r.category}\ntags: ${r.tags}\npublishedAt: ${r.publishedAt.toISOString()}\nexcerpt: ${r.excerpt}`);
    console.log(`content preview:\n${r.content.slice(0, 400)}`);
  }
  process.exit(0);
}

// ---------- insert ----------
const conn = await mysql.createConnection(process.env.DATABASE_URL);
let inserted = 0;
let skipped = 0;
for (const r of rows) {
  const [existing] = await conn.execute("SELECT id FROM blog_posts WHERE slug = ?", [r.slug]);
  if (existing.length) {
    skipped++;
    continue;
  }
  await conn.execute(
    `INSERT INTO blog_posts (slug, title, excerpt, content, category, tags, status, publishedAt, createdAt, updatedAt)
     VALUES (?, ?, ?, ?, ?, ?, 'published', ?, ?, ?)`,
    [r.slug, r.title, r.excerpt, r.content, r.category, r.tags, r.publishedAt, r.publishedAt, r.publishedAt],
  );
  inserted++;
}
await conn.end();
console.log(`inserted: ${inserted}, skipped (already existed): ${skipped}`);
