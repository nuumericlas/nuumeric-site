# Approach 2 — Separate Node API export

## What this export is

This package separates the deployment responsibilities: Netlify publishes the
browser bundle, while a Node-compatible host runs the existing Express/tRPC
server. It includes a Dockerfile, a Render-style service example, and a
Netlify redirect configuration that expects an `API_ORIGIN` site variable.

## Required implementation work

The current server still contains Manus-specific runtime helpers. Before
production use, replace or adapt Manus OAuth/session, storage proxy,
notifications, SSR/data prefetching, and scheduled callbacks. Configure the
external MySQL-compatible database, migrate live rows, move uploaded assets,
and update OAuth callback URLs and CORS/cookie settings for the two origins.

## API host setup

```bash
docker build -t nuumeric-api .
docker run --env-file .env -p 3000:3000 nuumeric-api
```

Or use the included `render.yaml.example` as a starting point for Render or
translate it to Railway/Fly.io. The API host must expose `/api/trpc`, OAuth
callbacks, storage routes, SEO routes, and the stale-review scheduler endpoint.

## Netlify frontend setup

Set `API_ORIGIN` to the HTTPS origin of the deployed Node API, then deploy the
folder containing `netlify.toml`. Validate forms, blog administration, login,
referrals, Zoho lead creation, spam review, analytics, legal embeds, and mobile
navigation in staging before changing DNS.
