# Nuumeric Inc export notes

This package contains a source snapshot of the Nuumeric Inc React + Express +
tRPC website and the previously exported website-image archive. Dependencies,
secret values, Manus project configuration, live database records, and live
third-party account settings are intentionally excluded.

The source currently depends on Manus runtime helpers under `server/_core/`.
Those integrations are preserved for reference but are not asserted to work on
the destination until authentication, storage, notifications, scheduled work,
and database connectivity are adapted and tested there.

The authoritative live-data backup remains the separate database/data export
process; this archive is not a backup of database rows.
