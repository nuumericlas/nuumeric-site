# Approach 1 — Netlify Functions export

## What this export is

This is a Netlify-oriented source export with `netlify.toml`, the static publish
configuration, the `/api/*` redirect boundary, and an explicitly non-production
placeholder function. It is a migration starter, not a claim that the current
full-stack Manus application can be deployed unchanged to Netlify Functions.

## Required implementation work

Port the procedures in `source/server/routers.ts` into one or more Netlify
Functions, or expose a compatible tRPC adapter. Rework Manus OAuth/session
handling, the S3/storage proxy, owner notifications, stale-review scheduling,
Zoho integration, and SSR/data prefetching for the destination services. Point
`DATABASE_URL` at an external MySQL-compatible provider and migrate the live
records separately. Rewrite `/manus-storage/...` asset references or use an
external object-storage/CDN URL.

## Initial setup

```bash
cd source
pnpm install --frozen-lockfile
pnpm run check
pnpm test
pnpm run build
```

Deploy the repository root containing `netlify.toml` only after replacing the
placeholder function and configuring all required environment variables. Add a
Netlify scheduled function or an external scheduler for stale spam-review
alerts; the current Express POST endpoint is not automatically scheduled by
Netlify.
