/**
 * Netlify Functions migration boundary.
 *
 * This deliberately returns 501 until the current Express/tRPC procedures,
 * OAuth callbacks, storage proxy, scheduled handler, and notifications have
 * been moved into Netlify-compatible handlers. Do not deploy this placeholder
 * as a production API.
 */
export default async function handler() {
  return new Response(
    JSON.stringify({
      error: "Netlify Functions backend migration is not complete",
      nextStep: "Port the procedures from source/server/routers.ts and replace this handler",
    }),
    { status: 501, headers: { "content-type": "application/json" } },
  );
}
